---
title: "Body bias in FD-SOI: one transistor, two gates"
description: "Why the thin buried oxide turns the substrate into a second gate, how much it moves the threshold voltage, and what chip designers do with it."
date: 2026-10-22
tags: [cmos, fd-soi, tutorial]
devices: [fdsoi-mosfet]
---

In a bulk MOSFET the substrate is a nuisance: biasing it shifts the threshold voltage a little (the *body effect*), but it also leaks through junctions. In **FD-SOI** the transistor sits on a buried oxide, and the substrate under that oxide becomes a clean, well-behaved **second gate**.

## A capacitive divider

The channel is a silicon film only $t_{Si} \approx 7$ nm thick. It is coupled to the front gate through the gate oxide ($C_{ox}$) and to the back plane through the buried oxide ($C_{BOX}$). Because the film is fully depleted, both gates see the same charge and the threshold shift is set by a capacitive divider:

$$
\Delta V_t \approx -\frac{C_{Si}\,C_{BOX}}{C_{ox}\,(C_{Si} + C_{BOX})}\,V_{BB} \;=\; -\gamma\,V_{BB}
$$

With a 1.2 nm equivalent oxide, a 7 nm film and a 25 nm BOX, $\gamma$ comes out around 70–85 mV/V. A ±3 V back bias therefore moves $V_t$ by about ±0.25 V, more than enough to switch a circuit between a *turbo* mode and a *sleep* mode.

## See it

Set $V_G = 0.35$ V and move the back bias in the simulation below. Use the vertical cut: the back plane pulls the bands in the film down and the electrons appear, without touching the front gate.

{% devicesim "fdsoi-mosfet", "atomic" %}

## Speed against leakage

Because sub-threshold current falls by a decade every $SS \approx 70$ mV, a 200 mV threshold shift changes the off-current by about three decades:

$$
\frac{I_{off}(V_{BB})}{I_{off}(0)} = 10^{\,\gamma V_{BB}/SS}
$$

The bench's *I_on–I_off* card shows the whole trade-off as $V_{BB}$ sweeps from −3 to +3 V. Designers use **forward body bias** to recover speed in slow corners or at low supply voltage, and **reverse body bias** to cut standby leakage, on the same silicon, after fabrication.

## Further reading

- Open the [FD-SOI MOSFET device page](/devices/fdsoi-mosfet/) for both simulations.
- The [technology overview](/technologies/cmos/) lists the other CMOS devices.
