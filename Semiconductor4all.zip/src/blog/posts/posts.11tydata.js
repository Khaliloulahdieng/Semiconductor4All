// Defaults for every article in src/blog/posts/.
// The URL comes from `slug` in front matter (or the folder/file name) and never from the date,
// so a published article keeps its address even if you edit or re-date it.
export default {
  layout: "layouts/post.njk",
  permalink: (data) => `/blog/${data.slug || data.page.fileSlug}/`,
};
