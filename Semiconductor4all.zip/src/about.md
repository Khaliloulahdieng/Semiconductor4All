---
layout: layouts/page.njk
permalink: /about/
title: About Semiconductor4all
description: Why this site exists and how the simulations are built.
---

Semiconductor4all explains semiconductor devices by letting you play with them. Every device has two simulations:

1. **Atomic physics.** A cross-section of the device with its crystal lattice, dopant ions, free electrons (blue) and holes (red). Next to it, an energy-band diagram along a cut line you choose. The bands come from a one-dimensional Poisson solver that runs in your browser every time you move a slider.
2. **How it works.** The device on a test bench: a front panel of instruments, a schematic with numbered test points (TP), and a probe card for each test point with its equation, a live plot and readouts.

## About the models

The models are compact and analytical (EKV-style transistor currents, depletion and plasma-dispersion laws, transmission-line formulas) with parameters chosen to look like real technologies. They are built for intuition: trends and orders of magnitude are right, but the numbers are not from a foundry PDK. Each page lists what is and is not modelled.

## Articles

The [articles](/blog/) go deeper into a topic and embed the same live simulations.
