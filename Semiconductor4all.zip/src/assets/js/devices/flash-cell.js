// Floating-gate flash memory cell (NAND-style): FN tunnelling program/erase, read and retention.
import { buildGrid, solvePoisson, interp, visDensity, ekvId, fSI, f, q, kB } from "../lib/physics.js";
import { map, linspace, logspace } from "../lib/plot.js";

// ---------- cell model ----------
const TOX = 7;               // tunnel oxide, nm
const CT = 9e-17;            // total floating-gate capacitance, F
const AG = 0.65;             // control-gate coupling ratio
const VT_FG = 0.6;           // threshold seen from the floating gate, V
const AREA = 2e-11;          // tunnelling area, cm²
const FN_A = 4.8e-7, FN_B = 3.9e8; // Fowler–Nordheim constants for a 3.2 eV barrier (A/V², V/cm)
const vfg = (VCG, n) => AG * VCG - (n * q) / CT;
const vtCG = (n) => (VT_FG + (n * q) / CT) / AG;
const psiS = (V) => 0.9 / (1 + Math.exp(-(V - VT_FG) / 0.15)) - 0.1; // surface potential: accumulation → inversion
const field = (VCG, n) => (vfg(VCG, n) - psiS(vfg(VCG, n))) / (TOX * 1e-7); // V/cm, > 0 pulls electrons up
const fnJ = (E) => { const a = Math.abs(E); return a < 1e6 ? 0 : FN_A * a * a * Math.exp(-FN_B / a); }; // A/cm²
const rate = (VCG, n) => { const E = field(VCG, n); return Math.sign(E) * fnJ(E) * AREA / q; }; // electrons/s into the FG

// ---------- atomic: Poisson below the floating gate + composite stack ----------
function below(VFG) {
  const g = buildGrid([{ mat: "SiO2", t: TOX, dx: 0.25 }, { mat: "Si", t: 120, N: -5e17, dx: 0.8 }]);
  const s = solvePoisson(g, { left: { type: "gate", V: VFG, wf: 4.05 }, right: { type: "ohmic", V: 0 } });
  let ns = 0; for (let i = 1; i < g.x.length; i++) if (g.x[i] > TOX) ns += s.n[i] * (g.x[i] - g.x[i - 1]) * 1e-7;
  return { g, s, ns };
}
const T_CG = 10, T_ONO = 12, T_FG = 15, X_TOX = T_CG + T_ONO + T_FG;
function stack(VCG, VFG, B) {
  const xs = [], Ec = [], Ev = [], EFn = [], EFp = [], n = [], p = [], E = [];
  const push = (x, ec, ev, ef, nn, pp, e) => { xs.push(x); Ec.push(ec); Ev.push(ev); EFn.push(ef); EFp.push(ef); n.push(nn); p.push(pp); E.push(e); };
  for (let k = 0; k <= 10; k++) push((T_CG * k) / 10, -VCG, -VCG - 1.12, -VCG, 1e20, 1, 0);
  const eOno = ((VCG - VFG) / (T_ONO * 1e-7));
  for (let k = 0; k <= 24; k++) { const t = k / 24, v = VCG + (VFG - VCG) * t; push(T_CG + T_ONO * t, -v + 3.1, -v + 3.1 - 9, NaN, NaN, NaN, eOno); }
  for (let k = 0; k <= 10; k++) push(T_CG + T_ONO + (T_FG * k) / 10, -VFG, -VFG - 1.12, -VFG, 1e20, 1, 0);
  const s = B.s;
  for (let i = 0; i < s.x.length && s.x[i] <= TOX + 40; i++) { const ins = !s.semi[i]; push(X_TOX + s.x[i], s.Ec[i], s.Ev[i], ins ? NaN : s.EFn[i], ins ? NaN : s.n[i], ins ? NaN : s.p[i], s.E[i]); }
  const A = (a) => Float64Array.from(a);
  return { x: A(xs), Ec: A(Ec), Ev: A(Ev), EFn: A(EFn), EFp: A(EFp), n: A(n), p: A(p), E: A(E) };
}

const atomic = {
  intro: "A flash cell is a transistor with an extra, electrically isolated gate. Electrons trapped on this floating gate raise the threshold voltage: that is the stored bit. A large control-gate voltage tilts the thin tunnel oxide so steeply that electrons tunnel through it (Fowler–Nordheim). Not to scale.",
  controls: [
    { label: "Control gate", color: "ph", items: [{ id: "VCG", label: "V_CG", min: -20, max: 20, step: 0.5, value: 3, fmt: (v) => f(v, 1) + " V" }] },
    { label: "Floating gate", color: "e", items: [{ id: "nFG", label: "Stored electrons", min: -300, max: 2000, step: 25, value: 0, fmt: (v) => (v < 0 ? "+" + -v + " holes" : v + " e⁻") }, { type: "note", text: "Negative = over-erased (net positive charge)." }] },
  ],
  presets: [
    { label: "Erased, read at 3 V", set: { VCG: 3, nFG: 0 } }, { label: "Programmed, read at 3 V", set: { VCG: 3, nFG: 1100 } },
    { label: "Programming pulse +18 V", set: { VCG: 18, nFG: 300 } }, { label: "Erase pulse −18 V", set: { VCG: -18, nFG: 1100 } },
  ],
  look: [
    "Read at V_CG = 3 V: with an empty floating gate the channel inverts (electrons under the tunnel oxide); with 1100 stored electrons it stays off. That on/off difference is the bit.",
    "Apply +18 V on the full-stack cut: the tunnel oxide becomes a thin triangular barrier and electrons tunnel from the channel into the floating gate.",
    "Apply −18 V: the field reverses and electrons leave the floating gate (erase).",
    "At 3 V the oxide barrier is thick and nearly flat: the electrons stay put for years (retention).",
  ],
  world: { w: 160, h: 100 }, aspect: "8/5", lensAt: [80, 45],
  cuts: [{ id: "stack", label: "Full stack: CG → FG → substrate", a: [80, 15], b: [80, 99] }, { id: "tox", label: "Tunnel oxide → substrate", a: [70, 52], b: [70, 99] }],
  solve(st) {
    const VFG = vfg(st.VCG, st.nFG);
    const B = below(VFG);
    return { VFG, B, E: field(st.VCG, st.nFG), J: fnJ(field(st.VCG, st.nFG)), stack: stack(st.VCG, VFG, B) };
  },
  scene(S, st) {
    const tun = S.J > 1e-9 ? Math.min(0.8, 0.15 + 0.08 * Math.log10(S.J / 1e-9)) : 0;
    const up = S.E > 0;
    const ch = visDensity(S.B.ns / 5e-6, 13, 19.5);
    return {
      regions: [
        { x: 0, y: 60, w: 160, h: 40, mat: "si", dop: "p", label: "p-well" },
        { x: 8, y: 56, w: 44, h: 13, mat: "si", dop: "n+" }, { x: 108, y: 56, w: 44, h: 13, mat: "si", dop: "n+" },
        { x: 52, y: 56, w: 56, h: 4, mat: "si", dop: "p" },
        { x: 40, y: 10, w: 80, h: 46, mat: "ox" },
        { x: 45, y: 12, w: 70, h: 20, mat: "poly" },
        { x: 52, y: 38, w: 56, h: 13, mat: "poly" },
      ],
      zones: [
        { id: "fg", type: "e", x: 53, y: 39, w: 54, h: 11, dens: Math.max(0, Math.min(1, st.nFG / 1800)), jit: 0.25, px: 50 },
        { id: "cg", type: "e", x: 46, y: 13, w: 68, h: 18, dens: 0.35, jit: 0.2 },
        { id: "sd1", type: "e", x: 8, y: 56, w: 44, h: 13, dens: 0.9 }, { id: "sd2", type: "e", x: 108, y: 56, w: 44, h: 13, dens: 0.9 },
        { id: "ch", type: "e", x: 52, y: 56, w: 56, h: 2.5, dens: ch, jit: 0.3 },
        { id: "tun", type: "e", x: 56, y: 51, w: 48, h: 5, dens: tun, vy: up ? -12 : 12, jit: 0.15, px: 40 },
        { id: "sub", type: "h", x: 0, y: 62, w: 160, h: 38, dens: 0.45 },
        ...(st.nFG < 0 ? [{ id: "fgh", type: "h", x: 53, y: 39, w: 54, h: 11, dens: Math.min(1, -st.nFG / 400) }] : []),
      ],
      depl: ch < 0.3 && S.VFG > -0.2 ? [{ x: 52, y: 56, w: 56, h: 10 }] : [],
      arrows: tun > 0 ? [{ x1: 112, y1: up ? 57 : 49, x2: 112, y2: up ? 47 : 59, color: "e", label: up ? "FN tunnelling: program" : "FN tunnelling: erase" }] : [],
      labels: [
        { x: 80, y: 22, text: "control gate", size: 10 }, { x: 80, y: 44.5, text: "floating gate", size: 10 },
        { x: 26, y: 35, text: "ONO", size: 10, color: "muted" }, { x: 30, y: 62.5, text: "n⁺ source", size: 10 }, { x: 130, y: 62.5, text: "n⁺ drain", size: 10 },
        { x: 30, y: 90, text: "p-well", size: 10, color: "muted" },
      ],
      terminals: [{ x: 80, y: 5, text: `CG ${f(st.VCG, 1)} V` }, { x: 136, y: 92, text: `FG ${f(S.VFG, 2)} V` }],
    };
  },
  bands(S, st, cut) {
    if (cut === "stack") {
      const B = S.stack;
      return { ...B, regions: [{ x0: 0, x1: T_CG, label: "CG" }, { x0: T_CG, x1: T_CG + T_ONO, label: "ONO" }, { x0: T_CG + T_ONO, x1: X_TOX, label: "FG" }, { x0: X_TOX, x1: X_TOX + TOX, label: "" }, { x0: X_TOX + TOX, x1: X_TOX + TOX + 40, label: "p-Si" }],
        xlabel: "depth from control gate (nm)", clip: [-24, 24] };
    }
    const { g, s } = S.B;
    return { x: s.x, Ec: s.Ec, Ev: s.Ev, EFn: s.EFn, EFp: s.EFp, n: s.n, p: s.p, E: s.E, Nabs: map(g.N, Math.abs), regions: [{ x0: 0, x1: TOX, label: "tunnel ox" }, { x0: TOX, x1: TOX + 120, label: "p-Si" }], xlabel: "depth below floating gate (nm)", clip: [-12, 12] };
  },
  readouts(S, st) {
    return [["V_FG", f(S.VFG, 2) + " V"], ["Tunnel-oxide field", (S.E / 1e6).toFixed(1) + " MV/cm", Math.abs(S.E) > 1e7 ? "warn" : ""], ["FN current density", S.J > 1e-15 ? S.J.toExponential(1) + " A/cm²" : "≈ 0"],
      ["V_t seen from CG", f(vtCG(st.nFG), 2) + " V"], ["Channel electrons", S.B.ns.toExponential(1) + " cm⁻²"]];
  },
  foot: "Floating gate as a capacitive node: V_FG = α_G·V_CG + Q_FG/C_T (α_G = 0.65, C_T = 90 aF). Below it: 1D Poisson through a 7 nm tunnel oxide into 5×10¹⁷ p-Si. Full-stack cut assembled from the control gate, a 12 nm (EOT) ONO, the n⁺ poly floating gate and that Poisson solution. Illustrative values.",
};

// ---------- bench ----------
function transient(st) {
  const tEnd = Math.pow(10, st.lpw);
  const ts = logspace(-9, Math.log10(tEnd), 220);
  const V = st.mode === "pgm" ? st.Vp : -st.Vp;
  let n = st.mode === "pgm" ? 0 : 1100, tPrev = 0;
  const out = { t: ts, n: new Float64Array(ts.length), E: new Float64Array(ts.length), J: new Float64Array(ts.length), vt: new Float64Array(ts.length) };
  for (let i = 0; i < ts.length; i++) {
    const steps = 12, dt = (ts[i] - tPrev) / steps;
    for (let k = 0; k < steps; k++) {
      // RK2 on dn/dt = rate(V, n)
      const k1 = rate(V, n), k2 = rate(V, n + k1 * dt / 2);
      n += k2 * dt;
    }
    tPrev = ts[i];
    out.n[i] = n; out.E[i] = field(V, n); out.J[i] = fnJ(out.E[i]); out.vt[i] = vtCG(n);
  }
  return { ...out, V, nEnd: n, tEnd };
}
const readId = (VCG, n, VD = 0.5) => ekvId(VCG, VD, { Vt: vtCG(n), n: 1.4 / AG, beta: 4e-5, Ut: 0.0259, theta: 0.3 });

const bench = {
  intro: "A pulse generator drives the control gate while source, drain and well are grounded; a source-meter then reads the cell. Choose program or erase, the pulse height and length, and follow the charge onto (or off) the floating gate.",
  animated: true,
  controls: [
    { label: "Pulse generator (TP1)", color: "ph", items: [{ id: "mode", type: "seg", options: [["pgm", "Program (+V)"], ["ers", "Erase (−V)"]], value: "pgm" }, { id: "Vp", label: "Pulse amplitude |V_CG|", min: 12, max: 22, step: 0.5, value: 18, fmt: (v) => v.toFixed(1) + " V" }, { id: "lpw", label: "Pulse width", min: -6, max: -1, step: 0.1, value: -3, fmt: (v) => fSI(Math.pow(10, v), "s", 1) }] },
    { label: "Read SMU (TP4)", color: "rf", items: [{ id: "Vread", label: "Read voltage on CG", min: 0, max: 6, step: 0.1, value: 2.5, fmt: (v) => v.toFixed(1) + " V" }] },
    { label: "Storage (A2)", color: "heat", items: [{ id: "Tret", label: "Bake temperature", min: 25, max: 200, step: 5, value: 85, fmt: (v) => v + " °C" }] },
  ],
  presets: [
    { label: "Program 18 V, 1 ms", set: { mode: "pgm", Vp: 18, lpw: -3 } },
    { label: "Program 15 V: too weak", set: { mode: "pgm", Vp: 15, lpw: -3 } },
    { label: "Program 20 V, 10 µs", set: { mode: "pgm", Vp: 20, lpw: -5 } },
    { label: "Erase −18 V, 1 ms", set: { mode: "ers", Vp: 18, lpw: -3 } },
  ],
  schematic: {
    viewBox: "0 0 900 320",
    svg: `
  <rect class="bx" x="30" y="40" width="160" height="56" rx="5"/><text class="lb" x="110" y="64" text-anchor="middle">Pulse generator</text><text class="sub" x="110" y="83" text-anchor="middle">±V_CG, width t_p</text>
  <rect class="bx" x="30" y="200" width="160" height="56" rx="5"/><text class="lb" x="110" y="224" text-anchor="middle">Read SMU</text><text class="sub" x="110" y="243" text-anchor="middle">V_read sweep</text>
  <rect class="bx chip" x="250" y="120" width="80" height="36" rx="4"/><text class="lb" x="290" y="143" text-anchor="middle">Switch</text>
  <path class="mix" d="M190,68 H230 V130 H250 M190,228 H230 V146 H250 M330,138 H420"/>
  <rect class="ht" x="420" y="100" width="180" height="22" rx="4"/><text class="lb" x="510" y="116" text-anchor="middle">control gate</text>
  <rect class="bx" x="420" y="126" width="180" height="8" fill="var(--m-ox)"/>
  <rect class="dev fgbox" x="430" y="138" width="160" height="26" rx="3"/><text class="lb fgtxt" x="510" y="156" text-anchor="middle">floating gate</text>
  <rect class="bx" x="420" y="168" width="180" height="6" fill="var(--m-ox)"/>
  <rect class="bx" x="380" y="178" width="260" height="40" fill="var(--m-p)"/><text class="sub" x="510" y="203" text-anchor="middle">p-well (channel)</text>
  <path class="w" d="M380,198 H350 V270 M640,198 H680 V140 H740"/>
  <rect class="bx" x="740" y="112" width="140" height="56" rx="5"/><text class="lb" x="810" y="136" text-anchor="middle">Drain SMU</text><text class="sub" x="810" y="155" text-anchor="middle">0 V / 0.5 V read</text>
  <path class="w" d="M335,270 H365 M342,276 H358"/><text class="sub" x="370" y="274">source, well = 0 V</text>`,
  },
  tps: [{ n: 1, x: 380, y: 138, label: "control-gate pulse" }, { n: 2, x: 620, y: 171, label: "tunnel oxide" }, { n: 3, x: 510, y: 188, label: "floating-gate charge" }, { n: 4, x: 700, y: 140, label: "read" }],
  sections: [{ k: "op", t: "Program / erase pulse", n: "Time axis is logarithmic: tunnelling is slow at first and self-limits as charge builds up." }, { k: "rd", t: "Reading and keeping the bit", n: "" }],
  cards: [
    { id: "tp1", tp: 1, s: "op", d: "ph", dn: "pulse", t: "Control-gate pulse", x: "Square pulse on the control gate (log time). The floating gate follows with the coupling ratio, minus its own charge.", eq: "V<sub>FG</sub> = α<sub>G</sub>V<sub>CG</sub> + Q<sub>FG</sub>/C<sub>T</sub>,&nbsp; α<sub>G</sub> = C<sub>ONO</sub>/C<sub>T</sub> = 0.65" },
    { id: "tp2", tp: 2, s: "op", d: "th", dn: "oxide", t: "Tunnel oxide: field and FN current", x: "Top: oxide field. Bottom: Fowler–Nordheim current density. As electrons accumulate, the field drops and the current collapses exponentially.", eq: "J<sub>FN</sub> = A·E²·e<sup>−B/E</sup>,&nbsp; B = 6.83×10⁷·φ<sub>B</sub><sup>3/2</sup> V/cm,&nbsp; E = (V<sub>FG</sub> − ψ<sub>s</sub>)/t<sub>ox</sub>", kind: "dual" },
    { id: "tp3", tp: 3, s: "op", d: "ok", dn: "charge", t: "Floating gate: stored charge and V_t", x: "Electrons on the floating gate and the threshold voltage seen from the control gate. Dashed: program-verify and erase-verify levels.", eq: "dn/dt = J<sub>FN</sub>·A<sub>tun</sub>/q,&nbsp; ΔV<sub>t</sub> = −Q<sub>FG</sub>/(α<sub>G</sub>C<sub>T</sub>) = n·q/C<sub>CG</sub>" },
    { id: "tp4", tp: 4, s: "rd", d: "rf", dn: "read", t: "Read: I_D vs V_CG", x: "Erased cell (left curve) and the cell after this pulse (right). At the read voltage one conducts (\"1\"), the other does not (\"0\").", eq: "I<sub>read</sub> &gt; I<sub>sense</sub> ⇒ \"1\" (erased),&nbsp; V<sub>t,ers</sub> &lt; V<sub>read</sub> &lt; V<sub>t,pgm</sub>" },
    { id: "a1", chip: "J–E", s: "rd", d: "an", dn: "physics", t: "Fowler–Nordheim characteristic", x: "Tunnel current vs oxide field: 10 orders of magnitude between read (~2 MV/cm) and program (~15 MV/cm). That non-linearity is why the bit survives reading.", eq: "ln(J/E²) = ln A − B/E: a straight line on a Fowler–Nordheim plot" },
    { id: "a2", chip: "RET", s: "rd", d: "an", dn: "retention", t: "Retention bake", x: "Slow charge loss through oxide defects, accelerated by temperature (Arrhenius, E_a = 1.1 eV). Specification: 10 years at 85 °C.", eq: "n(t) = n<sub>0</sub>·exp[−(t/τ)<sup>½</sup>],&nbsp; τ = τ<sub>0</sub>e<sup>E<sub>a</sub>/kT</sup>" },
  ],
  foot: "Model: floating gate with C_T = 90 aF, coupling 0.65, tunnelling area 2×10⁻¹¹ cm² through 7 nm SiO₂ (φ_B = 3.2 eV), surface potential from accumulation to inversion, read current from an EKV channel. Retention: stretched-exponential loss, E_a = 1.1 eV, calibrated to 10 % loss after 10 years at 85 °C. Illustrative values.",
  sim(st) {
    const R = { tr: transient(st) };
    R.vtErs = vtCG(0); R.vtNow = vtCG(R.tr.nEnd);
    R.vg = linspace(-2, 7, 181);
    R.idE = map(R.vg, (v) => readId(v, 0)); R.idP = map(R.vg, (v) => readId(v, R.tr.nEnd)); R.idPg = map(R.vg, (v) => readId(v, 1100));
    R.Es = linspace(1e6, 1.8e7, 120); R.Js = map(R.Es, fnJ);
    const tau = (Tc) => 9.7e-6 * Math.exp(1.1 / (kB * (Tc + 273.15)));
    R.tret = logspace(0, 9, 120);
    const n0 = st.mode === "pgm" ? Math.max(R.tr.nEnd, 1) : 1100;
    R.ret = map(R.tret, (t) => vtCG(n0 * Math.exp(-Math.sqrt(t / tau(st.Tret)))));
    R.ret85 = map(R.tret, (t) => vtCG(n0 * Math.exp(-Math.sqrt(t / tau(85)))));
    R.read = { ers: readId(st.Vread, 0), now: readId(st.Vread, R.tr.nEnd) };
    return R;
  },
  render(R, api) {
    const { st, C } = api, T = R.tr;
    const n = T.t.length, cur = (api.frame * 2) % n, tc = T.t[cur];
    const dvt = R.vtNow - R.vtErs;
    const ok = st.mode === "pgm" ? R.vtNow >= 3 : R.vtNow <= 0.9;
    api.status([
      ["Operation", st.mode === "pgm" ? "Program" : "Erase", ""], ["Electrons on FG", T.nEnd.toFixed(0), ""], ["V_t after pulse", f(R.vtNow, 2) + " V", ok ? "good" : "warn"],
      ["ΔV_t vs erased", f(dvt, 2) + " V", ""], ["Peak oxide field", (Math.max(...map(T.E, Math.abs)) / 1e6).toFixed(1) + " MV/cm", ""],
      ["Verify", ok ? "pass" : "fail: more pulse", ok ? "good" : "warn"],
    ]);
    api.q(".fgtxt").textContent = `floating gate: ${T.nEnd < 0 ? "+" + (-T.nEnd).toFixed(0) + " holes" : T.nEnd.toFixed(0) + " e⁻"}`;
    api.plot("tp1", { xlog: true, xmin: 1e-9, xmax: T.tEnd, ymin: Math.min(0, T.V) * 1.15 - 1, ymax: Math.max(0, T.V) * 1.15 + 1, xlabel: "time (s)", ylabel: "V (V)", legend: true,
      series: [{ x: T.t, y: map(T.t, () => T.V), color: C.ph, w: 2.2, label: "V_CG" }, { x: T.t, y: map(T.n, (nn) => vfg(T.V, nn)), color: C.e, w: 1.6, dash: [4, 3], label: "V_FG" }], cursor: tc });
    api.eqv("tp1", `V_FG(t = 0) = 0.65 × ${f(T.V, 1)} = ${f(AG * T.V, 2)} V; at the end ${f(vfg(T.V, T.nEnd), 2)} V`);
    api.ro("tp1", [["Amplitude", f(T.V, 1) + " V"], ["Width", fSI(T.tEnd, "s", 1)], ["V_FG at cursor", f(vfg(T.V, T.n[cur]), 2) + " V"]]);
    api.plot("tp2", { xlog: true, xmin: 1e-9, xmax: T.tEnd, xlabel: "time (s)", ylabel: "|E| (MV/cm)", series: [{ x: T.t, y: map(T.E, (e) => Math.abs(e) / 1e6), color: C.heat, w: 2 }], cursor: tc }, 0);
    api.plot("tp2", { xlog: true, ylog: true, xmin: 1e-9, xmax: T.tEnd, ymin: 1e-8, ymax: 10, ylabel: "J (A/cm²)", series: [{ x: T.t, y: map(T.J, (j) => Math.max(j, 1e-12)), color: C.e, w: 2 }], cursor: tc }, 1);
    api.ro("tp2", [["E at cursor", (Math.abs(T.E[cur]) / 1e6).toFixed(2) + " MV/cm"], ["J at cursor", T.J[cur].toExponential(1) + " A/cm²"], ["Electrons/s", (T.J[cur] * AREA / q).toExponential(1)]]);
    api.plot("tp3", { xlog: true, xmin: 1e-9, xmax: T.tEnd, ymin: -1, ymax: 6, xlabel: "time (s)", ylabel: "V_t from CG (V)", series: [{ x: T.t, y: T.vt, color: C.ok, w: 2.2 }], hlines: [{ y: 3, color: C.muted, dash: [3, 3], label: "program verify" }, { y: 0.9, color: C.muted, dash: [2, 3], label: "erase verify" }], cursor: tc });
    api.ro("tp3", [["Electrons at cursor", T.n[cur].toFixed(0)], ["V_t at cursor", f(T.vt[cur], 2) + " V"], ["ΔV_t per 100 e⁻", ((100 * q) / (AG * CT)).toFixed(2) + " V"]]);
    api.plot("tp4", { xmin: -2, xmax: 7, ylog: true, ymin: 1e-12, ymax: 1e-4, xlabel: "V_CG (V)", ylabel: "I_D (A)", legend: true,
      series: [{ x: R.vg, y: R.idE, color: C.ok, w: 2, label: "erased" }, { x: R.vg, y: R.idP, color: C.rf, w: 2.2, label: "after pulse" }],
      vlines: [{ x: st.Vread, color: C.ink, dash: [3, 3], label: "V_read" }], hlines: [{ y: 1e-7, color: C.muted, dash: [2, 3], label: "sense level" }] });
    const bit = (i) => (i > 1e-7 ? "1 (conducts)" : "0 (off)");
    api.ro("tp4", [["Erased cell reads", bit(R.read.ers)], ["This cell reads", bit(R.read.now)], ["Window", f(dvt, 2) + " V"]]);
    api.plot("a1", { xmin: 0, xmax: 18, ylog: true, ymin: 1e-14, ymax: 100, xlabel: "E (MV/cm)", ylabel: "J (A/cm²)", series: [{ x: map(R.Es, (e) => e / 1e6), y: map(R.Js, (j) => Math.max(j, 1e-20)), color: C.ink, w: 2 }],
      vbands: [{ x0: 0, x1: 3, color: C.ok, a: 0.12, label: "read" }, { x0: 12, x1: 18, color: C.rf, a: 0.12, label: "program/erase" }], points: [{ x: Math.abs(T.E[cur]) / 1e6, y: Math.max(T.J[cur], 1e-14), color: C.e }] });
    api.ro("a1", [["J at 3 MV/cm", fnJ(3e6).toExponential(0) + " A/cm²"], ["J at 15 MV/cm", fnJ(1.5e7).toExponential(1) + " A/cm²"]]);
    api.plot("a2", { xlog: true, xmin: 1, xmax: 1e9, ymin: -1, ymax: 6, xlabel: "time (s)", ylabel: "V_t (V)", legend: true,
      series: [{ x: R.tret, y: R.ret85, color: C.muted, w: 1.2, dash: [3, 3], label: "85 °C" }, { x: R.tret, y: R.ret, color: C.heat, w: 2.2, label: st.Tret + " °C" }],
      vlines: [{ x: 3.15e8, color: C.ink, dash: [2, 3], label: "10 years" }], hlines: [{ y: st.Vread, color: C.bad, dash: [3, 3], label: "V_read" }] });
    const lost = R.ret.findIndex((v) => v < st.Vread);
    api.ro("a2", [["Bit lost after", lost < 0 ? "> 30 years" : fSI(R.tret[lost], "s", 1)], ["Bake", st.Tret + " °C"]]);
  },
};

export default { atomic, bench };
