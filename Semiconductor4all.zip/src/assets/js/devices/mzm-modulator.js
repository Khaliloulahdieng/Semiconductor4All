// Depletion-mode silicon Mach-Zehnder modulator (push-pull), ported from the SiPh MZM test bench.
import { buildGrid, solvePoisson, depletedSpans, interp, visDensity, fSI, f, depletionWidth, builtIn } from "../lib/physics.js";
import { map, linspace } from "../lib/plot.js";

const PI = Math.PI;

// ---------- atomic: lateral PN junction across the rib ----------
const NA = 5e17, ND = 5e17, NPP = 1e20;
const LPP = 200, LP = 700, LN = 700, LNP = 200, XJ = LPP + LP; // nm
const NM = 10;           // nm per world unit
const X0 = 10;           // world x of the p+ edge
const toW = (nm) => X0 + nm / NM;
function lateral(V) {    // V = voltage on the n contact (p contact grounded); V > 0 is reverse bias
  const g = buildGrid([
    { mat: "Si", t: LPP, N: -NPP, dx: 6, phin: V, phip: 0 },
    { mat: "Si", t: LP, N: -NA, dx: 4, phin: V, phip: 0 },
    { mat: "Si", t: LN, N: ND, dx: 4, phin: V, phip: 0 },
    { mat: "Si", t: LNP, N: NPP, dx: 6, phin: V, phip: 0 },
  ]);
  return { g, s: solvePoisson(g, { left: { type: "ohmic", V: 0 }, right: { type: "ohmic", V } }) };
}
// plasma-dispersion effect at 1550 nm (Soref)
const dnE = (N) => -8.8e-22 * N, dnH = (N) => -8.5e-18 * Math.pow(N, 0.8);
function junctionNumbers(VR) {
  const Vbi = builtIn(NA, ND);
  const W = depletionWidth(Vbi + VR, NA, ND), W0 = depletionWidth(Vbi, NA, ND);
  const xn = W * NA / (NA + ND), xp = W * ND / (NA + ND), xn0 = W0 * NA / (NA + ND), xp0 = W0 * ND / (NA + ND);
  // carriers removed from the optical mode (~500 nm wide), overlap Γ ≈ 0.7
  const dneff = 0.7 * (-(dnE(ND) * (xn - xn0)) - dnH(NA) * (xp - xp0)) / 500;
  const L = 3e-3, lam = 1.55e-6;
  const dphi = (2 * PI / lam) * dneff * L;
  return { Vbi, W, xn, xp, dneff, dphi };
}

const fmtV = (v) => f(v, 2) + " V";
const shiftY = (sc, dy) => {
  for (const k of ["regions", "depl", "ions", "zones", "labels", "terminals"]) for (const o of sc[k] || []) o.y += dy;
  for (const g of sc.glows || []) g.cy += dy;
  return sc;
};
const atomic = {
  intro: "Cross-section of one MZM arm: a 500 nm × 220 nm silicon rib in oxide, doped p on the left and n on the right. Reverse bias widens the depletion region, removing free carriers from where the light travels, which changes the refractive index (plasma dispersion). Not to scale vertically.",
  controls: [
    { label: "Junction bias", color: "dc", items: [{ id: "VR", label: "Reverse bias V_R (n side +)", min: -0.9, max: 5, step: 0.05, value: 2, fmt: fmtV }, { type: "note", text: "Negative values forward-bias the diode: carriers are injected (slow, lossy)." }] },
    { label: "Light", color: "opt", items: [{ id: "light", type: "check", label: "Show optical mode (TE, 1550 nm)", value: true }] },
  ],
  presets: [
    { label: "0 V", set: { VR: 0 } }, { label: "Reverse 2 V (bias point)", set: { VR: 2 } }, { label: "Reverse 5 V", set: { VR: 5 } }, { label: "Forward 0.8 V", set: { VR: -0.8 } },
  ],
  look: [
    "Slide V_R from 0 to 5 V: the hatched depletion region in the rib widens like √(V_bi + V_R). The holes and electrons it pushes out are exactly what the light was interacting with.",
    "Switch the plot to Carriers: the hole and electron densities drop by many decades across the junction.",
    "Forward-bias the junction (V_R < 0): the quasi-Fermi levels split the other way and minority carriers flood in. That changes the index a lot, but slowly (ns lifetimes) and with absorption.",
    "Put the lens on the rib centre: in the depleted zone you see dopant ions (P⁺, B⁻) but no free carriers.",
  ],
  // scene() is drawn in a 200×100 frame; the top 26 units (empty cladding) are cropped via shiftY
  world: { w: 200, h: 64 }, aspect: "25/8", lensAt: [100, 30],
  cuts: [{ id: "lat", label: "Across the junction (p⁺ → n⁺)", a: [toW(0), 38], b: [toW(LPP + LP + LN + LNP), 38] }],
  solve(st) {
    const L = lateral(st.VR);
    return { L, J: junctionNumbers(Math.max(st.VR, -0.7)), spans: depletedSpans(L.g, L.s, 0.5) };
  },
  scene(S, st) { return shiftY(this.sceneFull(S, st), -26); },
  sceneFull(S, st) {
    const { g, s } = S.L;
    const at = (nm, arr) => interp(g.x, arr, nm);
    const span = S.spans.find((sp) => sp[0] < XJ && sp[1] > XJ) || [XJ, XJ];
    const dl = toW(span[0]), dr = toW(span[1]);
    const pMid = at((LPP + span[0]) / 2, s.p), nMid = at((span[1] + LPP + LP + LN) / 2, s.n);
    const injN = at(LPP + LP * 0.6, s.n), injP = at(LPP + LP + LN * 0.4, s.p);
    const zones = [
      { id: "pp", type: "h", x: X0, y: 60, w: LPP / NM, h: 10, dens: 1, jit: 0.2 },
      { id: "p1", type: "h", x: toW(LPP), y: 60, w: Math.max(0.5, dl - toW(LPP)), h: 10, dens: visDensity(pMid, 14, 19), jit: 0.2 },
      { id: "p2", type: "h", x: 75, y: 48, w: Math.max(0.5, Math.min(dl, 125) - 75), h: 12, dens: visDensity(pMid, 14, 19), jit: 0.2 },
      { id: "n1", type: "e", x: dr, y: 60, w: Math.max(0.5, toW(LPP + LP + LN) - dr), h: 10, dens: visDensity(nMid, 14, 19), jit: 0.2 },
      { id: "n2", type: "e", x: Math.max(dr, 75), y: 48, w: Math.max(0.5, 125 - Math.max(dr, 75)), h: 12, dens: visDensity(nMid, 14, 19), jit: 0.2 },
      { id: "nn", type: "e", x: toW(LPP + LP + LN), y: 60, w: LNP / NM, h: 10, dens: 1, jit: 0.2 },
    ];
    if (st.VR < -0.3) { // injected minority carriers under forward bias
      zones.push({ id: "inj-e", type: "e", x: toW(LPP), y: 50, w: LP / NM, h: 20, dens: visDensity(injN, 14, 19) * 0.8, vx: -6, jit: 0.25 });
      zones.push({ id: "inj-h", type: "h", x: toW(LPP + LP), y: 50, w: LN / NM, h: 20, dens: visDensity(injP, 14, 19) * 0.8, vx: 6, jit: 0.25 });
    }
    const depl = dr - dl > 0.6 ? [{ x: dl, y: 60, w: dr - dl, h: 10 }, { x: Math.max(dl, 75), y: 48, w: Math.max(0, Math.min(dr, 125) - Math.max(dl, 75)), h: 12 }] : [];
    const ions = dr - dl > 0.6 ? [{ x: dl, y: 49, w: toW(XJ) - dl, h: 20, sign: -1, dens: 0.8 }, { x: toW(XJ), y: 49, w: dr - toW(XJ), h: 20, sign: 1, dens: 0.8 }] : [];
    return {
      regions: [
        { x: 0, y: 0, w: 200, h: 70, mat: "clad" },
        { x: 0, y: 70, w: 200, h: 30, mat: "box" },
        { x: X0, y: 60, w: LPP / NM, h: 10, mat: "si", dop: "p+" },
        { x: toW(LPP), y: 60, w: LP / NM, h: 10, mat: "si", dop: "p" },
        { x: toW(XJ), y: 60, w: LN / NM, h: 10, mat: "si", dop: "n" },
        { x: toW(LPP + LP + LN), y: 60, w: LNP / NM, h: 10, mat: "si", dop: "n+" },
        { x: 75, y: 48, w: 25, h: 12, mat: "si", dop: "p" },
        { x: 100, y: 48, w: 25, h: 12, mat: "si", dop: "n" },
        { x: 13, y: 22, w: 14, h: 38, mat: "metal" }, { x: 173, y: 22, w: 14, h: 38, mat: "metal" },
      ],
      glows: st.light ? [{ cx: 100, cy: 58, rx: 30, ry: 11, color: "opt", a: 0.55 }] : [],
      depl, ions, zones,
      labels: [
        { x: 87, y: 44, text: "p", bold: true }, { x: 113, y: 44, text: "n", bold: true },
        { x: 20, y: 76, text: "p⁺", bold: true }, { x: 180, y: 76, text: "n⁺", bold: true },
        { x: 100, y: 84, text: "buried oxide", color: "muted", size: 10 }, { x: 55, y: 34, text: "oxide cladding", color: "muted", size: 10 },
        ...(st.light ? [{ x: 100, y: 36, text: "optical mode", color: "opt", size: 10 }] : []),
      ],
      terminals: [{ x: 20, y: 31, text: "p 0 V" }, { x: 180, y: 31, text: `n ${f(st.VR, 2)} V` }],
    };
  },
  bands(S) {
    const { g, s } = S.L;
    return { x: s.x, Ec: s.Ec, Ev: s.Ev, EFn: s.EFn, EFp: s.EFp, n: s.n, p: s.p, E: s.E, Nabs: map(g.N, Math.abs),
      regions: [{ x0: 0, x1: LPP, label: "p⁺" }, { x0: LPP, x1: XJ, label: "p" }, { x0: XJ, x1: XJ + LN, label: "n" }, { x0: XJ + LN, x1: XJ + LN + LNP, label: "n⁺" }], xlabel: "position across rib (nm)" };
  },
  readouts(S, st) {
    const J = S.J;
    return [["Built-in V_bi", f(J.Vbi, 3) + " V"], ["Depletion width W", J.W.toFixed(0) + " nm"], ["Δn_eff vs 0 V", J.dneff.toExponential(2)],
      ["Phase shift, 3 mm arm", f(J.dphi / PI, 3) + " π rad"], ["V_πL (single arm)", st.VR > 0.1 ? ((PI / Math.abs(J.dphi)) * st.VR * 0.3).toFixed(2) + " V·cm" : "—"]];
  },
  foot: "Lateral 1D Poisson across the rib (p⁺ 10²⁰ | p 5×10¹⁷ | n 5×10¹⁷ | n⁺ 10²⁰ cm⁻³) with quasi-Fermi levels pinned at the contacts. Index change from the Soref–Bennett plasma-dispersion fit at 1550 nm with a 0.7 mode overlap. Illustrative values.",
};

// ---------- bench (ported from the SiPh MZM test bench) ----------
const M = { Vbi: 0.8, K: 1.75, r: 0.52, ILc: 4, Resp: 0.9, Rs: 30, Cj0: 300 };
const phiJ = (v) => { v = Math.max(v, -0.7); return M.K * (Math.sqrt(M.Vbi + v) - Math.sqrt(M.Vbi)); };
const tJ = (v) => { const vv = Math.max(v, -0.7); let dB = 3 - 0.35 * (Math.sqrt(M.Vbi + vv) - Math.sqrt(M.Vbi)); if (v < 0) dB += 6 * -v; return Math.pow(10, -dB / 20); };
const Cj = (VR) => M.Cj0 / Math.sqrt(1 + Math.max(VR, -0.5) / M.Vbi);
const sr = Math.sqrt(M.r), sr2 = Math.sqrt(1 - M.r);
const BITS = (() => { let s = 0x7f; const b = []; for (let i = 0; i < 127; i++) { const n = ((s >> 6) ^ (s >> 5)) & 1; s = ((s << 1) | n) & 0x7f; b.push(n); } return b; })();
let seed = 1;
const rnd = () => ((seed = (seed * 1664525 + 1013904223) >>> 0) / 4294967296);
const gauss = () => { let u = 0; while (!u) u = rnd(); return Math.sqrt(-2 * Math.log(u)) * Math.cos(2 * PI * rnd()); };
function power(v1, v2, phB, Pin) {
  const a1 = sr * tJ(v1), a2 = sr2 * tJ(v2), p1 = phiJ(v1) + phB, p2 = phiJ(v2);
  const er = sr * a1 * Math.cos(p1) + sr2 * a2 * Math.cos(p2), ei = sr * a1 * Math.sin(p1) + sr2 * a2 * Math.sin(p2);
  return Pin * (er * er + ei * ei);
}

const bench = {
  intro: "A laser feeds the MZM; an RF driver pushes +v_RF into arm 1 and −v_RF into arm 2 on top of a shared reverse bias; a heater sets the static phase. Follow the signal from laser to scope.",
  animated: true,
  controls: [
    { label: "Laser", color: "opt", items: [{ id: "Plas", label: "Output power", min: 1, max: 20, step: 0.5, value: 10, fmt: (v) => v.toFixed(1) + " mW" }, { type: "note", text: "λ = 1550 nm, CW, TE" }] },
    { label: "RF source / driver", color: "rf", items: [{ id: "mode", type: "seg", options: [["nrz", "NRZ PRBS7"], ["sine", "Sine"]], value: "nrz" }, { id: "rate", label: "Bit rate / frequency", min: 1, max: 56, step: 1, value: 25, fmt: (v, st) => v + (st.mode === "nrz" ? " Gb/s" : " GHz") }, { id: "vpp", label: "Swing per arm (Vpp)", min: 0, max: 6, step: 0.1, value: 2, fmt: (v) => v.toFixed(1) + " Vpp" }] },
    { label: "DC supply (junctions)", color: "dc", items: [{ id: "VR", label: "Reverse bias V_R", min: 0, max: 5, step: 0.1, value: 2, fmt: (v) => v.toFixed(1) + " V" }] },
    { label: "Heater (static phase)", color: "heat", items: [{ id: "phB", label: "Bias phase φ_h + φ₀", min: 0, max: 2, step: 0.01, value: 0.5, fmt: (v) => v.toFixed(2) + " π" }, { type: "note", text: "0.5π = quadrature, 1π = null" }] },
  ],
  presets: [
    { label: "25 Gb/s NRZ at quadrature", set: { mode: "nrz", rate: 25, vpp: 2, VR: 2, phB: 0.5, Plas: 10 } },
    { label: "Null bias, 5 GHz sine (frequency doubling)", set: { mode: "sine", rate: 5, vpp: 3, VR: 2, phB: 1, Plas: 10 } },
    { label: "Forward-bias fault", set: { mode: "nrz", rate: 25, vpp: 5, VR: 0.5, phB: 0.5 } },
    { label: "56 Gb/s: RC limit", set: { mode: "nrz", rate: 56, vpp: 2, VR: 0.5, phB: 0.5 } },
  ],
  schematic: {
    viewBox: "0 0 1000 420",
    svg: `
  <rect class="die" x="190" y="150" width="610" height="230" rx="10"/><text class="cap" x="204" y="170">SiPh die</text>
  <rect class="bx" x="20" y="232" width="120" height="56" rx="5"/><text class="lb" x="80" y="256" text-anchor="middle">Laser</text><text class="sub" x="80" y="275" text-anchor="middle">1550 nm CW</text>
  <path class="o" d="M140,260 H210"/>
  <path class="o" d="M250,250 C280,250 280,200 310,200 L680,200 C710,200 710,250 740,250"/>
  <path class="o" d="M250,270 C280,270 280,330 310,330 L680,330 C710,330 710,270 740,270"/>
  <path class="o" d="M780,260 H860"/>
  <g><path class="flow" d="M140,260 H210"/><path class="flow" d="M250,250 C280,250 280,200 310,200 L680,200 C710,200 710,250 740,250"/><path class="flow" d="M250,270 C280,270 280,330 310,330 L680,330 C710,330 710,270 740,270"/><path class="flow" d="M780,260 H860"/></g>
  <rect class="mmi" x="210" y="236" width="40" height="48" rx="4"/><text class="sub" x="230" y="264" text-anchor="middle">MMI</text>
  <rect class="mmi" x="740" y="236" width="40" height="48" rx="4"/><text class="sub" x="760" y="264" text-anchor="middle">MMI</text>
  <rect class="pn" data-pn="1" x="340" y="186" width="220" height="28" rx="4"/><text class="lb" x="450" y="205" text-anchor="middle">PN arm 1 (reverse)</text>
  <rect class="pn" data-pn="2" x="340" y="316" width="220" height="28" rx="4"/><text class="lb" x="450" y="335" text-anchor="middle">PN arm 2 (reverse)</text>
  <rect class="ht" x="590" y="188" width="70" height="24" rx="4"/><text class="lb" x="625" y="205" text-anchor="middle">Heater</text>
  <rect class="bx" x="860" y="232" width="120" height="56" rx="5"/><text class="lb" x="920" y="256" text-anchor="middle">PD + scope</text><text class="sub" x="920" y="275" text-anchor="middle">0.9 A/W</text>
  <rect class="bx" x="300" y="30" width="130" height="50" rx="5"/><text class="lb" x="365" y="52" text-anchor="middle">RF driver</text><text class="sub" x="365" y="70" text-anchor="middle">± outputs</text>
  <rect class="bx" x="470" y="30" width="130" height="50" rx="5"/><text class="lb" x="535" y="52" text-anchor="middle">DC supply</text><text class="sub" x="535" y="70" text-anchor="middle">−V_R</text>
  <rect class="bx chip" x="390" y="110" width="110" height="30" rx="4"/><text class="lb" x="445" y="130" text-anchor="middle">Bias-tees</text>
  <path class="rf" d="M365,80 V125 H390"/><path class="dc" d="M535,80 V125 H500"/>
  <path class="mix" d="M445,140 V186"/><path class="mix" d="M520,140 V170 H580 V395 H450 V344"/>
  <rect class="bx" x="640" y="30" width="110" height="50" rx="5"/><text class="lb" x="695" y="52" text-anchor="middle">Heater supply</text><text class="sub" x="695" y="70" text-anchor="middle">sets φ_h</text>
  <path class="th" d="M695,80 V160 H625 V188"/>
  <text class="cap" x="20" y="400">Push-pull: arm 1 gets +v_RF, arm 2 gets −v_RF, both on the same −V_R.</text>`,
  },
  tps: [{ n: 1, x: 175, y: 260, label: "laser output" }, { n: 2, x: 365, y: 100, label: "RF driver output" }, { n: 3, x: 445, y: 165, label: "PN arm 1 voltage" }, { n: 4, x: 575, y: 265, label: "arm phases" }, { n: 5, x: 820, y: 260, label: "MZM optical output" }, { n: 6, x: 920, y: 305, label: "scope" }],
  sections: [{ k: "sig", t: "Signal path", n: "Laser → driver → junction → phase → intensity → receiver." }, { k: "ana", t: "Device curves", n: "The two non-linear laws that set the modulator's behaviour." }],
  cards: [
    { id: "tp1", tp: 1, s: "sig", d: "opt", dn: "optical", t: "Laser output", x: "CW carrier into the input coupler: flat power with a little intensity noise.", eq: "E<sub>L</sub>(t) = <span class=\"rt\">√</span><span class=\"rad\">P<sub>L</sub></span>·cos(ωt),&nbsp; ω = 2πc/λ" },
    { id: "tp2", tp: 2, s: "sig", d: "rf", dn: "RF", t: "RF driver output", x: "Differential drive: solid = + output to arm 1, dashed = − output to arm 2.", eq: "v<sub>RF±</sub>(t) = ±(V<sub>pp</sub>/2)·s(t),&nbsp; s = ±1 (NRZ) or sin(2πft)" },
    { id: "tp3", tp: 3, s: "sig", d: "ph", dn: "DC + RF", t: "PN junction voltage, arm 1", x: "Bias-tee output: −V_R plus the RF, low-pass filtered by the junction RC. It must stay below 0 V (reverse).", eq: "V<sub>PN1</sub>(t) = −V<sub>R</sub> − [v<sub>RF</sub> ∗ h<sub>RC</sub>](t),&nbsp; τ = R<sub>s</sub>C<sub>j</sub>" },
    { id: "tp4", tp: 4, s: "sig", d: "ph", dn: "phase", t: "Arm phases and Δφ", x: "Each arm's phase follows the √ depletion law; the combiner only cares about the difference Δφ (bold).", eq: "φ<sub>i</sub> = K[<span class=\"rt\">√</span><span class=\"rad\">V<sub>bi</sub>+V<sub>Ri</sub></span> − <span class=\"rt\">√</span><span class=\"rad\">V<sub>bi</sub></span>],&nbsp; Δφ = φ<sub>1</sub> − φ<sub>2</sub> + φ<sub>bias</sub>" },
    { id: "tp5", tp: 5, s: "sig", d: "opt", dn: "optical", t: "MZM optical output", x: "Interference turns phase into intensity: P = |E₁ + E₂|².", eq: "P<sub>out</sub> ≈ P<sub>max</sub>·cos²(Δφ/2)" },
    { id: "tp6", tp: 6, s: "sig", d: "opt", dn: "instrument", t: "Photodiode + oscilloscope", x: "Eye diagram for NRZ, waveform for sine, with receiver noise.", eq: "ER = 10·log(P<sub>1</sub>/P<sub>0</sub>),&nbsp; Q = (P<sub>1</sub> − P<sub>0</sub>)/(σ<sub>1</sub> + σ<sub>0</sub>)", h: "tall" },
    { id: "atr", chip: "P–Δφ", s: "ana", d: "an", dn: "static", t: "Transfer curve", x: "The cos² curve with the operating point and the RF excursion mapped onto it. Quadrature (0.5π) is the most linear point.", eq: "P(Δφ) = P<sub>in</sub>·|√r·t<sub>1</sub>e<sup>jΔφ</sup> + √(1−r)·t<sub>2</sub>|²" },
    { id: "aphv", chip: "φ–V", s: "ana", d: "an", dn: "junction", t: "Phase law and bandwidth", x: "Sub-linear depletion phase law with the arm-1 swing. Higher V_R: less efficient (larger V_π) but less capacitance (faster).", eq: "dφ/dV = K/(2<span class=\"rt\">√</span><span class=\"rad\">V<sub>bi</sub>+V<sub>R</sub></span>),&nbsp; f<sub>RC</sub> = 1/(2πR<sub>s</sub>C<sub>j</sub>)" },
  ],
  foot: "Model: φ = K(√(V_bi+V_R) − √V_bi), K = 1.75 rad/√V per 3 mm arm, V_bi = 0.8 V; C_j = 300 fF/√(1+V_R/V_bi) with a 30 Ω source (first-order RC); 52/48 MMI split; 4 dB coupling loss + 3 dB junction loss; PD 0.9 A/W. Velocity mismatch, heater dynamics and chirp are not modelled. Values are illustrative.",
  sim(st) {
    seed = 12345;
    const R = {};
    const Pin = st.Plas * Math.pow(10, -M.ILc / 10);
    const phB = st.phB * PI;
    const cj = Cj(st.VR), tau = M.Rs * cj * 1e-6; // ns
    R.bw = 1 / (2 * PI * tau);
    const spb = 24;
    let N, dt;
    if (st.mode === "nrz") { N = BITS.length * spb; dt = 1 / (st.rate * spb); R.W = 16 * spb; }
    else { N = 720; dt = 3 / st.rate / N; R.W = N; }
    const t = new Float64Array(N), raw = new Float64Array(N), xf = new Float64Array(N);
    for (let i = 0; i < N; i++) { t[i] = i * dt; raw[i] = st.mode === "nrz" ? (BITS[Math.floor(i / spb)] ? 1 : -1) : Math.sin(2 * PI * st.rate * t[i]); }
    const a = 1 - Math.exp(-dt / tau);
    let y = raw[N - 1];
    for (let p = 0; p < 2; p++) for (let i = 0; i < N; i++) { y += (raw[i] - y) * a; xf[i] = y; }
    const h = st.vpp / 2;
    const A = () => new Float64Array(N);
    const v1 = A(), v2 = A(), f1 = A(), f2 = A(), dph = A(), P = A(), Pn = A(), las = A();
    let sP = 0, vmin = 1e9;
    const sig = 0.012 * Pin + 0.004;
    for (let i = 0; i < N; i++) {
      const a1 = st.VR + xf[i] * h, a2 = st.VR - xf[i] * h;
      v1[i] = -a1; v2[i] = -a2;
      f1[i] = phiJ(a1); f2[i] = phiJ(a2); dph[i] = (f1[i] - f2[i] + phB) / PI;
      P[i] = power(a1, a2, phB, Pin); Pn[i] = P[i] + sig * gauss();
      las[i] = st.Plas * (1 + 0.004 * gauss());
      sP += P[i]; vmin = Math.min(vmin, a1, a2);
    }
    Object.assign(R, { t, raw, xf, v1, v2, f1, f2, dph, P, Pn, las, N, spb, Pin, phB, cj });
    R.avgP = sP / N; R.fwd = vmin < 0;
    let mx = -1, mn = 1e9;
    R.tr = linspace(0, 2, 241);
    R.trP = map(R.tr, (q) => { const p = power(st.VR, st.VR, q * PI, Pin); mx = Math.max(mx, p); mn = Math.min(mn, p); return p; });
    R.ER = 10 * Math.log10(mx / mn); R.IL = -10 * Math.log10(mx / st.Plas);
    R.slope = M.K / (2 * Math.sqrt(M.Vbi + st.VR)); R.Vpi = PI / R.slope;
    if (st.mode === "nrz") {
      let best = -1e9, bp = spb - 1, pol = 1;
      for (let p = 0; p < spb; p++) { let s1 = 0, n1 = 0, s0 = 0, n0 = 0; for (let k = 2; k < BITS.length - 1; k++) { const v = Pn[k * spb + p]; if (BITS[k]) { s1 += v; n1++; } else { s0 += v; n0++; } } const d = Math.abs(s1 / n1 - s0 / n0); if (d > best) { best = d; bp = p; pol = s1 / n1 > s0 / n0 ? 1 : -1; } }
      const ones = [], zeros = [], segs = [];
      for (let k = 2; k < BITS.length - 2; k++) {
        const c = k * spb + bp; (BITS[k] ? ones : zeros).push(Pn[c]);
        const i0 = c - Math.round(spb / 2); const xs = [], ys = [];
        for (let i = i0; i <= i0 + 2 * spb && i < N; i++) { xs.push((i - i0) / spb); ys.push(Pn[i]); }
        segs.push([xs, ys]);
      }
      const mean = (q) => q.reduce((s, v) => s + v, 0) / q.length, sd = (q, m) => Math.sqrt(q.reduce((s, v) => s + (v - m) * (v - m), 0) / q.length);
      let hi = ones, lo = zeros; if (pol < 0) { hi = zeros; lo = ones; }
      const mh = mean(hi), ml = mean(lo), sh = sd(hi, mh), sl = sd(lo, ml);
      R.eye = { segs, mh, ml, Q: (mh - ml) / (sh + sl), ERd: 10 * Math.log10(mh / Math.max(ml, 1e-4)), EH: Math.min(...hi) - Math.max(...lo), inv: pol < 0 };
    } else {
      const amp = (k) => { let re = 0, im = 0; for (let i = 0; i < N; i++) { const w = 2 * PI * k * st.rate * t[i]; re += P[i] * Math.cos(w); im += P[i] * Math.sin(w); } return (2 * Math.hypot(re, im)) / N; };
      R.h1 = amp(1); R.h2 = amp(2);
    }
    R.vr = linspace(-0.5, 5.5, 121); R.ph = map(R.vr, (v) => phiJ(v));
    return R;
  },
  render(R, api) {
    const { st, C } = api;
    const W = R.W, tw = R.t.subarray(0, W), xmax = tw[W - 1], cur = (api.frame * 5) % W, tc = tw[cur];
    const sub = (a) => a.subarray(0, W);
    api.status([
      ["Operating point", st.phB > 0.45 && st.phB < 0.55 || st.phB > 1.45 && st.phB < 1.55 ? "Quadrature" : Math.abs(st.phB - 1) < 0.05 ? "Null" : st.phB < 0.05 || st.phB > 1.95 ? "Peak" : st.phB.toFixed(2) + "π", ""],
      ["Junctions", R.fwd ? "Forward excursion!" : "Reverse-biased", R.fwd ? "warn" : "good"],
      ["RC bandwidth", R.bw.toFixed(1) + " GHz", R.bw < st.rate * 0.6 ? "warn" : ""],
      ["V_π single arm", R.Vpi.toFixed(2) + " V", ""],
      ["Static ER / IL", R.ER.toFixed(1) + " dB / " + R.IL.toFixed(1) + " dB", ""],
      [st.mode === "nrz" ? "Eye Q-factor" : "2f / 1f", st.mode === "nrz" ? R.eye.Q.toFixed(1) : (R.h2 / Math.max(R.h1, 1e-9)).toFixed(2), st.mode === "nrz" && R.eye.Q < 4 ? "warn" : ""],
    ]);
    api.qa(".pn").forEach((el) => el.classList.toggle("fault", R.fwd));
    const tl = "time (ns)";
    api.plot("tp1", { xmin: 0, xmax, ymin: 0, ymax: st.Plas * 1.3, xlabel: tl, ylabel: "P (mW)", series: [{ x: tw, y: sub(R.las), color: C.opt, w: 1.6 }], cursor: tc });
    api.ro("tp1", [["Power", st.Plas.toFixed(1) + " mW"], ["Power", (10 * Math.log10(st.Plas)).toFixed(1) + " dBm"], ["After coupler", R.Pin.toFixed(2) + " mW"]]);
    const lim = Math.max(0.6, (st.vpp / 2) * 1.35);
    api.plot("tp2", { xmin: 0, xmax, ymin: -lim, ymax: lim, xlabel: tl, ylabel: "v_RF (V)", series: [{ x: tw, y: map(sub(R.raw), (v) => -v * st.vpp / 2), color: C.rf, w: 1.4, dash: [4, 3], alpha: 0.6 }, { x: tw, y: map(sub(R.raw), (v) => v * st.vpp / 2), color: C.rf, w: 1.8 }], cursor: tc });
    api.ro("tp2", [["Waveform", st.mode === "nrz" ? "NRZ PRBS7" : "Sine"], [st.mode === "nrz" ? "Bit rate" : "Frequency", st.rate + (st.mode === "nrz" ? " Gb/s" : " GHz")], ["Swing per arm", st.vpp.toFixed(1) + " Vpp"]]);
    api.plot("tp3", { xmin: 0, xmax, ymin: -st.VR - st.vpp / 2 - 0.6, ymax: Math.max(0.6, -st.VR + st.vpp / 2 + 0.4), xlabel: tl, ylabel: "V_PN1 (V)", series: [{ x: tw, y: sub(R.v1), color: C.ph, w: 1.8 }], hlines: [{ y: 0, color: C.bad, dash: [3, 3], label: "0 V: forward above" }, { y: -st.VR, color: C.dc, dash: [2, 3] }], cursor: tc });
    api.eqv("tp3", `C_j(${st.VR.toFixed(1)} V) = ${R.cj.toFixed(0)} fF, τ = ${(M.Rs * R.cj * 1e-3).toFixed(1)} ps, f_RC = ${R.bw.toFixed(1)} GHz`);
    api.ro("tp3", [["DC level", f(-st.VR, 1) + " V"], ["Most positive", f(Math.max(...sub(R.v1)), 2) + " V", R.fwd ? "warn" : ""], ["Bandwidth", R.bw.toFixed(1) + " GHz"]]);
    api.plot("tp4", { xmin: 0, xmax, xlabel: tl, ylabel: "phase (π rad)", series: [{ x: tw, y: map(sub(R.f1), (v) => v / PI), color: C.opt, w: 1.2, alpha: 0.8 }, { x: tw, y: map(sub(R.f2), (v) => v / PI), color: C.opt2, w: 1.2, alpha: 0.8 }, { x: tw, y: sub(R.dph), color: C.ph, w: 2.2 }], cursor: tc });
    api.eqv("tp4", `Δφ(t) at cursor = ${R.dph[cur].toFixed(3)} π`);
    api.ro("tp4", [["φ₁ at V_R", (phiJ(st.VR) / PI).toFixed(3) + " π"], ["Δφ swing", (Math.max(...sub(R.dph)) - Math.min(...sub(R.dph))).toFixed(3) + " π"], ["Bias phase", st.phB.toFixed(2) + " π"]]);
    api.plot("tp5", { xmin: 0, xmax, ymin: 0, xlabel: tl, ylabel: "P_out (mW)", series: [{ x: tw, y: sub(R.P), color: C.opt, w: 1.8, fill: C.opt }], cursor: tc });
    api.ro("tp5", [["Average", R.avgP.toFixed(3) + " mW"], ["Average", (10 * Math.log10(R.avgP)).toFixed(1) + " dBm"], ["Photocurrent", (R.avgP * M.Resp).toFixed(3) + " mA"]]);
    if (st.mode === "nrz") {
      const E = R.eye;
      api.plot("tp6", { xmin: 0, xmax: 2, ymin: 0, xlabel: "time (UI)", ylabel: "P (mW)", series: [{ segs: E.segs, color: C.opt, w: 1, alpha: 0.35 }], hlines: [{ y: E.mh, color: C.ok, dash: [3, 3], label: "P₁" }, { y: E.ml, color: C.bad, dash: [3, 3], label: "P₀" }] });
      api.ro("tp6", [["Q-factor", E.Q.toFixed(1), E.Q < 4 ? "warn" : "good"], ["Dynamic ER", E.ERd.toFixed(1) + " dB"], ["Eye height", (E.EH * 1000).toFixed(0) + " µW", E.EH <= 0 ? "warn" : ""], ["Polarity", E.inv ? "inverted" : "normal"]]);
      api.eqv("tp6", `Q = (${E.mh.toFixed(3)} − ${E.ml.toFixed(3)}) / (σ₁ + σ₀) = ${E.Q.toFixed(1)}`);
    } else {
      api.plot("tp6", { xmin: 0, xmax, ymin: 0, xlabel: tl, ylabel: "P (mW)", series: [{ x: tw, y: sub(R.Pn), color: C.opt, w: 1.2 }], cursor: tc });
      api.ro("tp6", [["1f amplitude", (R.h1 * 1000).toFixed(1) + " µW"], ["2f amplitude", (R.h2 * 1000).toFixed(1) + " µW"], ["2f/1f", (R.h2 / Math.max(R.h1, 1e-9)).toFixed(2)]]);
      api.eqv("tp6", st.phB > 0.9 && st.phB < 1.1 ? "At null the output follows sin²: the optical signal is at twice the RF frequency." : "");
    }
    let lo = Infinity, hi = -Infinity; for (let i = 0; i < W; i++) { lo = Math.min(lo, R.dph[i]); hi = Math.max(hi, R.dph[i]); }
    const dc = st.phB;
    api.plot("atr", { xmin: 0, xmax: 2, ymin: 0, xlabel: "Δφ (π rad)", ylabel: "P_out (mW)", series: [{ x: R.tr, y: R.trP, color: C.ink, w: 1.8 }], vbands: [{ x0: lo, x1: hi, color: C.ph, a: 0.18 }], points: [{ x: dc, y: power(st.VR, st.VR, dc * PI, R.Pin), color: C.ph, label: "bias" }] });
    api.ro("atr", [["Static ER", R.ER.toFixed(1) + " dB"], ["Insertion loss", R.IL.toFixed(1) + " dB"], ["RF excursion", (hi - lo).toFixed(3) + " π"]]);
    const s = R.slope;
    api.plot("aphv", { xmin: -0.5, xmax: 5.5, ymin: 0, xlabel: "V_R (V)", ylabel: "φ (rad)", series: [{ x: R.vr, y: R.ph, color: C.ink, w: 1.8 }, { x: R.vr, y: map(R.vr, (v) => phiJ(st.VR) + s * (v - st.VR)), color: C.ph, w: 1, dash: [4, 3] }], vbands: [{ x0: st.VR - st.vpp / 2, x1: st.VR + st.vpp / 2, color: C.rf, a: 0.15 }], points: [{ x: st.VR, y: phiJ(st.VR), color: C.ph }] });
    api.eqv("aphv", `dφ/dV = ${s.toFixed(3)} rad/V → V_π = ${R.Vpi.toFixed(2)} V; C_j = ${R.cj.toFixed(0)} fF → f_RC = ${R.bw.toFixed(1)} GHz`);
    api.ro("aphv", [["Slope", s.toFixed(3) + " rad/V"], ["V_π (1 arm)", R.Vpi.toFixed(2) + " V"], ["V_πL", (R.Vpi * 0.3).toFixed(2) + " V·cm"], ["C_j", R.cj.toFixed(0) + " fF"]]);
  },
};

export default { atomic, bench };
