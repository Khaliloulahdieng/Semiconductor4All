// Silicon micro-ring modulator: a 5 µm-radius ring with a depletion PN junction, coupled to a bus waveguide.
import { buildGrid, solvePoisson, depletedSpans, interp, visDensity, f, depletionWidth, builtIn } from "../lib/physics.js";
import { map, linspace } from "../lib/plot.js";

const PI = Math.PI, C0 = 3e8;
const LAM0 = 1550.0;     // nm, cold resonance at 0 V, no heater, 25 °C
const QI = 20000;        // intrinsic Q
const DLDV = 60;         // pm per √V unit of depletion (see shift())
const HEAT = 250;        // pm per mW of heater power
const DTHERM = 80;       // pm per K of chip temperature
const RADIUS = 5, NG = 4.2;
const FSR = ((LAM0 * 1e-9) ** 2 / (NG * 2 * PI * RADIUS * 1e-6)) * 1e9; // free spectral range, nm
const shift = (V) => DLDV * (Math.sqrt(0.8 + Math.max(V, -0.7)) - Math.sqrt(0.8)) - (V < 0 ? 300 * -V * -V : 0); // pm; forward bias blue-shifts (injection)
function ring(QL) {
  const Qc = 1 / Math.max(1 / QL - 1 / QI, 1e-7);
  return { QL, Qc, fwhm: (LAM0 / QL) * 1000, tmin: Math.pow((QI - Qc) / (QI + Qc), 2) }; // fwhm in pm
}
const trans = (dpm, R) => 1 - (1 - R.tmin) / (1 + Math.pow((2 * dpm) / R.fwhm, 2)); // through-port vs detuning (pm)

// ---------- atomic: radial PN junction across the ring waveguide ----------
const LN = 650, LP = 650, LPP = 200, LNP = 200, XJ = LNP + LN;
function radial(V) { // n on the outer side (left), p inner (right); V on the n contact = reverse bias
  const g = buildGrid([
    { mat: "Si", t: LNP, N: 1e20, dx: 6, phin: V, phip: 0 },
    { mat: "Si", t: LN, N: 4e17, dx: 4, phin: V, phip: 0 },
    { mat: "Si", t: LP, N: -6e17, dx: 4, phin: V, phip: 0 },
    { mat: "Si", t: LPP, N: -1e20, dx: 6, phin: V, phip: 0 },
  ]);
  return { g, s: solvePoisson(g, { left: { type: "ohmic", V }, right: { type: "ohmic", V: 0 } }) };
}
const X0 = 20, toW = (nm) => X0 + nm / 10;

const atomic = {
  intro: "Cross-section through the ring waveguide, away from the bus coupler. A PN junction runs around the ring: n on the outer edge, p on the inner edge. Reverse bias widens the depletion region inside the optical mode, nudging the refractive index and shifting the ring's sharp resonance. A heater above the ring tunes it thermally. Not to scale vertically.",
  controls: [
    { label: "Junction", color: "dc", items: [{ id: "V", label: "Reverse bias (n side +)", min: -0.8, max: 3, step: 0.05, value: 1, fmt: (v) => f(v, 2) + " V" }] },
    { label: "Heater", color: "heat", items: [{ id: "Ph", label: "Heater power", min: 0, max: 8, step: 0.1, value: 2, fmt: (v) => v.toFixed(1) + " mW" }] },
  ],
  presets: [{ label: "0 V", set: { V: 0 } }, { label: "Reverse 2 V", set: { V: 2 } }, { label: "Forward 0.7 V", set: { V: -0.7 } }, { label: "Heater off", set: { Ph: 0 } }],
  look: [
    "The optical mode (blue glow) sits slightly toward the outer edge of the ring because the waveguide is bent.",
    "Reverse bias widens the depletion region: fewer carriers in the light's path, slightly higher index, so the resonance moves to longer wavelength (red shift).",
    "The heater works the same way but bigger and slower: about 10× more shift per unit than the junction, at microsecond speeds.",
  ],
  legendExtra: '<span><i style="background:var(--heat);opacity:.5"></i>heater hot spot</span>',
  world: { w: 200, h: 64 }, aspect: "25/8", lensAt: [86, 40],
  cuts: [{ id: "rad", label: "Across the ring (n⁺ outer → p⁺ inner)", a: [toW(0), 44], b: [toW(LNP + LN + LP + LPP), 44] }],
  solve(st) {
    const R = radial(st.V);
    const Vbi = builtIn(6e17, 4e17), W = depletionWidth(Vbi + Math.max(st.V, -0.7), 6e17, 4e17);
    const dl = shift(st.V) + HEAT * st.Ph;
    return { R, spans: depletedSpans(R.g, R.s, 0.5), W, dl, T: 25 + st.Ph * 4.8 };
  },
  scene(S, st) {
    const sp = S.spans.find((s) => s[0] < XJ && s[1] > XJ) || [XJ, XJ];
    const dl = toW(sp[0]), dr = toW(sp[1]);
    const rib0 = toW(LNP + LN - 250), rib1 = toW(LNP + LN + 200);
    return {
      regions: [
        { x: 0, y: 0, w: 200, h: 50, mat: "clad" }, { x: 0, y: 50, w: 200, h: 14, mat: "box" },
        { x: toW(0), y: 41, w: LNP / 10, h: 9, mat: "si", dop: "n+" }, { x: toW(LNP), y: 41, w: LN / 10, h: 9, mat: "si", dop: "n" },
        { x: toW(XJ), y: 41, w: LP / 10, h: 9, mat: "si", dop: "p" }, { x: toW(XJ + LP), y: 41, w: LPP / 10, h: 9, mat: "si", dop: "p+" },
        { x: rib0, y: 28, w: toW(XJ) - rib0, h: 13, mat: "si", dop: "n" }, { x: toW(XJ), y: 28, w: rib1 - toW(XJ), h: 13, mat: "si", dop: "p" },
        { x: rib0 - 2, y: 6, w: rib1 - rib0 + 4, h: 4, mat: "metal" },
        { x: toW(10), y: 14, w: 12, h: 27, mat: "metal" }, { x: toW(LNP + LN + LP + 60), y: 14, w: 12, h: 27, mat: "metal" },
      ],
      glows: [{ cx: toW(XJ) - 6, cy: 38, rx: 30, ry: 9, color: "opt", a: 0.55 }, ...(st.Ph > 0 ? [{ cx: (rib0 + rib1) / 2, cy: 10, rx: 30, ry: 12, color: "heat", a: Math.min(0.6, 0.08 * st.Ph) }] : [])],
      depl: dr - dl > 0.6 ? [{ x: dl, y: 41, w: dr - dl, h: 9 }, { x: Math.max(dl, rib0), y: 28, w: Math.max(0, Math.min(dr, rib1) - Math.max(dl, rib0)), h: 13 }] : [],
      ions: dr - dl > 0.6 ? [{ x: dl, y: 29, w: toW(XJ) - dl, h: 20, sign: 1, dens: 0.7 }, { x: toW(XJ), y: 29, w: dr - toW(XJ), h: 20, sign: -1, dens: 0.8 }] : [],
      zones: [
        { id: "nn", type: "e", x: toW(0), y: 41, w: LNP / 10, h: 9, dens: 1 }, { id: "n1", type: "e", x: toW(LNP), y: 41, w: Math.max(0.5, dl - toW(LNP)), h: 9, dens: 0.7 },
        { id: "n2", type: "e", x: rib0, y: 28, w: Math.max(0.5, Math.min(dl, rib1) - rib0), h: 13, dens: 0.7 },
        { id: "p1", type: "h", x: dr, y: 41, w: Math.max(0.5, toW(XJ + LP) - dr), h: 9, dens: 0.75 }, { id: "p2", type: "h", x: Math.max(dr, rib0), y: 28, w: Math.max(0.5, rib1 - Math.max(dr, rib0)), h: 13, dens: 0.75 },
        { id: "pp", type: "h", x: toW(XJ + LP), y: 41, w: LPP / 10, h: 9, dens: 1 },
        ...(st.V < -0.3 ? [{ id: "inj", type: "e", x: toW(XJ), y: 30, w: 30, h: 18, dens: 0.5, vx: 6 }, { id: "injh", type: "h", x: toW(XJ) - 30, y: 30, w: 30, h: 18, dens: 0.5, vx: -6 }] : []),
      ],
      labels: [{ x: (rib0 + rib1) / 2, y: 3, text: "TiN heater", size: 9 }, { x: toW(XJ) - 18, y: 24, text: "n (outer)", size: 9 }, { x: toW(XJ) + 18, y: 24, text: "p (inner)", size: 9 }, { x: 100, y: 58, text: "buried oxide", size: 9, color: "muted" }, { x: 10, y: 30, text: "← ring outside", size: 8, color: "muted", align: "left" }],
      terminals: [{ x: toW(16), y: 8, text: `n ${f(st.V, 2)} V` }, { x: toW(LNP + LN + LP + 66), y: 8, text: "p 0 V" }],
    };
  },
  bands(S) {
    const { g, s } = S.R;
    return { x: s.x, Ec: s.Ec, Ev: s.Ev, EFn: s.EFn, EFp: s.EFp, n: s.n, p: s.p, E: s.E, Nabs: map(g.N, Math.abs), regions: [{ x0: 0, x1: LNP, label: "n⁺" }, { x0: LNP, x1: XJ, label: "n" }, { x0: XJ, x1: XJ + LP, label: "p" }, { x0: XJ + LP, x1: XJ + LP + LPP, label: "p⁺" }], xlabel: "radial position (nm)" };
  },
  readouts(S, st) {
    return [["Depletion width", S.W.toFixed(0) + " nm"], ["Junction shift", f(shift(st.V), 1) + " pm"], ["Heater shift", (HEAT * st.Ph).toFixed(0) + " pm"], ["Ring temperature rise", "+" + (S.T - 25).toFixed(1) + " K"], ["Resonance", (LAM0 + S.dl / 1000).toFixed(3) + " nm"]];
  },
  foot: "1D Poisson across the ring (n⁺ | n 4×10¹⁷ | p 6×10¹⁷ | p⁺). Resonance shift from the depletion law Δλ ∝ √(V_bi+V) − √V_bi (≈ 30 pm/V near 1 V), heater 0.25 nm/mW. Mode offset toward the outer edge drawn qualitatively. Illustrative values.",
};

// ---------- bench ----------
const BITS = (() => { let s = 0x7f; const b = []; for (let i = 0; i < 127; i++) { const n = ((s >> 6) ^ (s >> 5)) & 1; s = ((s << 1) | n) & 0x7f; b.push(n); } return b; })();
let seed = 1;
const rnd = () => ((seed = (seed * 1664525 + 1013904223) >>> 0) / 4294967296);
const gauss = () => { let u = 0; while (!u) u = rnd(); return Math.sqrt(-2 * Math.log(u)) * Math.cos(2 * PI * rnd()); };

const bench = {
  intro: "A tunable laser sends light along the bus waveguide past the ring. When the laser sits on the ring's resonance, light is trapped and lost in the ring and the through-port goes dark. The driver wiggles the resonance back and forth across the laser line, so the output flickers with the data.",
  animated: true,
  controls: [
    { label: "Laser (TP1)", color: "opt", items: [{ id: "det", label: "Laser − cold resonance", min: -200, max: 500, step: 2, value: 330, fmt: (v) => v + " pm" }, { id: "P", label: "Power in bus", min: 0.2, max: 2, step: 0.1, value: 1, fmt: (v) => v.toFixed(1) + " mW" }] },
    { label: "Driver (TP2)", color: "rf", items: [{ id: "VR", label: "DC reverse bias", min: 0, max: 3, step: 0.1, value: 1.5, fmt: (v) => v.toFixed(1) + " V" }, { id: "vpp", label: "Swing (Vpp)", min: 0, max: 3, step: 0.1, value: 2, fmt: (v) => v.toFixed(1) + " Vpp" }, { id: "rate", label: "Bit rate", min: 5, max: 60, step: 1, value: 25, fmt: (v) => v + " Gb/s" }] },
    { label: "Ring", color: "ph", items: [{ id: "QL", label: "Loaded Q (set by the coupling gap)", min: 2500, max: 15000, step: 250, value: 9000, fmt: (v) => v.toFixed(0) }] },
    { label: "Heater and chip (A2)", color: "heat", items: [{ id: "Ph", label: "Heater power", min: 0, max: 6, step: 0.05, value: 1, fmt: (v) => v.toFixed(2) + " mW" }, { id: "dT", label: "Chip temperature drift", min: -10, max: 10, step: 0.5, value: 0, fmt: (v) => f(v, 1) + " K" }] },
  ],
  presets: [
    { label: "25 Gb/s, on the slope", set: { det: 330, VR: 1.5, vpp: 2, rate: 25, QL: 9000, Ph: 1, dT: 0 } },
    { label: "Laser on resonance (bad)", set: { det: 285, Ph: 1.0, vpp: 2 } },
    { label: "High Q 15k at 50 Gb/s", set: { QL: 15000, rate: 50 } },
    { label: "Chip heated +5 K", set: { dT: 5 } },
  ],
  schematic: {
    viewBox: "0 0 960 330",
    svg: `
  <rect class="bx" x="20" y="200" width="130" height="56" rx="5"/><text class="lb" x="85" y="224" text-anchor="middle">Tunable laser</text><text class="sub" x="85" y="243" text-anchor="middle">λ_laser</text>
  <path class="o" d="M150,228 H800"/><path class="flow" d="M150,228 H800"/>
  <rect class="die" x="200" y="40" width="560" height="250" rx="10"/><text class="cap" x="212" y="60">SiPh die</text>
  <circle class="ring" cx="480" cy="140" r="80" fill="none" stroke="var(--opt)" stroke-width="4"/>
  <circle cx="480" cy="140" r="86" fill="none" stroke="var(--rf)" stroke-width="2" stroke-dasharray="6 4"/>
  <circle cx="480" cy="140" r="70" fill="none" stroke="var(--heat)" stroke-width="2" opacity=".6"/>
  <text class="lb" x="480" y="135" text-anchor="middle">ring, R = 5 µm</text><text class="sub ringtxt" x="480" y="153" text-anchor="middle"></text>
  <rect class="bx" x="270" y="60" width="120" height="44" rx="5"/><text class="lb" x="330" y="87" text-anchor="middle">RF driver</text>
  <path class="rf" d="M390,82 H420"/>
  <rect class="bx" x="590" y="60" width="140" height="44" rx="5"/><text class="lb" x="660" y="87" text-anchor="middle">Heater supply</text>
  <path class="th" d="M590,82 H560"/>
  <rect class="bx" x="800" y="200" width="140" height="56" rx="5"/><text class="lb" x="870" y="224" text-anchor="middle">PD + scope</text><text class="sub" x="870" y="243" text-anchor="middle">through port</text>
  <text class="cap" x="420" y="275">bus waveguide (gap ≈ 200 nm sets the coupling)</text>`,
  },
  tps: [{ n: 1, x: 180, y: 228, label: "laser line" }, { n: 2, x: 405, y: 82, label: "ring junction drive" }, { n: 3, x: 480, y: 228, label: "ring spectrum" }, { n: 4, x: 780, y: 228, label: "through-port power" }, { n: 5, x: 870, y: 272, label: "eye" }],
  sections: [{ k: "sig", t: "Signal path", n: "" }, { k: "ana", t: "Design trade-offs", n: "Q, speed and temperature." }],
  cards: [
    { id: "tp1", tp: 1, s: "sig", d: "opt", dn: "optical", t: "Laser and resonance positions", x: "Where the laser line sits relative to the ring's resonances (one free spectral range shown).", eq: "λ<sub>res</sub> = n<sub>eff</sub>·2πR/m,&nbsp; FSR = λ²/(n<sub>g</sub>·2πR) ≈ " + FSR.toFixed(1) + " nm" },
    { id: "tp2", tp: 2, s: "sig", d: "rf", dn: "RF", t: "Junction voltage and resonance shift", x: "Reverse voltage on the junction (RC-filtered NRZ) and the resonance shift it causes.", eq: "Δλ<sub>res</sub>(t) ∝ <span class=\"rt\">√</span><span class=\"rad\">V<sub>bi</sub> + V(t)</span> − <span class=\"rt\">√</span><span class=\"rad\">V<sub>bi</sub></span>" },
    { id: "tp3", tp: 3, s: "sig", d: "ph", dn: "spectral", t: "Through-port spectrum", x: "Transmission near resonance for the two drive levels ('0' and '1'). The vertical line is the laser: the vertical gap between the curves at the laser is the modulation.", eq: "T(δ) = 1 − (1 − T<sub>min</sub>)/(1 + (2δ/Δλ<sub>FWHM</sub>)²),&nbsp; Δλ<sub>FWHM</sub> = λ/Q<sub>L</sub>", h: "tall" },
    { id: "tp4", tp: 4, s: "sig", d: "opt", dn: "optical", t: "Through-port power", x: "Optical power after the ring: the photon lifetime of the ring low-pass filters the modulation.", eq: "τ<sub>ph</sub> = Q<sub>L</sub>λ/(2πc),&nbsp; f<sub>opt</sub> ≈ 1/(2πτ<sub>ph</sub>)" },
    { id: "tp5", tp: 5, s: "sig", d: "opt", dn: "instrument", t: "Eye diagram", x: "Received eye with detector noise.", eq: "ER = P<sub>1</sub>/P<sub>0</sub>,&nbsp; OMA = P<sub>1</sub> − P<sub>0</sub>", h: "tall" },
    { id: "a1", chip: "Q", s: "ana", d: "an", dn: "trade-off", t: "Q: modulation depth vs optical bandwidth", x: "A sharper resonance (high Q) converts a tiny shift into a big power change but stores photons longer, limiting speed.", eq: "OMA ↑ with Q,&nbsp; f<sub>opt</sub> = c/(λQ<sub>L</sub>)" },
    { id: "a2", chip: "°C", s: "ana", d: "an", dn: "thermal", t: "Thermal tuning and drift", x: "Resonance vs heater power; dashed lines show ±5 K of chip temperature drift (80 pm/K). The ring must be kept locked to the laser.", eq: "Δλ = 0.25 nm/mW·P<sub>heater</sub> + 80 pm/K·ΔT" },
  ],
  foot: "Model: all-pass ring, intrinsic Q 20 000, loaded Q set by coupling, depletion shift ≈ 30 pm/V, junction RC 25 GHz, photon lifetime as a first-order filter, heater 0.25 nm/mW, 80 pm/K, PD noise 1 % of P. Illustrative values.",
  sim(st) {
    seed = 7;
    const R = { ring: ring(st.QL) };
    const base = HEAT * st.Ph + DTHERM * st.dT; // pm
    const res = (V) => base + shift(V);
    R.res0 = res(st.VR + st.vpp / 2); R.res1 = res(st.VR - st.vpp / 2); // '0' bit at higher reverse V (resonance redder)
    R.d = linspace(-400, 900, 521);
    R.Ta = map(R.d, (x) => trans(x - R.res0, R.ring)); R.Tb = map(R.d, (x) => trans(x - R.res1, R.ring));
    const spb = 24, N = BITS.length * spb, dt = 1 / (st.rate * spb); // ns
    const tauRC = 1 / (2 * PI * 25), tauPh = (st.QL * LAM0 * 1e-9) / (2 * PI * C0) * 1e9;
    const aRC = 1 - Math.exp(-dt / tauRC), aPh = 1 - Math.exp(-dt / tauPh);
    const t = new Float64Array(N), v = new Float64Array(N), dl = new Float64Array(N), P = new Float64Array(N), Pn = new Float64Array(N);
    let y = st.VR, p = 0.5;
    for (let pass = 0; pass < 2; pass++) for (let i = 0; i < N; i++) {
      const raw = st.VR + (BITS[Math.floor(i / spb)] ? -1 : 1) * st.vpp / 2;
      y += (raw - y) * aRC; const r = res(y);
      p += (st.P * trans(st.det - r, R.ring) - p) * aPh;
      t[i] = i * dt; v[i] = y; dl[i] = r; P[i] = p; Pn[i] = p + 0.01 * st.P * gauss();
    }
    Object.assign(R, { t, v, dl, P, Pn, spb, N, tauPh, fopt: 1 / (2 * PI * tauPh) });
    const ones = [], zeros = [], segs = [];
    let bp = 0, best = -1;
    for (let q = 0; q < spb; q++) { let s1 = 0, s0 = 0, n1 = 0, n0 = 0; for (let k = 2; k < 126; k++) { const val = Pn[k * spb + q]; if (BITS[k]) { s1 += val; n1++; } else { s0 += val; n0++; } } const dd = Math.abs(s1 / n1 - s0 / n0); if (dd > best) { best = dd; bp = q; } }
    for (let k = 2; k < 125; k++) { const c = k * spb + bp; (BITS[k] ? ones : zeros).push(Pn[c]); const i0 = c - spb / 2, xs = [], ys = []; for (let i = i0; i <= i0 + 2 * spb && i < N; i++) { xs.push((i - i0) / spb); ys.push(Pn[i]); } segs.push([xs, ys]); }
    const mean = (a) => a.reduce((s, x) => s + x, 0) / a.length, sd = (a, m) => Math.sqrt(a.reduce((s, x) => s + (x - m) ** 2, 0) / a.length);
    const m1 = mean(ones), m0 = mean(zeros);
    R.eye = { segs, m1, m0, Q: Math.abs(m1 - m0) / (sd(ones, m1) + sd(zeros, m0)), ER: 10 * Math.log10(Math.max(m1, m0) / Math.max(Math.min(m1, m0), 1e-6)) };
    R.Qs = linspace(2500, 15000, 60);
    R.oma = map(R.Qs, (Q) => { const rr = ring(Q); return Math.abs(trans(st.det - R.res0, rr) - trans(st.det - R.res1, rr)) * st.P; });
    R.ph = linspace(0, 6, 61);
    return R;
  },
  render(R, api) {
    const { st, C } = api, rg = R.ring;
    const W = 16 * R.spb, tw = R.t.subarray(0, W), xmax = tw[W - 1], cur = (api.frame * 4) % W;
    const onRes = Math.abs(st.det - (R.res0 + R.res1) / 2) < rg.fwhm * 0.25;
    api.status([["Loaded Q", st.QL.toFixed(0), ""], ["Linewidth", rg.fwhm.toFixed(0) + " pm", ""], ["Resonance shift (swing)", Math.abs(R.res0 - R.res1).toFixed(1) + " pm", ""],
      ["Optical bandwidth", R.fopt.toFixed(0) + " GHz", R.fopt < 0.7 * st.rate ? "warn" : "good"], ["Dynamic ER", R.eye.ER.toFixed(1) + " dB", R.eye.ER < 3 ? "warn" : "good"], ["Laser position", onRes ? "at the notch bottom" : "on the slope", onRes ? "warn" : "good"]]);
    api.q(".ringtxt").textContent = `Q_L = ${st.QL.toFixed(0)}, FWHM ${rg.fwhm.toFixed(0)} pm`;
    // TP1: laser vs comb of resonances over one FSR (nm scale)
    const fs = linspace(-FSR * 0.75, FSR * 0.75, 600);
    api.plot("tp1", { xmin: fs[0], xmax: fs[599], ymin: 0, ymax: 1.1, xlabel: "λ − 1550 nm (nm)", ylabel: "T", series: [{ x: fs, y: map(fs, (x) => { let tt = 1; for (const k of [-1, 0, 1]) tt *= trans((x - k * FSR) * 1000 - R.res1, rg); return tt; }), color: C.ink, w: 1.6 }], vlines: [{ x: st.det / 1000, color: C.opt, w: 2, dash: [], label: "laser" }] });
    api.ro("tp1", [["Laser", (LAM0 + st.det / 1000).toFixed(3) + " nm"], ["FSR", FSR.toFixed(1) + " nm"], ["Power", st.P.toFixed(1) + " mW"]]);
    api.plot("tp2", { xmin: 0, xmax, xlabel: "time (ns)", ylabel: "V_R (V) · Δλ/10 (pm)", legend: true, series: [{ x: tw, y: R.v.subarray(0, W), color: C.rf, w: 1.8, label: "V_R" }, { x: tw, y: map(R.dl.subarray(0, W), (d) => d / 10 - (HEAT * st.Ph + DTHERM * st.dT) / 10), color: C.ph, w: 1.4, label: "Δλ_V/10" }], cursor: tw[cur] });
    api.ro("tp2", [["Swing", st.vpp.toFixed(1) + " Vpp"], ["Shift '0' → '1'", Math.abs(R.res0 - R.res1).toFixed(1) + " pm"], ["Forward excursion", st.VR - st.vpp / 2 < 0 ? "yes" : "no", st.VR - st.vpp / 2 < 0 ? "warn" : "good"]]);
    api.plot("tp3", { xmin: -400, xmax: 900, ymin: 0, ymax: 1.05, xlabel: "λ − 1550 nm (pm)", ylabel: "through-port T", series: [{ x: R.d, y: R.Ta, color: C.bad, w: 1.8 }, { x: R.d, y: R.Tb, color: C.ok, w: 1.8 }], vlines: [{ x: st.det, color: C.opt, w: 2, dash: [], label: "laser" }], labels: [{ x: R.res0, y: rg.tmin, text: "'0'", color: C.bad, dy: -10 }, { x: R.res1, y: rg.tmin, text: "'1'", color: C.ok, dy: -10 }] });
    api.eqv("tp3", `T('1') = ${trans(st.det - R.res1, rg).toFixed(2)}, T('0') = ${trans(st.det - R.res0, rg).toFixed(2)}, T_min = ${rg.tmin.toFixed(3)} (Q_c = ${rg.Qc.toFixed(0)})`);
    api.ro("tp3", [["Res. '1'", (R.res1).toFixed(0) + " pm"], ["Res. '0'", (R.res0).toFixed(0) + " pm"], ["Notch depth", (10 * Math.log10(1 / Math.max(rg.tmin, 1e-4))).toFixed(1) + " dB"]]);
    api.plot("tp4", { xmin: 0, xmax, ymin: 0, xlabel: "time (ns)", ylabel: "P (mW)", series: [{ x: tw, y: R.P.subarray(0, W), color: C.opt, w: 1.8, fill: C.opt }], cursor: tw[cur] });
    api.eqv("tp4", `τ_ph = ${(R.tauPh * 1000).toFixed(1)} ps → optical bandwidth ≈ ${R.fopt.toFixed(0)} GHz`);
    api.ro("tp4", [["Average", (R.P.reduce((s, x) => s + x, 0) / R.N).toFixed(3) + " mW"], ["Photon lifetime", (R.tauPh * 1000).toFixed(1) + " ps"]]);
    api.plot("tp5", { xmin: 0, xmax: 2, ymin: 0, xlabel: "time (UI)", ylabel: "P (mW)", series: [{ segs: R.eye.segs, color: C.opt, w: 1, alpha: 0.35 }], hlines: [{ y: R.eye.m1, color: C.ok, dash: [3, 3] }, { y: R.eye.m0, color: C.bad, dash: [3, 3] }] });
    api.ro("tp5", [["Q-factor", R.eye.Q.toFixed(1), R.eye.Q < 6 ? "warn" : "good"], ["ER", R.eye.ER.toFixed(1) + " dB"], ["OMA", (Math.abs(R.eye.m1 - R.eye.m0) * 1000).toFixed(0) + " µW"]]);
    api.plot("a1", { xmin: 2500, xmax: 15000, ymin: 0, xlabel: "loaded Q", ylabel: "OMA (mW) · f_opt (100 GHz)", legend: true, series: [{ x: R.Qs, y: R.oma, color: C.opt, w: 2, label: "OMA (static)" }, { x: R.Qs, y: map(R.Qs, (Q) => C0 / (LAM0 * 1e-9 * Q) / 1e11), color: C.ink, w: 2, label: "f_opt /100 GHz" }], vlines: [{ x: st.QL, color: C.muted, dash: [2, 3] }] });
    api.ro("a1", [["Optical BW", R.fopt.toFixed(0) + " GHz"], ["Static OMA", (Math.abs(trans(st.det - R.res0, rg) - trans(st.det - R.res1, rg)) * st.P * 1000).toFixed(0) + " µW"]]);
    const resH = map(R.ph, (p) => (HEAT * p) / 1000);
    api.plot("a2", { xmin: 0, xmax: 6, xlabel: "heater power (mW)", ylabel: "resonance − 1550 (nm)", series: [{ x: R.ph, y: map(resH, (r) => r + 0.4), color: C.muted, w: 1, dash: [3, 3] }, { x: R.ph, y: map(resH, (r) => r - 0.4), color: C.muted, w: 1, dash: [3, 3] }, { x: R.ph, y: map(resH, (r) => r + (DTHERM * st.dT + shift(st.VR)) / 1000), color: C.heat, w: 2.2 }], hlines: [{ y: st.det / 1000, color: C.opt, dash: [], w: 1.6, label: "laser" }], points: [{ x: st.Ph, y: (HEAT * st.Ph + DTHERM * st.dT + shift(st.VR)) / 1000, color: C.ink }] });
    api.ro("a2", [["Heater shift", (HEAT * st.Ph).toFixed(0) + " pm"], ["Drift shift", f(DTHERM * st.dT, 0) + " pm"], ["Heater to re-lock", Math.max(0, (st.det - DTHERM * st.dT - shift(st.VR)) / HEAT).toFixed(2) + " mW"]]);
  },
};

export default { atomic, bench };
