// Silicon grating coupler: a periodically etched waveguide that diffracts light up into a single-mode fibre.
import { fSI, f } from "../lib/physics.js";
import { map, linspace } from "../lib/plot.js";

const PI = Math.PI, NOX = 1.444, W0 = 5.2; // fibre mode waist (µm)
// effective indices of the 220 nm slab (unetched) and of the etched teeth, with a simple linear dispersion
const nFull = (lam) => 2.85 - 1.0 * (lam - 1.55);
const nEtch = (lam, etch) => nFull(lam) - 0.0036 * etch - 0.4 * (lam - 1.55) * etch / 220;
const neff = (lam, g) => g.ff * nFull(lam) + (1 - g.ff) * nEtch(lam, g.etch);
// first-order diffraction angle into air (deg); NaN if evanescent
const angle = (lam, g) => { const s = neff(lam, g) - lam / (g.period / 1000); return Math.abs(s) <= 1 ? (Math.asin(s) * 180) / PI : NaN; };
const alphaOf = (g) => 0.11 * Math.pow(g.etch / 70, 2) * 4 * g.ff * (1 - g.ff); // power leakage rate, 1/µm
// directionality: interference between the up-going beam and its reflection from the substrate under the BOX
const directionality = (lam, g) => 0.62 + 0.28 * Math.cos((4 * PI * NOX * g.box) / lam - (4 * PI * NOX * 2.0) / 1.55);
function overlap(alpha, xf) { // field overlap of exp(−αx) emission with a Gaussian fibre mode centred at xf
  const xs = linspace(0, 40, 400), dx = xs[1] - xs[0];
  let num = 0, a2 = 0, g2 = 0;
  for (const x of xs) { const e = Math.sqrt(2 * alpha) * Math.exp(-alpha * x), gg = Math.exp(-((x - xf) ** 2) / (W0 * W0)); num += e * gg * dx; a2 += e * e * dx; g2 += gg * gg * dx; }
  return (num * num) / (a2 * g2);
}
function couple(lam, g) {
  const th = angle(lam, g), a = alphaOf(g);
  const dTh = ((lam / (PI * W0)) * 180) / PI; // far-field angular width of the fibre mode
  const ang = isNaN(th) ? 0 : Math.exp(-(((th - g.theta) / dTh) ** 2));
  const ov = overlap(a, g.xf), D = directionality(lam, g);
  return { th, a, ov, D, ang, eta: 0.95 * D * ov * ang };
}
const dB = (x) => 10 * Math.log10(Math.max(x, 1e-6));
const fmtNm = (v) => v.toFixed(0) + " nm";

// ---------- atomic ----------
const atomic = {
  intro: "Side view along the waveguide. Light arrives from the left in a 220 nm silicon slab. Each etched tooth scatters a little of it; when the period is right, all those scattered waves add up in phase at one angle and form a beam aimed at the fibre above. Some light also goes down into the substrate, and whatever is not scattered continues to the right. Not to scale.",
  controls: [
    { label: "Light", color: "opt", items: [{ id: "lam", label: "Wavelength", min: 1500, max: 1600, step: 1, value: 1550, fmt: fmtNm }] },
    { label: "Grating", color: "ph", items: [{ id: "period", label: "Period Λ", min: 560, max: 700, step: 2, value: 610, fmt: fmtNm }, { id: "etch", label: "Etch depth", min: 20, max: 160, step: 5, value: 70, fmt: fmtNm }] },
  ],
  presets: [{ label: "Standard: 610 nm, 70 nm etch", set: { lam: 1550, period: 610, etch: 70 } }, { label: "Deep etch 150 nm", set: { etch: 150 } }, { label: "Period too long", set: { period: 690 } }],
  look: [
    "The tilted beam angle follows the Bragg (phase-matching) condition: change the period or the wavelength and watch it swing.",
    "A deeper etch scatters more per tooth, so the light leaves the grating faster (shorter emission region, see the 'Power along grating' view).",
    "Lens on a tooth: crystalline silicon next to amorphous oxide. The index contrast between them (3.48 vs 1.44) is what scatters the light.",
  ],
  legendExtra: '<span><i class="dot" style="background:var(--ph)"></i>photons</span>',
  world: { w: 220, h: 90 }, aspect: "22/9", lensAt: [80, 54],
  views: [["power", "Power along grating"], ["index", "Index profile"], ["phase", "Phase matching"]],
  plotChip: "OPTICS", plotTitle: "Light along the grating", plotDom: "coupled-mode model",
  cuts: [{ id: "wg", label: "Along the waveguide", a: [5, 54], b: [215, 54] }],
  solve(st) { const g = { ...st, ff: 0.5, box: 2.0, theta: 10, xf: 8 }; return { g, c: couple(st.lam / 1000, g) }; },
  scene(S, st) {
    const g = S.g, c = S.c, x0 = 40, tooth = (st.period / 1000) * 9; // world units per µm ≈ 9
    const regions = [{ x: 0, y: 0, w: 220, h: 50, mat: "clad" }, { x: 0, y: 58, w: 220, h: 20, mat: "box" }, { x: 0, y: 78, w: 220, h: 12, mat: "si", dop: "i" }, { x: 0, y: 50, w: 220, h: 8, mat: "si", dop: "i" }];
    const et = (st.etch / 220) * 8;
    for (let k = 0; k < 18; k++) { const x = x0 + k * tooth + tooth * 0.5; if (x > 210) break; regions.push({ x, y: 50, w: tooth * 0.5, h: et, mat: "clad" }); }
    const up = isNaN(c.th) ? 0 : c.th;
    const vx = Math.sin((up * PI) / 180) * 30, vy = -Math.cos((up * PI) / 180) * 30;
    const decay = Math.min(150, 1 / Math.max(c.a, 0.005) * 9);
    return {
      regions,
      glows: [{ cx: 20, cy: 54, rx: 22, ry: 5, color: "opt", a: 0.5 }, { cx: x0 + decay * 0.5, cy: 30, rx: Math.max(10, decay * 0.5), ry: 18, color: "opt", a: 0.25 * Math.min(1, c.D * 1.5) }],
      zones: [
        { id: "in", type: "ph", x: 0, y: 51, w: x0, h: 6, dens: 0.8, vx: 40, jit: 0.05, px: 30 },
        { id: "gr", type: "ph", x: x0, y: 51, w: Math.min(170, decay), h: 6, dens: 0.6, vx: 40, jit: 0.05, px: 30 },
        { id: "upb", type: "ph", x: x0, y: 5, w: Math.min(170, decay), h: 44, dens: isNaN(c.th) ? 0 : 0.35 * c.D, vx, vy, jit: 0.02, px: 40 },
        { id: "down", type: "ph", x: x0, y: 59, w: Math.min(170, decay), h: 18, dens: 0.3 * (1 - c.D), vx, vy: -vy, jit: 0.02, px: 40 },
      ],
      arrows: isNaN(c.th) ? [] : [{ x1: x0 + 30, y1: 46, x2: x0 + 30 + 30 * Math.tan((up * PI) / 180), y2: 16, color: "opt", label: `θ = ${up.toFixed(1)}°` }],
      labels: [{ x: 20, y: 46, text: "Si waveguide", size: 9 }, { x: 180, y: 68, text: "buried oxide 2 µm", size: 9, color: "muted" }, { x: 190, y: 85, text: "Si substrate", size: 9, color: "muted" }, { x: 180, y: 10, text: "fibre above →", size: 9, color: "muted" }],
      terminals: [],
    };
  },
  plotView(S, st, cut, view, C) {
    const g = S.g, c = S.c;
    if (view === "power") {
      const x = linspace(0, 30, 200);
      const P = map(x, (v) => Math.exp(-2 * c.a * v)), Sx = map(x, (v) => 2 * c.a * Math.exp(-2 * c.a * v)), F = map(x, (v) => Math.exp(-2 * ((v - g.xf) ** 2) / (W0 * W0)));
      const smax = Math.max(...Sx);
      return { o: { xmin: 0, xmax: 30, ymin: 0, ymax: 1.05, xlabel: "position along grating (µm)", ylabel: "normalised", legend: true, series: [{ x, y: P, color: C.opt, w: 2, label: "power in waveguide" }, { x, y: map(Sx, (v) => v / smax), color: C.ph, w: 2, fill: C.ph, label: "emission" }, { x, y: F, color: C.muted, w: 1.4, dash: [4, 3], label: "fibre mode" }] },
        leg: `<span style="color:var(--opt)">waveguide power decays as e<sup>−2αx</sup></span><span style="color:var(--ph)">emitted intensity</span><span>dashed: fibre mode to match</span>` };
    }
    if (view === "index") {
      const per = st.period / 1000, x = linspace(0, 6 * per, 600);
      const y = map(x, (v) => ((v % per) / per < 0.5 ? nFull(st.lam / 1000) : nEtch(st.lam / 1000, st.etch)));
      return { o: { xmin: 0, xmax: 6 * per, ymin: 2.3, ymax: 3.0, xlabel: "position (µm)", ylabel: "local n_eff", series: [{ x, y, color: C.ink, w: 2 }], hlines: [{ y: neff(st.lam / 1000, g), color: C.ph, dash: [4, 3], label: "average n_eff" }] }, leg: "<span>effective index of the slab: full height vs etched</span>" };
    }
    const lams = linspace(1.45, 1.65, 120);
    return { o: { xmin: 1450, xmax: 1650, ymin: -25, ymax: 35, xlabel: "λ (nm)", ylabel: "diffraction angle θ (°)", series: [{ x: map(lams, (l) => l * 1000), y: map(lams, (l) => angle(l, g)), color: C.ph, w: 2.2 }], hlines: [{ y: g.theta, color: C.opt, dash: [4, 3], label: "fibre at 10°" }], points: isNaN(c.th) ? [] : [{ x: st.lam, y: c.th, color: C.ink }] },
      leg: "<span>sin θ = n_eff − λ/Λ: the phase-matching (Bragg) condition</span>" };
  },
  readouts(S, st) {
    const c = S.c;
    return [["n_eff (average)", neff(st.lam / 1000, S.g).toFixed(3)], ["Diffraction angle", isNaN(c.th) ? "evanescent" : c.th.toFixed(1) + "°"], ["Leakage α", c.a.toFixed(3) + " µm⁻¹"],
      ["1/(2α) emission length", (1 / (2 * c.a)).toFixed(1) + " µm"], ["Coupling to fibre", dB(c.eta).toFixed(2) + " dB"]];
  },
  foot: "Coupled-mode picture: average effective index from the unetched and etched slab indices, first-order Bragg condition into air, exponential leakage with α ∝ (etch)², directionality from the BOX reflection, overlap with a 10.4 µm Gaussian fibre mode. No FDTD. Illustrative values.",
};

// ---------- bench ----------
const bench = {
  intro: "A tunable laser feeds a cleaved single-mode fibre held above the chip at an angle; the grating couples the light into the waveguide, and an on-chip photodiode (or a second grating) reads it. Tune the grating and the fibre to maximise coupling.",
  controls: [
    { label: "Laser (TP1)", color: "opt", items: [{ id: "lam", label: "Wavelength", min: 1500, max: 1600, step: 1, value: 1550, fmt: fmtNm }] },
    { label: "Fibre (TP1)", color: "rf", items: [{ id: "theta", label: "Fibre angle", min: 0, max: 20, step: 0.5, value: 10, fmt: (v) => v.toFixed(1) + "°" }, { id: "xf", label: "Fibre position along grating", min: 0, max: 20, step: 0.5, value: 8, fmt: (v) => v.toFixed(1) + " µm" }] },
    { label: "Grating design (TP2)", color: "ph", items: [{ id: "period", label: "Period Λ", min: 560, max: 700, step: 2, value: 610, fmt: fmtNm }, { id: "etch", label: "Etch depth", min: 20, max: 160, step: 5, value: 70, fmt: fmtNm }, { id: "ff", label: "Fill factor", min: 0.2, max: 0.8, step: 0.02, value: 0.5, fmt: (v) => v.toFixed(2) }] },
    { label: "Wafer (A1)", color: "dc", items: [{ id: "box", label: "BOX thickness", min: 0.8, max: 3.2, step: 0.05, value: 2.0, fmt: (v) => v.toFixed(2) + " µm" }] },
  ],
  presets: [
    { label: "Optimised", set: { lam: 1550, theta: 10, xf: 8, period: 610, etch: 70, ff: 0.5, box: 2.0 } },
    { label: "Wrong fibre angle (2°)", set: { theta: 2 } },
    { label: "BOX 1.6 µm (destructive)", set: { box: 1.6 } },
    { label: "Fibre misaligned 5 µm", set: { xf: 13 } },
  ],
  schematic: {
    viewBox: "0 0 900 300",
    svg: `
  <rect class="bx" x="20" y="20" width="140" height="50" rx="5"/><text class="lb" x="90" y="50" text-anchor="middle">Tunable laser</text>
  <path class="o" d="M160,45 H300 L360,150" /><text class="cap" x="190" y="35">single-mode fibre</text>
  <rect class="die" x="200" y="160" width="520" height="110" rx="10"/><text class="cap" x="212" y="180">SiPh die</text>
  <rect class="dev" x="300" y="190" width="150" height="34" rx="4"/><text class="lb" x="375" y="212" text-anchor="middle">grating coupler</text>
  <path class="o" d="M450,207 H620"/><path class="flow" d="M450,207 H620"/>
  <rect class="bx" x="620" y="185" width="90" height="44" rx="5"/><text class="lb" x="665" y="212" text-anchor="middle">Ge PD</text>
  <path class="dc" d="M710,207 H760"/><rect class="bx" x="760" y="180" width="120" height="54" rx="5"/><text class="lb" x="820" y="203" text-anchor="middle">Power meter</text><text class="sub pwtxt" x="820" y="221" text-anchor="middle"></text>`,
  },
  tps: [{ n: 1, x: 330, y: 100, label: "fibre beam" }, { n: 2, x: 375, y: 240, label: "grating emission" }, { n: 3, x: 535, y: 207, label: "coupled power spectrum" }, { n: 4, x: 820, y: 255, label: "power meter" }],
  sections: [{ k: "tp", t: "Test points", n: "" }, { k: "ana", t: "Design and assembly tolerances", n: "" }],
  cards: [
    { id: "tp1", tp: 1, s: "tp", d: "opt", dn: "optical", t: "Fibre beam vs grating beam angle", x: "Angle at which the grating radiates vs wavelength, with the fibre angle. Coupling needs them to match within the fibre's angular width.", eq: "sin θ = n<sub>eff</sub> − λ/Λ,&nbsp; Δθ<sub>fibre</sub> ≈ λ/(πw<sub>0</sub>) ≈ 5°" },
    { id: "tp2", tp: 2, s: "tp", d: "ph", dn: "near field", t: "Emission profile vs fibre mode", x: "Exponential emission from the grating and the Gaussian fibre mode. Their overlap is capped near 80 % for a uniform grating; apodised gratings reach 95 %.", eq: "η<sub>ov</sub> = |∫√S(x)·g(x)dx|² / (∫S ∫g²),&nbsp; S ∝ 2αe<sup>−2αx</sup>" },
    { id: "tp3", tp: 3, s: "tp", d: "opt", dn: "spectrum", t: "Coupling efficiency vs wavelength", x: "Peak efficiency and 1 dB bandwidth. The spectrum moves with the period and the fibre angle.", eq: "η(λ) = 0.95·D(λ)·η<sub>ov</sub>·exp[−((θ(λ) − θ<sub>f</sub>)/Δθ)²]", h: "tall" },
    { id: "tp4", tp: 4, s: "tp", d: "dc", dn: "instrument", t: "Power meter", x: "Coupling loss at the laser wavelength.", eq: "IL = −10·log<sub>10</sub>η", kind: "big" },
    { id: "a1", chip: "BOX", s: "ana", d: "an", dn: "wafer", t: "Directionality vs BOX thickness", x: "Light emitted downward reflects off the substrate and interferes with the upward beam. The BOX thickness sets constructive or destructive interference.", eq: "D ≈ 0.62 + 0.28·cos(4πn<sub>ox</sub>t<sub>BOX</sub>/λ − φ)" },
    { id: "a2", chip: "Δx", s: "ana", d: "an", dn: "assembly", t: "Fibre alignment tolerance", x: "Coupling vs fibre position along the grating: the ±1 dB window is what packaging must hold.", eq: "η(x<sub>f</sub>) ∝ η<sub>ov</sub>(α, x<sub>f</sub>)" },
  ],
  foot: "Model: average effective index (220 nm slab, 2.85; etched teeth reduced by 3.6×10⁻³ per nm of etch), first-order diffraction into air, leakage α = 0.11 µm⁻¹ × (etch/70 nm)² × 4ff(1−ff), BOX directionality, Gaussian fibre (MFD 10.4 µm). Back-reflection and polarisation are ignored. Illustrative values.",
  sim(st) {
    const g = { ...st };
    const R = { c: couple(st.lam / 1000, g) };
    R.lams = linspace(1480, 1620, 141);
    R.eta = map(R.lams, (l) => dB(couple(l / 1000, g).eta));
    R.th = map(R.lams, (l) => angle(l / 1000, g));
    let pk = -99, lpk = st.lam; R.eta.forEach((v, i) => { if (v > pk) { pk = v; lpk = R.lams[i]; } });
    const inBand = R.lams.filter((l, i) => R.eta[i] > pk - 1);
    R.pk = pk; R.lpk = lpk; R.bw1 = inBand.length ? inBand[inBand.length - 1] - inBand[0] : 0;
    R.boxes = linspace(0.8, 3.2, 121); R.D = map(R.boxes, (b) => directionality(st.lam / 1000, { ...g, box: b }));
    R.xs = linspace(0, 20, 81); R.al = map(R.xs, (x) => dB(couple(st.lam / 1000, { ...g, xf: x }).eta));
    return R;
  },
  render(R, api) {
    const { st, C } = api, c = R.c;
    api.status([["Coupling loss", (-dB(c.eta)).toFixed(2) + " dB", -dB(c.eta) > 6 ? "warn" : "good"], ["Peak / at λ", R.pk.toFixed(2) + " dB @ " + R.lpk.toFixed(0) + " nm", ""],
      ["1 dB bandwidth", R.bw1.toFixed(0) + " nm", ""], ["Grating angle", isNaN(c.th) ? "—" : c.th.toFixed(1) + "°", ""], ["Directionality", (c.D * 100).toFixed(0) + " %", c.D < 0.5 ? "warn" : ""], ["Mode overlap", (c.ov * 100).toFixed(0) + " %", ""]]);
    api.q(".pwtxt").textContent = (-dB(c.eta)).toFixed(2) + " dB loss";
    api.plot("tp1", { xmin: 1480, xmax: 1620, ymin: -10, ymax: 30, xlabel: "λ (nm)", ylabel: "θ (°)", series: [{ x: R.lams, y: R.th, color: C.ph, w: 2.2 }], hbands: [{ y0: st.theta - 2.7, y1: st.theta + 2.7, color: C.opt, a: 0.15 }], hlines: [{ y: st.theta, color: C.opt, dash: [4, 3], label: "fibre" }], points: isNaN(c.th) ? [] : [{ x: st.lam, y: c.th, color: C.ink }] });
    api.ro("tp1", [["Grating θ at λ", isNaN(c.th) ? "—" : c.th.toFixed(2) + "°"], ["Fibre θ", st.theta.toFixed(1) + "°"], ["Angle match", (c.ang * 100).toFixed(0) + " %"]]);
    const x = linspace(0, 30, 200), Sx = map(x, (v) => 2 * c.a * Math.exp(-2 * c.a * v)), smax = Math.max(...Sx);
    api.plot("tp2", { xmin: 0, xmax: 30, ymin: 0, ymax: 1.05, xlabel: "x along grating (µm)", ylabel: "normalised", series: [{ x, y: map(Sx, (v) => v / smax), color: C.ph, w: 2, fill: C.ph }, { x, y: map(x, (v) => Math.exp(-2 * ((v - st.xf) ** 2) / (W0 * W0))), color: C.opt, w: 1.8, dash: [4, 3] }] });
    api.eqv("tp2", `α = ${c.a.toFixed(3)} µm⁻¹, emission length 1/(2α) = ${(1 / (2 * c.a)).toFixed(1)} µm; ideal α·w₀ ≈ 0.68 → α ≈ ${(0.68 / W0).toFixed(3)} µm⁻¹`);
    api.ro("tp2", [["Overlap", (c.ov * 100).toFixed(1) + " %"], ["α", c.a.toFixed(3) + " µm⁻¹"]]);
    api.plot("tp3", { xmin: 1480, xmax: 1620, ymin: -15, ymax: 0, xlabel: "λ (nm)", ylabel: "coupling (dB)", series: [{ x: R.lams, y: R.eta, color: C.opt, w: 2.2, fill: C.opt, fillTo: -15 }], hlines: [{ y: R.pk - 1, color: C.muted, dash: [3, 3], label: "−1 dB" }], vlines: [{ x: st.lam, color: C.ink, dash: [2, 3] }] });
    api.ro("tp3", [["Peak", R.pk.toFixed(2) + " dB"], ["Peak λ", R.lpk.toFixed(0) + " nm"], ["1 dB BW", R.bw1.toFixed(0) + " nm"]]);
    api.big("tp4", (-dB(c.eta)).toFixed(2) + "<small>dB loss</small>");
    api.plot("tp4", { xmin: 1480, xmax: 1620, ymin: -15, ymax: 0, series: [{ x: R.lams, y: R.eta, color: C.dc, w: 1.6 }], vlines: [{ x: st.lam, color: C.ink }] });
    api.ro("tp4", [["Transmitted", (c.eta * 100).toFixed(1) + " %"], ["From 1 mW", fSI(c.eta * 1e-3, "W")]]);
    api.plot("a1", { xmin: 0.8, xmax: 3.2, ymin: 0, ymax: 1, xlabel: "BOX thickness (µm)", ylabel: "directionality", series: [{ x: R.boxes, y: R.D, color: C.dc, w: 2.2 }], points: [{ x: st.box, y: c.D, color: C.ink }] });
    api.ro("a1", [["D at BOX", (c.D * 100).toFixed(0) + " %"], ["Lost to substrate", ((1 - c.D) * 100).toFixed(0) + " %"]]);
    const pkA = Math.max(...R.al);
    api.plot("a2", { xmin: 0, xmax: 20, ymin: -12, ymax: 0, xlabel: "fibre position (µm)", ylabel: "coupling (dB)", series: [{ x: R.xs, y: R.al, color: C.rf, w: 2.2 }], hlines: [{ y: pkA - 1, color: C.muted, dash: [3, 3], label: "−1 dB" }], points: [{ x: st.xf, y: dB(c.eta), color: C.ink }] });
    const win = R.xs.filter((x2, i) => R.al[i] > pkA - 1);
    api.ro("a2", [["±1 dB window", win.length ? (win[win.length - 1] - win[0]).toFixed(1) + " µm" : "—"], ["Best position", R.xs[R.al.indexOf(pkA)].toFixed(1) + " µm"]]);
  },
};

export default { atomic, bench };
