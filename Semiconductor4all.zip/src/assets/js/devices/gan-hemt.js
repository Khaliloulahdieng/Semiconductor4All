// AlGaN/GaN high-electron-mobility transistor (depletion mode, RF power class).
import { buildGrid, solvePoisson, interp, visDensity, fSI, f, q, eps0 } from "../lib/physics.js";
import { map, linspace } from "../lib/plot.js";

const PI = Math.PI;
// ---------- polarization and barrier ----------
const alloy = (x) => ({ chi: 4.1 - 0.7 * (6.2 - 3.4) * x, Eg: 3.4 + (6.2 - 3.4) * x, eps: 9.5 - 0.5 * x });
const sigma = (x) => 1.4e13 * (x / 0.25); // net polarization sheet at the AlGaN/GaN interface (cm⁻²)
const D_BAR = 20, PHI_B = 2.4; // barrier thickness nm; effective barrier (eV) calibrated so the compact n_s(V_G) tracks the Poisson 2DEG
function compact(x) { // ns(VG) ≈ (ε/qd)(VG − V_th), smoothed
  const a = alloy(x), C = (a.eps * eps0) / (D_BAR * 1e-7);
  const dEc = 0.7 * (a.Eg - 3.4);
  const Vth = PHI_B - dEc - (q * sigma(x)) / C + 0.1;
  return { C, Vth, ns: (VG) => (C / q) * 0.05 * Math.log1p(Math.exp((VG - Vth) / 0.05)) };
}

// ---------- atomic: vertical cut gate → AlGaN → GaN channel → buffer ----------
function vertical(VG, x) {
  const al = alloy(x);
  const g = buildGrid([
    { mat: "AlGaN", t: D_BAR - 1, dx: 0.25, mods: () => al },
    { mat: "AlGaN", t: 1, dx: 0.1, Qf: sigma(x) / 1e-7, mods: () => al }, // polarization charge
    { mat: "GaN", t: 40, N: 1e15, dx: 0.25 },
    { mat: "GaN", t: 400, N: 0, Nt: 5e16, dx: 8 },                       // carbon-doped, semi-insulating buffer
  ]);
  const s = solvePoisson(g, { left: { type: "gate", V: VG, wf: 5.1 }, right: { type: "neumann" } });
  let ns = 0, zs = 0;
  for (let i = 1; i < g.x.length; i++) if (g.x[i] > D_BAR) { const dx = (g.x[i] - g.x[i - 1]) * 1e-7; ns += s.n[i] * dx; zs += s.n[i] * dx * (g.x[i] - D_BAR); }
  return { g, s, ns, zc: ns > 0 ? zs / ns : 0 };
}

const atomic = {
  intro: "A HEMT has no doped channel. Gallium nitride and aluminium gallium nitride are polar crystals: at their interface a sheet of fixed positive polarization charge appears, and it pulls in a thin sheet of electrons on the GaN side, the two-dimensional electron gas (2DEG). These electrons move fast because no dopant atoms scatter them. A negative gate voltage pushes them away (pinch-off). Not to scale.",
  controls: [
    { label: "Gate", color: "ph", items: [{ id: "VG", label: "Gate voltage V_G", min: -6, max: 1.5, step: 0.05, value: 0, fmt: (v) => f(v, 2) + " V" }] },
    { label: "Drain", color: "rf", items: [{ id: "VD", label: "Drain voltage V_D", min: 0, max: 40, step: 1, value: 10, fmt: (v) => v + " V" }] },
    { label: "Barrier", color: "dc", items: [{ id: "x", label: "Al fraction in AlGaN", min: 0.15, max: 0.35, step: 0.01, value: 0.25, fmt: (v) => (v * 100).toFixed(0) + " %" }] },
  ],
  presets: [{ label: "V_G = 0 (normally on)", set: { VG: 0 } }, { label: "Near pinch-off", set: { VG: -2.6 } }, { label: "Pinched off (−5 V)", set: { VG: -5 } }, { label: "35 % Al", set: { x: 0.35, VG: 0 } }],
  look: [
    "At V_G = 0 the conduction band dips below the Fermi level just under the AlGaN: that triangular well holds the 2DEG. Switch to Carriers to see its density peak at 10¹⁹–10²⁰ cm⁻³ in a few nanometres.",
    "Make V_G negative: the AlGaN band tilts the other way, the well rises above E_F and the 2DEG empties. That is pinch-off, near −3 V here.",
    "Raise the Al fraction: more polarization charge, a deeper well and more electrons. That costs more negative gate voltage to pinch off.",
  ],
  world: { w: 200, h: 100 }, aspect: "2/1", lensAt: [100, 46],
  cuts: [{ id: "vert", label: "Gate → AlGaN → GaN", a: [100, 30], b: [100, 98] }],
  solve(st) {
    const V = vertical(st.VG, st.x), C = compact(st.x);
    const Id = idDC(st.VG, st.VD, { x: st.x, T: 25 }).Id;
    return { V, C, Id, ns0: vertical(0, st.x).ns };
  },
  scene(S, st) {
    const dg = visDensity(S.V.ns / 2e-7, 14.5, 20), da = visDensity(S.ns0 / 2e-7, 14.5, 20);
    const flow = S.Id > 1e-4 ? Math.min(60, 12 * Math.log10(S.Id * 1e4)) : 0;
    return {
      regions: [
        { x: 0, y: 85, w: 200, h: 15, mat: "si", dop: "i", fill: "m-hr" },
        { x: 0, y: 40, w: 200, h: 45, mat: "gan", dop: "i" },
        { x: 0, y: 32, w: 200, h: 8, mat: "gan", fill: "m-box" },
        { x: 0, y: 26, w: 200, h: 6, mat: "ox" },
        { x: 10, y: 22, w: 35, h: 18, mat: "metal" }, { x: 155, y: 22, w: 35, h: 18, mat: "metal" },
        { x: 90, y: 18, w: 20, h: 14, mat: "metal" }, { x: 90, y: 12, w: 40, h: 6, mat: "metal" },
      ],
      ions: [{ x: 0, y: 39, w: 200, h: 1, sign: 1, dens: 1 }],
      zones: [
        { id: "acL", type: "e", x: 45, y: 40, w: 45, h: 2, dens: da, vx: flow, jit: 0.2, px: 30 },
        { id: "gate", type: "e", x: 90, y: 40, w: 20, h: 2, dens: dg, vx: flow * (dg > 0.05 ? da / dg : 1), jit: 0.2, px: 30 },
        { id: "acR", type: "e", x: 110, y: 40, w: 45, h: 2, dens: da, vx: flow, jit: 0.2, px: 30 },
        { id: "s", type: "e", x: 10, y: 40, w: 35, h: 4, dens: 0.9 }, { id: "d", type: "e", x: 155, y: 40, w: 35, h: 4, dens: 0.9 },
      ],
      depl: dg < 0.3 ? [{ x: 90, y: 40, w: 20, h: 12 }] : [],
      labels: [
        { x: 60, y: 36, text: "AlGaN barrier (20 nm)", size: 9 }, { x: 60, y: 29, text: "SiN passivation", size: 9, color: "muted" },
        { x: 100, y: 64, text: "GaN channel / C-doped buffer", size: 10, color: "muted" }, { x: 100, y: 93, text: "SiC or Si substrate", size: 9, color: "muted" },
        { x: 180, y: 46, text: "2DEG", size: 9, color: "e" }, { x: 116, y: 15, text: "field plate", size: 8, align: "left" },
      ],
      terminals: [{ x: 27, y: 15, text: "S 0 V" }, { x: 100, y: 6, text: `G ${f(st.VG, 2)} V` }, { x: 172, y: 15, text: `D ${st.VD} V` }],
    };
  },
  bands(S) {
    const { g, s } = S.V;
    const idx = []; for (let i = 0; i < s.x.length; i++) if (s.x[i] <= 120) idx.push(i);
    const pick = (a) => Float64Array.from(idx, (i) => a[i]);
    return { x: pick(s.x), Ec: pick(s.Ec), Ev: pick(s.Ev), EFn: pick(s.EFn), EFp: pick(s.EFp), n: pick(s.n), p: pick(s.p), E: pick(s.E), Nabs: map(pick(g.N), Math.abs),
      regions: [{ x0: 0, x1: D_BAR, label: "AlGaN" }, { x0: D_BAR, x1: 60, label: "GaN channel" }, { x0: 60, x1: 120, label: "buffer" }], xlabel: "depth from gate (nm)", clip: [-5, 6] };
  },
  readouts(S, st) {
    return [["2DEG under gate", S.V.ns.toExponential(2) + " cm⁻²"], ["2DEG in access regions", S.ns0.toExponential(2) + " cm⁻²"], ["Polarization sheet", sigma(st.x).toExponential(1) + " cm⁻²"],
      ["Electron centroid", S.V.zc.toFixed(1) + " nm below interface"], ["Pinch-off (model)", f(S.C.Vth, 2) + " V"]];
  },
  foot: "1D Poisson: Schottky gate (φ_m = 5.1 eV) on a 20 nm AlGaN barrier treated as a carrier-free wide-gap layer with the polarization sheet at its bottom, GaN channel, carbon-doped buffer modelled by mid-gap traps. Boltzmann statistics and no quantisation in the well, so the 2DEG is approximate. Illustrative values.",
};

// ---------- compact model for the bench ----------
const VSAT = 1.3e7, RS = 0.35, RD = 0.6, RTH = 12; // cm/s, Ω·mm, Ω·mm, K·mm/W
function idDC(VG, VD, o) { // per mm of gate width, with self-heating
  const C = compact(o.x);
  let T = o.T, Id = 0;
  for (let k = 0; k < 6; k++) {
    const mu = 1800 * Math.pow((T + 273) / 300, -1.5), v = VSAT * Math.pow((T + 273) / 300, -0.3);
    const Imax = q * C.ns(VG) * v * 0.1 * 0.5; // A/cm → A/mm, and an average velocity ≈ 50 % of v_sat
    const Vsat = Math.max(0.3, Imax * (RS + RD) * 2 + 1.2 * (Imax / (Imax + 0.05)));
    Id = Imax * Math.tanh(Math.max(VD, 0) / Vsat) * (1 + 0.004 * VD);
    T = o.T + RTH * Id * VD;
  }
  return { Id, T };
}
function rf(st) {
  const Imax = idDC(2, 15, { x: st.x, T: 25 }).Id, Vk = 4;
  const Psat = ((st.VDD - Vk) * Imax) / 8 * st.Wmm; // class A/AB optimum load, W
  const G = 18; // dB
  const pin = linspace(-10, 40, 101);
  const pout = map(pin, (p) => { const pi = Math.pow(10, (p + G - 30) / 10); return 10 * Math.log10(Psat * Math.tanh(pi / Psat)) + 30; });
  const Idc = st.Wmm * 0.08;
  const pae = map(pin, (p, i) => { // drain current = quiescent + average of a half-sine of peak 2P/(V_DD − V_k)
    const po = Math.pow(10, (pout[i] - 30) / 10), pi = Math.pow(10, (p - 30) / 10);
    const pdc = st.VDD * (Idc + (2 / PI) * (2 * po) / (st.VDD - Vk));
    return Math.max(0, (100 * (po - pi)) / pdc);
  });
  return { Psat, pin, pout, pae, Ropt: (2 * (st.VDD - Vk)) / (Imax * st.Wmm), Imax };
}

const bench = {
  intro: "DC first (a parameter analyser on a 1 mm wide device), then RF: the same transistor biased at V_DD drives a matched load as a power amplifier. GaN's high breakdown lets V_DD be 28–50 V, so it delivers watts per millimetre.",
  controls: [
    { label: "Gate (TP1)", color: "ph", items: [{ id: "VG", label: "V_G", min: -6, max: 2, step: 0.05, value: -2, fmt: (v) => f(v, 2) + " V" }] },
    { label: "Drain (TP2)", color: "rf", items: [{ id: "VD", label: "V_D (DC curves)", min: 0, max: 50, step: 0.5, value: 10, fmt: (v) => v + " V" }, { id: "VDD", label: "Amplifier supply V_DD", min: 10, max: 50, step: 1, value: 28, fmt: (v) => v + " V" }] },
    { label: "Device", color: "dc", items: [{ id: "x", label: "Al fraction", min: 0.15, max: 0.35, step: 0.01, value: 0.25, fmt: (v) => (v * 100).toFixed(0) + " %" }, { id: "Wmm", label: "Total gate width", min: 0.5, max: 10, step: 0.5, value: 2, fmt: (v) => v + " mm" }] },
    { label: "Thermal", color: "heat", items: [{ id: "T", label: "Base-plate temperature", min: 25, max: 150, step: 5, value: 25, fmt: (v) => v + " °C" }] },
  ],
  presets: [{ label: "28 V class AB", set: { VG: -2, VD: 10, VDD: 28, Wmm: 2, T: 25 } }, { label: "48 V base station", set: { VDD: 48, Wmm: 10 } }, { label: "Hot: 150 °C base plate", set: { T: 150 } }, { label: "Pinched off", set: { VG: -5 } }],
  schematic: {
    viewBox: "0 0 900 320",
    svg: `
  <rect class="bx" x="20" y="130" width="120" height="56" rx="5"/><text class="lb" x="80" y="154" text-anchor="middle">RF source</text><text class="sub" x="80" y="173" text-anchor="middle">P_in</text>
  <path class="rf" d="M140,158 H200"/><rect class="bx chip" x="200" y="138" width="90" height="40" rx="4"/><text class="lb" x="245" y="163" text-anchor="middle">input match</text>
  <path class="rf" d="M290,158 H380"/>
  <rect class="dev" x="380" y="110" width="140" height="100" rx="6"/><text class="lb" x="450" y="152" text-anchor="middle">GaN HEMT</text><text class="sub hemttxt" x="450" y="172" text-anchor="middle"></text>
  <path class="rf" d="M520,158 H600"/><rect class="bx chip" x="600" y="138" width="90" height="40" rx="4"/><text class="lb" x="645" y="163" text-anchor="middle">output match</text>
  <path class="rf" d="M690,158 H760"/><rect class="bx" x="760" y="130" width="120" height="56" rx="5"/><text class="lb" x="820" y="154" text-anchor="middle">Power meter</text><text class="sub" x="820" y="173" text-anchor="middle">50 Ω load</text>
  <rect class="bx" x="380" y="20" width="140" height="44" rx="5"/><text class="lb" x="450" y="47" text-anchor="middle">Drain supply V_DD</text>
  <path class="dc" d="M450,64 V110"/>
  <rect class="bx" x="200" y="240" width="140" height="44" rx="5"/><text class="lb" x="270" y="267" text-anchor="middle">Gate bias −V_G</text>
  <path class="dc" d="M340,262 H420 V210"/>
  <path class="w" d="M480,210 V290 H460 M465,296 H495 M472,302 H488"/>`,
  },
  tps: [{ n: 1, x: 340, y: 158, label: "gate" }, { n: 2, x: 450, y: 88, label: "drain DC" }, { n: 3, x: 450, y: 230, label: "2DEG" }, { n: 4, x: 730, y: 158, label: "RF output" }],
  sections: [{ k: "dc", t: "DC characterisation", n: "Per millimetre of gate width." }, { k: "rf", t: "As a power amplifier", n: "" }],
  cards: [
    { id: "tp1", tp: 1, s: "dc", d: "ph", dn: "transfer", t: "Transfer: I_D and g_m vs V_G", x: "Depletion mode: the device is on at V_G = 0 and pinches off at a negative threshold.", eq: "I<sub>D</sub> ≈ q·n<sub>s</sub>(V<sub>G</sub>)·v<sub>sat</sub>·W,&nbsp; n<sub>s</sub> ≈ (ε<sub>AlGaN</sub>/qd)(V<sub>G</sub> − V<sub>th</sub>)" },
    { id: "tp2", tp: 2, s: "dc", d: "rf", dn: "output", t: "Output curves with self-heating", x: "I_D vs V_D for V_G = −3 … +1 V. The droop at high power is self-heating: hot electrons scatter more.", eq: "T<sub>ch</sub> = T<sub>base</sub> + R<sub>th</sub>·P<sub>diss</sub>,&nbsp; µ ∝ T<sup>−1.5</sup>", h: "tall" },
    { id: "tp3", tp: 3, s: "dc", d: "ok", dn: "2DEG", t: "2DEG density vs gate voltage", x: "Sheet density of the electron gas for three Al fractions. Marker: current bias.", eq: "q·n<sub>s</sub>(0) ≈ σ<sub>pol</sub> − (ε/d)(φ<sub>B</sub> − ΔE<sub>c</sub>),&nbsp; σ<sub>pol</sub> ∝ x<sub>Al</sub>" },
    { id: "tp4", tp: 4, s: "rf", d: "rf", dn: "RF", t: "Output power and efficiency vs input power", x: "Pout with gain compression and power-added efficiency. Saturated power scales with V_DD and gate width.", eq: "P<sub>sat</sub> ≈ (V<sub>DD</sub> − V<sub>knee</sub>)·I<sub>max</sub>/8,&nbsp; PAE = (P<sub>out</sub> − P<sub>in</sub>)/P<sub>DC</sub>", h: "tall" },
    { id: "a1", chip: "W/mm", s: "rf", d: "an", dn: "materials", t: "Power density vs supply voltage", x: "Why GaN: a wide band gap allows 5–10× higher V_DD than GaAs, and the 2DEG gives high current, so power per mm is much larger.", eq: "P/W ∝ I<sub>max</sub>·(V<sub>br</sub> − V<sub>knee</sub>)/8" },
  ],
  foot: "Model: n_s from a charge-control law (effective barrier calibrated to the Poisson solution), v_sat = 1.3×10⁷ cm/s, R_S + R_D = 0.95 Ω·mm, thermal resistance 12 K·mm/W, gain 18 dB with tanh compression, class-AB quiescent current 80 mA/mm. Trapping (current collapse) is not modelled. Illustrative values.",
  sim(st) {
    const C = compact(st.x), o = { x: st.x, T: st.T };
    const R = { C, op: idDC(st.VG, st.VD, o) };
    R.vg = linspace(-6, 2, 121); R.idg = map(R.vg, (v) => idDC(v, st.VD, o).Id);
    R.gm = map(R.vg, (v, i) => (i === 0 ? 0 : (R.idg[i] - R.idg[i - 1]) / (R.vg[i] - R.vg[i - 1]) * 1000));
    R.vd = linspace(0, 50, 101);
    R.fam = [-3, -2, -1, 0, 1].map((vg) => map(R.vd, (v) => idDC(vg, v, o).Id));
    R.ns = [0.15, 0.25, 0.35].map((x) => { const c = compact(x); return map(R.vg, (v) => c.ns(v) / 1e12); });
    R.rf = rf(st);
    R.vdd = linspace(5, 60, 56);
    R.pd = { GaN: map(R.vdd, (v) => (v <= 100 ? (Math.max(v - 4, 0) * 1.0) / 8 : NaN)), GaAs: map(R.vdd, (v) => (v <= 12 ? (Math.max(v - 1, 0) * 0.5) / 8 : NaN)), LDMOS: map(R.vdd, (v) => (v <= 50 ? (Math.max(v - 3, 0) * 0.2) / 8 : NaN)) };
    return R;
  },
  render(R, api) {
    const { st, C } = api, F = R.rf;
    api.status([["I_D (per mm)", fSI(R.op.Id, "A") + "/mm", ""], ["Threshold", f(R.C.Vth, 2) + " V", ""], ["Channel temperature", R.op.T.toFixed(0) + " °C", R.op.T > 200 ? "warn" : ""],
      ["P_sat", (10 * Math.log10(F.Psat) + 30).toFixed(1) + " dBm (" + F.Psat.toFixed(1) + " W)", ""], ["Power density", (F.Psat / st.Wmm).toFixed(1) + " W/mm", ""], ["Peak PAE", Math.max(...F.pae).toFixed(0) + " %", ""]]);
    api.q(".hemttxt").textContent = `W = ${st.Wmm} mm, x_Al = ${(st.x * 100).toFixed(0)} %`;
    api.plot("tp1", { xmin: -6, xmax: 2, ymin: 0, xlabel: "V_G (V)", ylabel: "I_D (A/mm) · g_m (S/mm ÷ 1000)", legend: true, series: [{ x: R.vg, y: R.idg, color: C.ph, w: 2.2, label: "I_D" }, { x: R.vg, y: map(R.gm, (g) => g / 1000), color: C.ok, w: 1.6, dash: [4, 3], label: "g_m" }], vlines: [{ x: R.C.Vth, color: C.muted, dash: [2, 3], label: "V_th" }], points: [{ x: st.VG, y: R.op.Id, color: C.ink }] });
    api.ro("tp1", [["I_D", fSI(R.op.Id, "A") + "/mm"], ["Peak g_m", Math.max(...R.gm).toFixed(0) + " mS/mm"], ["V_th", f(R.C.Vth, 2) + " V"]]);
    api.plot("tp2", { xmin: 0, xmax: 50, ymin: 0, xlabel: "V_D (V)", ylabel: "I_D (A/mm)", series: R.fam.map((y, i) => ({ x: R.vd, y, color: i === 3 ? C.ink : C.muted, w: i === 3 ? 2 : 1.2 })), points: [{ x: st.VD, y: R.op.Id, color: C.rf }], labels: [-3, -2, -1, 0, 1].map((vg, i) => ({ x: 49, y: R.fam[i][100], text: vg + " V", align: "right", dy: -7 })) });
    api.ro("tp2", [["Channel T at op", R.op.T.toFixed(0) + " °C"], ["P_diss", (R.op.Id * st.VD).toFixed(1) + " W/mm"]]);
    api.plot("tp3", { xmin: -6, xmax: 2, ymin: 0, xlabel: "V_G (V)", ylabel: "n_s (10¹² cm⁻²)", legend: true, series: R.ns.map((y, i) => ({ x: R.vg, y, color: [C.ok, C.dc, C.bad][i], w: 1.8, label: ["15 % Al", "25 % Al", "35 % Al"][i] })), points: [{ x: st.VG, y: R.C.ns(st.VG) / 1e12, color: C.ink }] });
    api.ro("tp3", [["n_s at V_G", (R.C.ns(st.VG) / 1e12).toFixed(2) + "×10¹² cm⁻²"], ["σ_pol/q", (sigma(st.x) / 1e12).toFixed(1) + "×10¹² cm⁻²"]]);
    api.plot("tp4", { xmin: -10, xmax: 40, xlabel: "P_in (dBm)", ylabel: "P_out (dBm) · PAE (%)", legend: true, series: [{ x: F.pin, y: F.pout, color: C.rf, w: 2.2, label: "P_out" }, { x: F.pin, y: F.pae, color: C.ok, w: 1.8, label: "PAE %" }, { x: F.pin, y: map(F.pin, (p) => p + 18), color: C.muted, w: 1, dash: [3, 3], label: "linear gain" }], hlines: [{ y: 10 * Math.log10(F.Psat) + 30, color: C.muted, dash: [2, 3], label: "P_sat" }] });
    api.eqv("tp4", `P_sat = (${st.VDD} − 4 V)·${F.Imax.toFixed(2)} A/mm/8·${st.Wmm} mm = ${F.Psat.toFixed(1)} W; R_opt = ${F.Ropt.toFixed(1)} Ω`);
    api.ro("tp4", [["P_sat", F.Psat.toFixed(1) + " W"], ["Peak PAE", Math.max(...F.pae).toFixed(0) + " %"], ["Optimum load", F.Ropt.toFixed(1) + " Ω"]]);
    api.plot("a1", { xmin: 5, xmax: 60, ymin: 0, xlabel: "V_DD (V)", ylabel: "P/W (W/mm)", legend: true, series: [{ x: R.vdd, y: R.pd.GaN, color: C.rf, w: 2.2, label: "GaN HEMT" }, { x: R.vdd, y: R.pd.LDMOS, color: C.dc, w: 1.6, label: "Si LDMOS" }, { x: R.vdd, y: R.pd.GaAs, color: C.ph, w: 1.6, label: "GaAs pHEMT" }], points: [{ x: st.VDD, y: F.Psat / st.Wmm, color: C.ink }] });
    api.ro("a1", [["This design", (F.Psat / st.Wmm).toFixed(1) + " W/mm"]]);
  },
};

export default { atomic, bench };
