// FD-SOI n-MOSFET (28 nm-class UTBB): 7 nm undoped film on a 25 nm BOX with a p+ ground plane as back gate.
import { buildGrid, solvePoisson, ekvId, lateralChannel, visDensity, fSI, f, Ut300 } from "../lib/physics.js";
import { linspace, map } from "../lib/plot.js";

// ---------- compact model (bench) ----------
const P = { Vt0: 0.45, gamma: 0.07, n: 1.22, beta: 1.6e-2, dibl: 0.07, lambda: 0.12, theta: 1.4, Wum: 1, Lnm: 30, Cox: 2.8e-6 /* F/cm² (EOT 1.2 nm) */ };
const tempParams = (Tc) => {
  const T = Tc + 273.15, Ut = Ut300 * T / 300;
  return { Ut, dVt: -0.0009 * (T - 300), mu: Math.pow(T / 300, -1.5) };
};
function params(st) {
  const tp = tempParams(st.T);
  return { Vt: P.Vt0 - P.gamma * st.VBB + tp.dVt, n: P.n, beta: P.beta * tp.mu, Ut: tp.Ut, dibl: P.dibl, lambda: P.lambda, theta: P.theta };
}
const Id = (VG, VD, p) => ekvId(VG, VD, p);
function ssAt(p) { // subthreshold slope, mV/dec, from two low-current points
  const a = Id(p.Vt - 0.25, 0.05, p), b = Id(p.Vt - 0.15, 0.05, p);
  return 100 / Math.log10(b / a);
}
function vtCC(p, VD) { // constant-current threshold: Id = 100 nA·W/L
  const target = 1e-7 * P.Wum / (P.Lnm / 1000);
  let lo = -1, hi = 2;
  for (let k = 0; k < 50; k++) { const m = (lo + hi) / 2; if (Id(m, VD, p) > target) hi = m; else lo = m; }
  return (lo + hi) / 2;
}

// ---------- atomic model: vertical Poisson through the gate ----------
const WF = 4.63;
function vertical(VG, VBB) {
  const g = buildGrid([
    { mat: "SiO2", t: 1.2, dx: 0.3, label: "ox" },
    { mat: "Si", t: 7, N: -1e15, dx: 0.35, label: "Si film" },
    { mat: "SiO2", t: 25, dx: 1.5, label: "BOX" },
    { mat: "Si", t: 50, N: -1e18, dx: 1.5, phin: VBB, phip: VBB, label: "p+ GP" },
  ]);
  const s = solvePoisson(g, { left: { type: "gate", V: VG, wf: WF }, right: { type: "ohmic", V: VBB } });
  return { g, s };
}
function filmStats(V) {
  const { g, s } = V;
  let ns = 0, ysum = 0, Ecmid = 0, cnt = 0;
  for (let i = 1; i < g.x.length; i++) if (g.x[i] >= 1.2 && g.x[i] <= 8.2) {
    const dx = (g.x[i] - g.x[i - 1]) * 1e-7;
    ns += s.n[i] * dx; ysum += s.n[i] * dx * (g.x[i] - 1.2);
    if (Math.abs(g.x[i] - 4.7) < 0.6) { Ecmid += s.Ec[i]; cnt++; }
  }
  return { ns, yc: ns > 0 ? ysum / ns : 3.5, Ecmid: Ecmid / Math.max(cnt, 1) };
}
// lateral profile along the film: natural-length solution between source and drain barriers
const LS = 40, LG = 30, LD = 40, LAM = 6;
const lateral = (Ecch, VD, Ut) => lateralChannel({ Ecch, VD, Ut, LS, LG, LD, lam: LAM });

// ---------- shared controls ----------
const fmtV = (v) => f(v, 2) + " V";

const atomic = {
  intro: "A 7 nm silicon film sits on a 25 nm buried oxide. The front gate and the back gate (the p⁺ ground plane under the BOX) both pull on the same thin channel. Hover the cross-section to see the crystal; switch the cut to see the bands vertically or along the channel. Not to scale.",
  controls: [
    { label: "Front gate", color: "ph", items: [{ id: "VG", label: "Gate voltage V_G", min: -0.4, max: 1.2, step: 0.01, value: 0.7, fmt: fmtV }] },
    { label: "Drain", color: "rf", items: [{ id: "VD", label: "Drain voltage V_D", min: 0, max: 1, step: 0.01, value: 0.5, fmt: fmtV }] },
    { label: "Back gate (ground plane)", color: "dc", items: [{ id: "VBB", label: "Back bias V_BB", min: -3, max: 3, step: 0.1, value: 0, fmt: fmtV }, { type: "note", text: "Forward back bias (V_BB > 0) lowers V_t: faster, leakier." }] },
  ],
  presets: [
    { label: "Off state", set: { VG: 0, VD: 1, VBB: 0 } },
    { label: "On, linear", set: { VG: 1, VD: 0.05, VBB: 0 } },
    { label: "On, saturation", set: { VG: 0.9, VD: 1, VBB: 0 } },
    { label: "Forward back bias", set: { VG: 0.35, VD: 0.5, VBB: 2.5 } },
    { label: "Reverse back bias", set: { VG: 0.35, VD: 0.5, VBB: -2.5 } },
  ],
  look: [
    "Raise V_G from 0 to 1 V on the vertical cut: the conduction band Ec in the film bends down to the Fermi level and electrons appear (inversion).",
    "Keep V_G at 0.35 V and move V_BB from −3 to +3 V: the back gate alone switches the channel on. That is FD-SOI's body-bias knob.",
    "On the channel cut, increase V_D: the source barrier drops a little (drain-induced barrier lowering) and electrons pour over it.",
    "With the lens on the BOX, compare amorphous SiO₂ to the silicon lattice; with the lens on the channel, watch the free electrons appear when the device turns on.",
  ],
  world: { w: 160, h: 100 }, aspect: "16/10", lensAt: [80, 34],
  cuts: [{ id: "vert", label: "Vertical (gate → substrate)", a: [80, 26], b: [80, 71] }, { id: "lat", label: "Along the channel (S → D)", a: [12, 35], b: [148, 35] }],
  solve(st) {
    const V = vertical(st.VG, st.VBB);
    const fs = filmStats(V);
    const p = params({ ...st, T: 25 });
    return { V, fs, p, id: Id(st.VG, st.VD, p), lat: lateral(fs.Ecmid, st.VD, p.Ut) };
  },
  scene(S, st) {
    const inv = visDensity(S.fs.ns / 7e-7, 14, 19.5);           // film electron density → 0..1
    const depth = Math.max(0.1, Math.min(0.9, S.fs.yc / 7));    // centroid position in the film
    const v = Math.min(60, Math.max(0, Math.log10(S.id * 1e12 + 1) * 6)) * (st.VD > 0.005 ? 1 : 0);
    const chY = 30 + depth * 10 - 2.5;
    const zones = [
      { id: "s", type: "e", x: 10, y: 20, w: 48, h: 20, dens: 0.95, jit: 0.12 },
      { id: "d", type: "e", x: 102, y: 20, w: 48, h: 20, dens: 0.95, jit: 0.12 },
      { id: "ch", type: "e", x: 60, y: Math.max(30, chY), w: 40, h: 5, dens: inv, vx: v, jit: 0.3 },
      { id: "gp", type: "h", x: 10, y: 57, w: 140, h: 15, dens: 0.75, jit: 0.15 },
      { id: "sub", type: "h", x: 10, y: 72, w: 140, h: 27, dens: 0.35, jit: 0.1 },
    ];
    const arrows = [];
    if (Math.abs(st.VG) > 0.05) arrows.push({ x1: 80, y1: 22, x2: 80, y2: st.VG > 0 ? 29 : 23, color: "ph", label: st.VG > 0 ? "" : "" });
    if (Math.abs(st.VBB) > 0.2) arrows.push(st.VBB > 0 ? { x1: 125, y1: 54, x2: 125, y2: 43, color: "dc", label: "back-gate field" } : { x1: 125, y1: 43, x2: 125, y2: 54, color: "dc", label: "back-gate field" });
    if (S.id > 1e-7 && st.VD > 0.01) arrows.push({ x1: 64, y1: 46, x2: 96, y2: 46, color: "e", lw: 1.6, label: "" });
    return {
      regions: [
        { x: 10, y: 72, w: 140, h: 28, mat: "si", dop: "p", label: "p-substrate" },
        { x: 10, y: 56, w: 140, h: 16, mat: "si", dop: "p+" },
        { x: 10, y: 40, w: 140, h: 16, mat: "box" },
        { x: 10, y: 30, w: 50, h: 10, mat: "si", dop: "n+" },
        { x: 60, y: 30, w: 40, h: 10, mat: "si", dop: "i" },
        { x: 100, y: 30, w: 50, h: 10, mat: "si", dop: "n+" },
        { x: 10, y: 20, w: 46, h: 10, mat: "si", dop: "n+" },
        { x: 104, y: 20, w: 46, h: 10, mat: "si", dop: "n+" },
        { x: 56, y: 12, w: 4, h: 18, mat: "ox" },
        { x: 100, y: 12, w: 4, h: 18, mat: "ox" },
        { x: 60, y: 26, w: 40, h: 4, mat: "ox" },
        { x: 60, y: 8, w: 40, h: 18, mat: "metal" },
      ],
      depl: inv < 0.35 ? [{ x: 60, y: 30, w: 40, h: 10 }] : [],
      zones, arrows,
      labels: [
        { x: 80, y: 17, text: "gate (metal)", size: 10 },
        { x: 34, y: 25, text: "n⁺ source", size: 10 }, { x: 126, y: 25, text: "n⁺ drain", size: 10 },
        { x: 80, y: 48, text: "BOX · 25 nm SiO₂", size: 10, color: "muted" },
        { x: 30, y: 64, text: "p⁺ ground plane", size: 10 }, { x: 30, y: 92, text: "p-substrate", size: 10, color: "muted" },
        { x: 80, y: 37.5, text: "7 nm film", size: 8.5, color: "muted" },
      ],
      terminals: [
        { x: 80, y: 4, text: `G ${f(st.VG, 2)} V` }, { x: 26, y: 13, text: "S 0 V" }, { x: 134, y: 13, text: `D ${f(st.VD, 2)} V` }, { x: 136, y: 92, text: `BB ${f(st.VBB, 1)} V` },
      ],
    };
  },
  bands(S, st, cut) {
    if (cut === "vert") {
      const { g, s } = S.V;
      const x = map(s.x, (v) => v);
      return { x, Ec: s.Ec, Ev: s.Ev, EFn: s.EFn, EFp: s.EFp, n: s.n, p: s.p, E: s.E, Nabs: map(g.N, Math.abs),
        regions: [{ x0: 0, x1: 1.2, label: "" }, { x0: 1.2, x1: 8.2, label: "film" }, { x0: 8.2, x1: 33.2, label: "BOX" }, { x0: 33.2, x1: 83.2, label: "p⁺ ground plane" }],
        xlabel: "depth from gate (nm)", clip: [-4, 4] };
    }
    const L = S.lat;
    return { ...L, regions: [{ x0: 0, x1: LS, label: "source" }, { x0: LS, x1: LS + LG, label: "channel" }, { x0: LS + LG, x1: LS + LG + LD, label: "drain" }], xlabel: "position along film (nm)" };
  },
  readouts(S, st) {
    const p = S.p;
    return [["Sheet electrons", (S.fs.ns).toExponential(1) + " cm⁻²"], ["Electron centroid", S.fs.yc.toFixed(1) + " nm below oxide"], ["V_t (model)", f(p.Vt, 3) + " V"],
      ["I_D (W = 1 µm)", fSI(S.id, "A")], ["Region", st.VG < p.Vt ? "sub-threshold" : st.VD < st.VG - p.Vt ? "linear" : "saturation"]];
  },
  foot: "Vertical cut: 1D Poisson with Boltzmann statistics (gate EOT 1.2 nm, film 7 nm undoped, BOX 25 nm, p⁺ ground plane 10¹⁸ cm⁻³), electron quasi-Fermi level of the source. Lateral cut: natural-length solution between source and drain barriers (λ = 6 nm). Quantum confinement is ignored. Illustrative values.",
};

// ---------- bench ----------
const VGs = linspace(-0.2, 1.1, 131);
const bench = {
  intro: "A parameter analyser drives the transistor's four terminals. Sweep the front gate, set the drain and the back gate, and follow each test point.",
  controls: [
    { label: "Gate SMU (TP1)", color: "ph", items: [{ id: "VG", label: "Gate voltage V_G", min: -0.2, max: 1.1, step: 0.01, value: 0.8, fmt: fmtV }] },
    { label: "Drain SMU (TP2)", color: "rf", items: [{ id: "VD", label: "Drain voltage V_D", min: 0, max: 1.1, step: 0.01, value: 0.9, fmt: fmtV }] },
    { label: "Back-gate supply (TP3)", color: "dc", items: [{ id: "VBB", label: "Back bias V_BB", min: -3, max: 3, step: 0.1, value: 0, fmt: fmtV }] },
    { label: "Chuck temperature", color: "heat", items: [{ id: "T", label: "Temperature", min: -40, max: 125, step: 5, value: 25, fmt: (v) => v + " °C" }] },
  ],
  presets: [
    { label: "Nominal: V_G = V_D = 0.9 V", set: { VG: 0.9, VD: 0.9, VBB: 0, T: 25 } },
    { label: "Turbo: FBB +2 V", set: { VG: 0.9, VD: 0.9, VBB: 2, T: 25 } },
    { label: "Sleep: RBB −3 V, off", set: { VG: 0, VD: 0.9, VBB: -3, T: 25 } },
    { label: "Hot leakage, 125 °C", set: { VG: 0, VD: 0.9, VBB: 0, T: 125 } },
  ],
  schematic: {
    viewBox: "0 0 900 330",
    svg: `
  <rect class="bx" x="30" y="135" width="150" height="60" rx="5"/><text class="lb" x="105" y="161" text-anchor="middle">Gate SMU</text><text class="sub" x="105" y="181" text-anchor="middle">V_G sweep</text>
  <rect class="bx" x="470" y="18" width="160" height="56" rx="5"/><text class="lb" x="550" y="42" text-anchor="middle">Drain SMU</text><text class="sub" x="550" y="61" text-anchor="middle">V_D, measures I_D</text>
  <rect class="bx" x="690" y="230" width="180" height="60" rx="5"/><text class="lb" x="780" y="256" text-anchor="middle">Back-gate supply</text><text class="sub" x="780" y="276" text-anchor="middle">V_BB, −3…+3 V</text>
  <path class="w" d="M180,165 H395"/>
  <path class="w" d="M395,120 V210"/>
  <rect class="dev" x="410" y="110" width="120" height="110" rx="4"/>
  <path class="w" d="M425,120 V210" stroke-width="3"/>
  <text class="sub" x="470" y="160" text-anchor="middle">film</text>
  <rect x="425" y="196" width="105" height="14" fill="var(--m-box)" stroke="var(--edge)"/><text class="sub" x="478" y="207" text-anchor="middle">BOX</text>
  <path class="w" d="M425,130 H550 V74"/>
  <path class="w" d="M425,200 H460 V300 H440 M445,306 H475 M452,312 H468"/>
  <text class="sub" x="470" y="296">source (0 V)</text>
  <path class="dc" d="M478,220 V260 H690"/>
  <text class="cap" x="500" y="315">back gate = p⁺ ground plane under the BOX</text>
  <text class="cap" x="580" y="140">I_D flows drain → source</text>
  <text class="lb" x="470" y="104" text-anchor="middle">FD-SOI nFET</text>
  <text class="sub" x="470" y="236" text-anchor="middle">W = 1 µm, L = 30 nm</text>`,
  },
  tps: [{ n: 1, x: 300, y: 165, label: "gate" }, { n: 2, x: 550, y: 100, label: "drain current" }, { n: 3, x: 620, y: 260, label: "back gate" }, { n: 4, x: 470, y: 180, label: "channel" }],
  sections: [{ k: "tp", t: "Test points", n: "What each instrument and the channel see right now." }, { k: "fom", t: "Figures of merit", n: "Why FD-SOI's back gate matters: speed vs leakage, set after fabrication." }],
  cards: [
    { id: "tp1", tp: 1, s: "tp", d: "ph", dn: "transfer", t: "Gate sweep: I_D vs V_G", x: "Log scale shows sub-threshold (straight line) and strong inversion (bends over). Grey: V_BB = −2, 0, +2 V for comparison.", eq: "I<sub>D</sub> = 2nβU<sub>T</sub>²[ F(v<sub>p</sub>) − F(v<sub>p</sub> − V<sub>D</sub>/U<sub>T</sub>) ],&nbsp; F(v) = ln²(1 + e<sup>v/2</sup>)<br>v<sub>p</sub> = (V<sub>G</sub> − V<sub>t</sub>)/(nU<sub>T</sub>),&nbsp; SS = n·U<sub>T</sub>·ln10", h: "tall" },
    { id: "tp2", tp: 2, s: "tp", d: "rf", dn: "output", t: "Drain SMU: I_D vs V_D", x: "Output curves for V_G = 0.4 … 1.1 V. Linear at low V_D, then saturation once the channel pinches off at the drain.", eq: "linear: I<sub>D</sub> ≈ β(V<sub>G</sub> − V<sub>t</sub> − V<sub>D</sub>/2)V<sub>D</sub><br>saturation: I<sub>D</sub> ≈ β(V<sub>G</sub> − V<sub>t</sub>)²/(2n) · (1 + λV<sub>D</sub>)", h: "tall" },
    { id: "tp3", tp: 3, s: "tp", d: "dc", dn: "body bias", t: "Back gate: V_t vs V_BB", x: "The ground plane couples to the channel through the BOX: a capacitive divider sets the slope (body factor).", eq: "V<sub>t</sub> = V<sub>t0</sub> − γ·V<sub>BB</sub> − DIBL·V<sub>D</sub>,&nbsp; γ ≈ C<sub>BOX</sub>/C<sub>ox</sub> ≈ t<sub>ox</sub>/t<sub>BOX</sub>·(ε)" },
    { id: "tp4", tp: 4, s: "tp", d: "ph", dn: "channel", t: "Channel: inversion charge from source to drain", x: "Electrons per cm² along the channel. In saturation the charge collapses near the drain (pinch-off).", eq: "q(x)² + q(x) = i<sub>f</sub> − (x/L)(i<sub>f</sub> − i<sub>r</sub>),&nbsp; Q<sub>i</sub> = 2nC<sub>ox</sub>U<sub>T</sub>·q" },
    { id: "a1", chip: "g_m/I_D", s: "fom", d: "an", dn: "analog", t: "Transconductance efficiency", x: "g_m/I_D vs V_G: highest in weak inversion (≈ 1/(nU_T)), lower in strong inversion. Analog designers bias on this curve.", eq: "g<sub>m</sub>/I<sub>D</sub> = ∂ ln I<sub>D</sub>/∂V<sub>G</sub> ≤ 1/(nU<sub>T</sub>)" },
    { id: "a2", chip: "I_on–I_off", s: "fom", d: "an", dn: "trade-off", t: "Speed vs leakage with back bias", x: "Each point is a V_BB from −3 to +3 V. Forward bias moves right (more drive, more leakage); reverse bias moves left.", eq: "I<sub>on</sub> = I<sub>D</sub>(V<sub>DD</sub>, V<sub>DD</sub>),&nbsp; I<sub>off</sub> = I<sub>D</sub>(0, V<sub>DD</sub>) ∝ 10<sup>−V<sub>t</sub>/SS</sup>" },
  ],
  foot: "Model: EKV-style charge-based current with V_t0 = 0.45 V, n = 1.22, body factor γ = 70 mV/V, DIBL = 70 mV/V, mobility degradation θ = 1.4 V⁻¹, CLM λ = 0.12 V⁻¹, V_t drift −0.9 mV/K and µ ∝ T^−1.5. W = 1 µm, L = 30 nm. Illustrative, not from a PDK.",
  sim(st) {
    const p = params(st);
    const R = { p };
    R.id = Id(st.VG, st.VD, p);
    R.idg = map(VGs, (v) => Id(v, st.VD, p));
    R.cmp = [-2, 0, 2].map((bb) => map(VGs, (v) => Id(v, st.VD, params({ ...st, VBB: bb }))));
    R.vt = vtCC(p, st.VD);
    R.ss = ssAt(p);
    const h = 1e-3;
    R.gm = (Id(st.VG + h, st.VD, p) - Id(st.VG - h, st.VD, p)) / (2 * h);
    R.gds = (Id(st.VG, st.VD + h, p) - Id(st.VG, Math.max(0, st.VD - h), p)) / (2 * h);
    R.vds = linspace(0, 1.1, 111);
    R.fam = [0.4, 0.55, 0.7, 0.85, 1.0, 1.1].map((vg) => ({ vg, y: map(R.vds, (vd) => Id(vg, vd, p)) }));
    R.cur = map(R.vds, (vd) => Id(st.VG, vd, p));
    R.vbb = linspace(-3, 3, 61);
    R.vtb = map(R.vbb, (bb) => vtCC(params({ ...st, VBB: bb }), st.VD));
    R.gmid = map(VGs, (v) => { const a = Id(v + h, st.VD, p), b = Id(v - h, st.VD, p); return Math.log(a / b) / (2 * h); });
    const VDD = 0.9;
    R.ion = map(R.vbb, (bb) => Id(VDD, VDD, params({ ...st, VBB: bb })));
    R.ioff = map(R.vbb, (bb) => Id(0, VDD, params({ ...st, VBB: bb })));
    R.ionNow = Id(VDD, VDD, p); R.ioffNow = Id(0, VDD, p);
    // inversion charge along channel (normalised EKV charge)
    const F = (v) => { const l = v > 30 ? v / 2 : Math.log1p(Math.exp(v / 2)); return l * l; };
    const Vt = p.Vt - p.dibl * st.VD, vp = (st.VG - Vt) / p.n;
    const iF = F(vp / p.Ut), iR = F((vp - st.VD) / p.Ut);
    const qOf = (i) => (-1 + Math.sqrt(1 + 4 * Math.max(i, 0))) / 2;
    const qs = qOf(iF), qd = qOf(iR), ks = qs * qs + qs, kd = qd * qd + qd;
    R.xc = linspace(0, 1, 101);
    R.qi = map(R.xc, (xx) => (2 * p.n * P.Cox * p.Ut * qOf(ks - xx * (ks - kd))) / 1.602e-19);
    R.region = st.VG < R.vt ? "Sub-threshold" : st.VD < (st.VG - R.vt) / p.n ? "Linear" : "Saturation";
    return R;
  },
  render(R, api) {
    const { st, C } = api, p = R.p;
    api.status([
      ["Operating region", R.region, ""], ["I_D", fSI(R.id, "A"), ""], ["V_t (100 nA·W/L)", f(R.vt, 3) + " V", ""],
      ["SS", R.ss.toFixed(1) + " mV/dec", ""], ["g_m", fSI(R.gm, "S"), ""], ["I_on / I_off @ 0.9 V", (R.ionNow / R.ioffNow).toExponential(1), R.ionNow / R.ioffNow < 1e4 ? "warn" : "good"],
    ]);
    api.q(".dev")?.setAttribute("style", R.id > 1e-6 ? "fill:color-mix(in srgb,var(--ph) 22%,var(--panel))" : "");
    // TP1
    api.plot("tp1", { xmin: -0.2, xmax: 1.1, ylog: true, ymin: 1e-13, ymax: 3e-3, xlabel: "V_G (V)", ylabel: "I_D (A)",
      series: [...R.cmp.map((y) => ({ x: VGs, y, color: C.muted, w: 1, dash: [3, 3] })), { x: VGs, y: R.idg, color: C.ph, w: 2.2 }],
      vlines: [{ x: R.vt, color: C.ph, dash: [2, 3], label: "V_t" }], points: [{ x: st.VG, y: Math.max(R.id, 1e-13), color: C.ink }] });
    api.eqv("tp1", `V_t = ${f(R.vt, 3)} V, n = ${p.n}, SS = ${R.ss.toFixed(1)} mV/dec → I_D = ${fSI(R.id, "A")}`);
    api.ro("tp1", [["V_G", fmtV(st.VG)], ["I_D", fSI(R.id, "A")], ["log I_D", Math.log10(R.id).toFixed(2)], ["SS", R.ss.toFixed(1) + " mV/dec"]]);
    // TP2
    api.plot("tp2", { xmin: 0, xmax: 1.1, ymin: 0, xlabel: "V_D (V)", ylabel: "I_D (mA)",
      series: [...R.fam.map((c) => ({ x: R.vds, y: map(c.y, (v) => v * 1e3), color: C.muted, w: 1 })), { x: R.vds, y: map(R.cur, (v) => v * 1e3), color: C.rf, w: 2.2 }],
      points: [{ x: st.VD, y: R.id * 1e3, color: C.ink, label: "V_G = " + st.VG.toFixed(2) }],
      vlines: st.VG > R.vt ? [{ x: (st.VG - R.vt) / p.n, color: C.rf, dash: [2, 3], label: "V_Dsat" }] : [] });
    api.eqv("tp2", `V_Dsat ≈ (V_G − V_t)/n = ${f(Math.max(0, (st.VG - R.vt) / p.n), 2)} V, r_out = 1/g_ds = ${fSI(1 / Math.max(R.gds, 1e-15), "Ω")}`);
    api.ro("tp2", [["V_D", fmtV(st.VD)], ["I_D", fSI(R.id, "A")], ["g_ds", fSI(R.gds, "S")], ["Intrinsic gain g_m/g_ds", (R.gm / Math.max(R.gds, 1e-15)).toFixed(1)]]);
    // TP3
    api.plot("tp3", { xmin: -3, xmax: 3, xlabel: "V_BB (V)", ylabel: "V_t (V)", series: [{ x: R.vbb, y: R.vtb, color: C.dc, w: 2.2 }],
      points: [{ x: st.VBB, y: R.vt, color: C.ink }], hlines: [{ y: 0.45, color: C.muted, dash: [2, 3], label: "V_t0" }] });
    api.eqv("tp3", `V_t = 0.45 − ${P.gamma}·(${f(st.VBB, 1)}) − ${P.dibl}·${f(st.VD, 2)} + ΔV_t(T) ≈ ${f(R.vt, 3)} V`);
    api.ro("tp3", [["V_BB", fmtV(st.VBB)], ["Body factor", P.gamma * 1000 + " mV/V"], ["ΔV_t", (f(-P.gamma * st.VBB * 1000, 0)) + " mV"], ["Mode", st.VBB > 0.05 ? "forward (FBB)" : st.VBB < -0.05 ? "reverse (RBB)" : "none"]]);
    // TP4
    api.plot("tp4", { xmin: 0, xmax: 1, ymin: 0, xlabel: "x / L (source → drain)", ylabel: "Q_i/q (10¹² cm⁻²)", series: [{ x: R.xc, y: map(R.qi, (v) => v / 1e12), color: C.ph, w: 2.2, fill: C.ph }] });
    api.eqv("tp4", `source: ${(R.qi[0] / 1e12).toFixed(2)}×10¹² cm⁻², drain: ${(R.qi[100] / 1e12).toFixed(3)}×10¹² cm⁻²`);
    api.ro("tp4", [["At source", (R.qi[0]).toExponential(1) + " cm⁻²"], ["At drain", (R.qi[100]).toExponential(1) + " cm⁻²"], ["Drain/source", (R.qi[100] / Math.max(R.qi[0], 1)).toFixed(2)], ["Pinch-off", R.qi[100] < 0.15 * R.qi[0] ? "yes" : "no"]]);
    // A1
    api.plot("a1", { xmin: -0.2, xmax: 1.1, ymin: 0, xlabel: "V_G (V)", ylabel: "g_m/I_D (V⁻¹)", series: [{ x: VGs, y: R.gmid, color: C.ink, w: 2 }],
      hlines: [{ y: 1 / (p.n * p.Ut), color: C.muted, dash: [3, 3], label: "1/(nU_T)" }], points: [{ x: st.VG, y: R.gm / R.id, color: C.ph }] });
    api.ro("a1", [["g_m/I_D now", (R.gm / R.id).toFixed(1) + " V⁻¹"], ["Weak-inversion limit", (1 / (p.n * p.Ut)).toFixed(1) + " V⁻¹"]]);
    // A2
    api.plot("a2", { xlog: true, ylog: true, xmin: 1e-5, xmax: 3e-3, ymin: 1e-13, ymax: 1e-6, xlabel: "I_on (A)", ylabel: "I_off (A)",
      series: [{ x: R.ion, y: R.ioff, color: C.dc, w: 2 }], points: [{ x: R.ionNow, y: R.ioffNow, color: C.ink, label: "V_BB = " + f(st.VBB, 1) + " V" }] });
    api.ro("a2", [["I_on", fSI(R.ionNow, "A")], ["I_off", fSI(R.ioffNow, "A")], ["Static power / µm", fSI(R.ioffNow * 0.9, "W")]]);
  },
};

export default { atomic, bench };
