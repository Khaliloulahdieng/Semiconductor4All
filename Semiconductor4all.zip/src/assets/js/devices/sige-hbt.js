// SiGe heterojunction bipolar transistor (npn, graded-Ge base), BiCMOS RF class.
import { buildGrid, solvePoisson, depletedSpans, interp, visDensity, fSI, f, Ut300 } from "../lib/physics.js";
import { map, linspace, logspace } from "../lib/plot.js";

const PI = Math.PI, Ut = Ut300;
const DEG = 0.74; // band-gap reduction per unit Ge fraction (eV), mostly in the valence band

// ---------- compact model ----------
const WB = 20e-7, DN = 4.5, VSAT = 1e7, WC = 120e-7;   // cm, cm²/s, cm/s, cm
function params(st) {
  const x = st.ge / 100, dEg = DEG * x, eta = dEg / Ut, dEg0 = DEG * 0.3 * x; // trapezoid: 30 % of the peak at the emitter edge
  const gradeGain = eta > 1e-3 ? eta / (1 - Math.exp(-eta)) : 1;
  const gamma = Math.exp(dEg0 / Ut) * gradeGain; // I_S enhancement over a Si base
  const tauB = eta > 1e-3 ? (WB * WB / DN) * (1 / eta) * (1 - (1 - Math.exp(-eta)) / eta) : WB * WB / (2 * DN);
  return { x, dEg, gamma, tauB, Is: 2e-18 * gamma, beta0: 100 * Math.pow(gamma, 0.6), /* part of the gain is traded for base doping */ VA: 15 + 400 * x, IKF: 12e-3, Ise: 3e-15, re: 3, rb: 45, rc: 20 };
}
// solve the internal junction voltage including emitter and base series resistance
function bjt(VBE, VCE, p) {
  let vbe = VBE, Ic = 0, Ib = 0;
  for (let k = 0; k < 40; k++) {
    const Icf = p.Is * Math.exp(Math.min(vbe, 1.2) / Ut);
    Ic = (Icf / Math.sqrt(1 + Icf / p.IKF)) * (1 + Math.max(VCE - vbe, 0) / p.VA) * (VCE > 0.05 ? 1 - Math.exp(-VCE / 0.08) : VCE / 0.08);
    Ib = Icf / p.beta0 + p.Ise * Math.exp(Math.min(vbe, 1.2) / (2 * Ut));
    const next = VBE - Ib * p.rb - (Ic + Ib) * p.re;
    if (Math.abs(next - vbe) < 1e-7) break;
    vbe = vbe + 0.5 * (next - vbe);
  }
  return { Ic, Ib, vbe };
}
function speed(Ic, VCE, VBE, p) {
  const VCB = Math.max(VCE - VBE, -0.3);
  const Ik = 8e-3 * (1 + Math.max(VCB, 0) / 1.2);
  const tauF = (0.25e-12 + p.tauB + WC / (2 * VSAT)) * (1 + Math.pow(Ic / Ik, 2));
  const Cje = 12e-15, Cbc = 6e-15 / Math.pow(1 + Math.max(VCB, -0.3) / 0.6, 0.33);
  const tot = tauF + ((Cje + Cbc) * Ut) / Math.max(Ic, 1e-12) + (p.re + p.rc) * Cbc;
  const fT = 1 / (2 * PI * tot);
  return { fT, fmax: Math.sqrt(fT / (8 * PI * p.rb * Cbc)), tauF, Cbc, Ik };
}

// ---------- atomic: vertical cut emitter → base → collector ----------
const LE = 80, LEB = 20, LBASE = 20, LC = 300, LSC = 200;
function vertical(VBE, VCE, ge) {
  const x = ge / 100;
  const g = buildGrid([
    { mat: "Si", t: LE, N: 1e20, dx: 2, phin: 0, phip: VBE },
    { mat: "Si", t: LEB, N: 2e18, dx: 0.5, phin: 0, phip: VBE },
    { mat: "Si", t: LBASE, N: -4e19, dx: 0.3, phin: 0, phip: VBE, mods: (z) => ({ Eg: 1.12 - DEG * x * (0.3 + 0.7 * z / LBASE) }) },
    { mat: "Si", t: LC, N: 1e17, dx: 1.5, phin: VCE, phip: VBE },
    { mat: "Si", t: LSC, N: 1e20, dx: 5, phin: VCE, phip: VBE },
  ]);
  return { g, s: solvePoisson(g, { left: { type: "ohmic", V: 0 }, right: { type: "ohmic", V: VCE } }) };
}
const DEP = [0, LE, LE + LEB, LE + LEB + LBASE, LE + LEB + LBASE + LC, LE + LEB + LBASE + LC + LSC];
const YS = [10, 24, 26, 32, 80, 100];
const d2y = (d) => { for (let k = 0; k < 5; k++) if (d <= DEP[k + 1]) return YS[k] + (YS[k + 1] - YS[k]) * (d - DEP[k]) / (DEP[k + 1] - DEP[k]); return YS[5]; };

const atomic = {
  intro: "Cross-section of a SiGe HBT. Electrons are injected from the n⁺ emitter into a very thin p⁺ SiGe base, cross it, and are swept into the collector by the reverse-biased base–collector junction. The germanium grading narrows the band gap toward the collector, building in a field that speeds electrons across the base. Not to scale.",
  controls: [
    { label: "Base–emitter", color: "ph", items: [{ id: "VBE", label: "V_BE", min: 0, max: 0.95, step: 0.01, value: 0.8, fmt: (v) => v.toFixed(2) + " V" }] },
    { label: "Collector–emitter", color: "rf", items: [{ id: "VCE", label: "V_CE", min: 0, max: 3, step: 0.05, value: 1.5, fmt: (v) => v.toFixed(2) + " V" }] },
    { label: "Base material", color: "dc", items: [{ id: "ge", label: "Peak Ge content", min: 0, max: 30, step: 1, value: 25, fmt: (v) => v + " %" }, { type: "note", text: "0 % = an ordinary silicon BJT." }] },
  ],
  presets: [
    { label: "Off (V_BE = 0)", set: { VBE: 0, VCE: 1.5 } }, { label: "Active, SiGe 25 %", set: { VBE: 0.8, VCE: 1.5, ge: 25 } },
    { label: "Active, plain Si", set: { VBE: 0.8, VCE: 1.5, ge: 0 } }, { label: "Saturation (V_CE 0.2 V)", set: { VBE: 0.85, VCE: 0.2 } },
  ],
  look: [
    "Compare 0 % and 25 % Ge on the band diagram: in the base, Ec slopes down toward the collector. That built-in field accelerates electrons and cuts the base transit time.",
    "Raise V_BE: the emitter–base barrier drops by qV_BE and electrons flood the base (Carriers view: the electron density in the base rises a decade every 60 mV).",
    "Lower V_CE to 0.2 V: the base–collector junction becomes forward-biased and the device saturates.",
  ],
  world: { w: 160, h: 120 }, aspect: "4/3", lensAt: [80, 29],
  cuts: [{ id: "vert", label: "Vertical: emitter → base → collector", a: [80, 10], b: [80, 100] }],
  solve(st) {
    const V = vertical(st.VBE, st.VCE, st.ge), p = params(st);
    return { V, p, op: bjt(st.VBE, st.VCE, p), spans: depletedSpans(V.g, V.s, 0.5) };
  },
  scene(S, st) {
    const flow = S.op.Ic > 1e-7 ? Math.min(45, 6 * Math.log10(S.op.Ic * 1e9 + 1)) : 0;
    const inj = S.op.Ic > 1e-9 ? Math.min(0.85, 0.1 + 0.1 * Math.log10(S.op.Ic * 1e9)) : 0;
    const bc = S.spans.find((s) => s[0] > LE + LEB + 5 && s[0] < LE + LEB + LBASE + 5) || S.spans.find((s) => s[1] > LE + LEB + LBASE + 5) || [LE + LEB + LBASE, LE + LEB + LBASE];
    const eb = S.spans.find((s) => s[0] < LE + LEB + 5 && s[1] > LE) || [LE + LEB, LE + LEB];
    const ycb = d2y(bc[1]);
    return {
      regions: [
        { x: 0, y: 100, w: 160, h: 20, mat: "si", dop: "p", label: "p-substrate" },
        { x: 10, y: 80, w: 145, h: 20, mat: "si", dop: "n+" },
        { x: 20, y: 32, w: 120, h: 48, mat: "si", dop: "n" },
        { x: 0, y: 26, w: 20, h: 74, mat: "ox" }, { x: 140, y: 26, w: 8, h: 54, mat: "ox" },
        { x: 148, y: 18, w: 10, h: 62, mat: "si", dop: "n+" },
        { x: 20, y: 26, w: 120, h: 6, mat: "si", dop: "p+", fill: st.ge > 0 ? "m-ge" : undefined },
        { x: 20, y: 18, w: 35, h: 8, mat: "poly", dop: "p+" }, { x: 105, y: 18, w: 35, h: 8, mat: "poly", dop: "p+" },
        { x: 55, y: 10, w: 5, h: 16, mat: "ox" }, { x: 100, y: 10, w: 5, h: 16, mat: "ox" },
        { x: 60, y: 10, w: 40, h: 14, mat: "poly", dop: "n+" }, { x: 60, y: 24, w: 40, h: 2, mat: "si", dop: "n" },
        { x: 65, y: 2, w: 30, h: 8, mat: "metal" }, { x: 27, y: 8, w: 20, h: 10, mat: "metal" }, { x: 113, y: 8, w: 20, h: 10, mat: "metal" }, { x: 148, y: 6, w: 10, h: 12, mat: "metal" },
      ],
      depl: [{ x: 60, y: d2y(eb[0]), w: 40, h: Math.max(0.6, d2y(eb[1]) - d2y(eb[0])) }, { x: 20, y: d2y(bc[0]), w: 120, h: Math.max(0.6, ycb - d2y(bc[0])) }],
      ions: [{ x: 20, y: Math.max(32, d2y(bc[0])), w: 120, h: Math.max(0, ycb - 32), sign: 1, dens: 0.35 }],
      zones: [
        { id: "em", type: "e", x: 60, y: 10, w: 40, h: 14, dens: 0.95, vy: flow * 0.2 },
        { id: "base", type: "h", x: 20, y: 26.3, w: 120, h: 5.4, dens: 0.9, jit: 0.3 },
        { id: "inj", type: "e", x: 62, y: 26, w: 36, h: Math.max(1, ycb - 26), dens: inj, vy: flow, jit: 0.25 },
        { id: "col", type: "e", x: 20, y: ycb, w: 120, h: Math.max(0.5, 80 - ycb), dens: 0.5, vy: flow * 0.3 },
        { id: "sc", type: "e", x: 10, y: 80, w: 145, h: 20, dens: 0.95, vx: flow * 0.3 },
        { id: "sk", type: "e", x: 148, y: 18, w: 10, h: 62, dens: 0.9, vy: -flow * 0.5 },
        { id: "bpoly", type: "h", x: 20, y: 18, w: 35, h: 8, dens: 0.8 }, { id: "bpoly2", type: "h", x: 105, y: 18, w: 35, h: 8, dens: 0.8 },
      ],
      arrows: flow > 0 ? [{ x1: 80, y1: 35, x2: 80, y2: 70, color: "e", label: "e⁻ to collector" }] : [],
      labels: [
        { x: 80, y: 17, text: "n⁺ emitter", size: 10 }, { x: 37, y: 29, text: st.ge > 0 ? "p⁺ SiGe base (20 nm)" : "p⁺ Si base (20 nm)", size: 9, align: "left" },
        { x: 120, y: 60, text: "n collector", size: 10 }, { x: 80, y: 90, text: "n⁺ subcollector", size: 10 }, { x: 80, y: 112, text: "p-substrate", size: 10, color: "muted" },
      ],
      terminals: [{ x: 80, y: 3, text: "E 0 V" }, { x: 30, y: 4, text: `B ${st.VBE.toFixed(2)} V` }, { x: 140, y: 113, text: `C ${st.VCE.toFixed(2)} V` }],
    };
  },
  bands(S) {
    // crop to emitter + base + upper collector so the 20 nm base is visible
    const { g, s } = S.V, x0 = LE - 40, x1 = LE + LEB + LBASE + 180;
    const idx = []; for (let i = 0; i < s.x.length; i++) if (s.x[i] >= x0 && s.x[i] <= x1) idx.push(i);
    const pick = (a) => Float64Array.from(idx, (i) => a[i]);
    return { x: pick(s.x), Ec: pick(s.Ec), Ev: pick(s.Ev), EFn: pick(s.EFn), EFp: pick(s.EFp), n: pick(s.n), p: pick(s.p), E: pick(s.E), Nabs: map(pick(g.N), Math.abs),
      regions: [{ x0, x1: LE + LEB, label: "emitter" }, { x0: LE + LEB, x1: LE + LEB + LBASE, label: "base" }, { x0: LE + LEB + LBASE, x1, label: "collector" }], xlabel: "depth from emitter contact (nm)" };
  },
  readouts(S, st) {
    const sp = speed(S.op.Ic, st.VCE, st.VBE, S.p);
    return [["I_C (1 µm² emitter)", fSI(S.op.Ic, "A")], ["β = I_C/I_B", (S.op.Ic / Math.max(S.op.Ib, 1e-30)).toFixed(0)], ["Base ΔE_g grading", (S.p.dEg * 1000).toFixed(0) + " meV"],
      ["Base transit τ_B", (S.p.tauB * 1e12).toFixed(2) + " ps"], ["f_T", (sp.fT / 1e9).toFixed(0) + " GHz"]];
  },
  foot: "1D Poisson along the emitter axis: n⁺ emitter | 2×10¹⁸ spacer | 20 nm p⁺ base (4×10¹⁹) with Ge graded 0.3→1 × peak (E_g reduced by 0.74 eV per unit Ge fraction) | 10¹⁷ collector | n⁺ subcollector. Electron quasi-Fermi level of the emitter through the base, hole quasi-Fermi level at V_BE. Illustrative values.",
};

// ---------- bench ----------
const VBEs = linspace(0.4, 1.0, 121);
const bench = {
  intro: "Two source-meters bias the base and the collector; a vector network analyser measures the current gain h₂₁ to extract f_T and f_max. Explore what the germanium in the base buys you.",
  controls: [
    { label: "Base SMU (TP1)", color: "ph", items: [{ id: "VBE", label: "V_BE", min: 0.6, max: 0.98, step: 0.005, value: 0.86, fmt: (v) => v.toFixed(3) + " V" }] },
    { label: "Collector SMU (TP2)", color: "rf", items: [{ id: "VCE", label: "V_CE", min: 0, max: 3, step: 0.05, value: 1.5, fmt: (v) => v.toFixed(2) + " V" }] },
    { label: "Base material", color: "dc", items: [{ id: "ge", label: "Peak Ge content", min: 0, max: 30, step: 1, value: 25, fmt: (v) => v + " %" }] },
  ],
  presets: [
    { label: "Peak f_T bias", set: { VBE: 0.88, VCE: 1.5, ge: 25 } },
    { label: "Same bias, plain Si BJT", set: { VBE: 0.88, VCE: 1.5, ge: 0 } },
    { label: "Kirk effect: high current", set: { VBE: 0.96, VCE: 1.0, ge: 25 } },
    { label: "Low-current LNA bias", set: { VBE: 0.78, VCE: 1.5, ge: 25 } },
  ],
  schematic: {
    viewBox: "0 0 900 330",
    svg: `
  <rect class="bx" x="30" y="140" width="140" height="56" rx="5"/><text class="lb" x="100" y="164" text-anchor="middle">Base SMU</text><text class="sub" x="100" y="183" text-anchor="middle">V_BE, reads I_B</text>
  <rect class="bx" x="520" y="18" width="160" height="56" rx="5"/><text class="lb" x="600" y="42" text-anchor="middle">Collector SMU</text><text class="sub" x="600" y="61" text-anchor="middle">V_CE, reads I_C</text>
  <rect class="bx chip" x="250" y="152" width="80" height="32" rx="4"/><text class="lb" x="290" y="173" text-anchor="middle">Bias-tee</text>
  <path class="w" d="M170,168 H250 M330,168 H420"/>
  <circle class="dev" cx="470" cy="168" r="58"/>
  <path class="w" d="M420,168 H448 M448,130 V206" stroke-width="3"/>
  <path class="w" d="M448,150 L500,118 V74 H600 M448,186 L500,218 V290 H480 M485,296 H515 M492,302 H508"/>
  <path class="w" d="M488,212 l12,6 -4,-12" fill="var(--ink)"/>
  <text class="sub" x="510" y="286">emitter</text>
  <text class="lb" x="470" y="250" text-anchor="middle">SiGe HBT</text><text class="sub hbttxt" x="470" y="266" text-anchor="middle"></text>
  <rect class="bx" x="660" y="200" width="200" height="56" rx="5"/><text class="lb" x="760" y="224" text-anchor="middle">VNA, port 1 → 2</text><text class="sub" x="760" y="243" text-anchor="middle">h₂₁(f) → f_T, U(f) → f_max</text>
  <path class="rf" d="M290,184 V300 H760 V256 M560,74 V110 H700 V200" stroke-dasharray="4 3"/>`,
  },
  tps: [{ n: 1, x: 380, y: 168, label: "base drive" }, { n: 2, x: 540, y: 96, label: "collector" }, { n: 3, x: 470, y: 128, label: "current gain" }, { n: 4, x: 700, y: 180, label: "VNA" }],
  sections: [{ k: "tp", t: "Test points", n: "DC first, then high frequency." }, { k: "ana", t: "Why SiGe", n: "The germanium grading is a design knob for speed and gain." }],
  cards: [
    { id: "tp1", tp: 1, s: "tp", d: "ph", dn: "DC", t: "Gummel plot: I_C and I_B vs V_BE", x: "Log scale. I_C rises one decade per ~60 mV (ideal exponential); I_B runs parallel, β below. Dashed: same transistor with a plain Si base.", eq: "I<sub>C</sub> = I<sub>S</sub>·e<sup>V<sub>BE</sub>/U<sub>T</sub></sup>,&nbsp; I<sub>S,SiGe</sub>/I<sub>S,Si</sub> = e<sup>ΔE<sub>g0</sub>/kT</sup>·η/(1−e<sup>−η</sup>),&nbsp; η = ΔE<sub>g,grade</sub>/kT", h: "tall" },
    { id: "tp2", tp: 2, s: "tp", d: "rf", dn: "output", t: "Collector: I_C vs V_CE", x: "Output curves at fixed V_BE steps. The slope in the active region gives the Early voltage; below ~0.3 V the device saturates. High-speed HBTs break down early (BV_CEO).", eq: "I<sub>C</sub> = I<sub>S</sub>e<sup>V<sub>BE</sub>/U<sub>T</sub></sup>(1 + V<sub>CE</sub>/V<sub>A</sub>),&nbsp; V<sub>A</sub> grows with Ge grading", h: "tall" },
    { id: "tp3", tp: 3, s: "tp", d: "ok", dn: "gain", t: "Current gain β vs I_C", x: "β = I_C/I_B: low at small currents (recombination in the junction), flat in the middle, falling at high injection.", eq: "β = I<sub>C</sub>/I<sub>B</sub>,&nbsp; I<sub>B</sub> = I<sub>C0</sub>/β<sub>0</sub> + I<sub>SE</sub>e<sup>V<sub>BE</sub>/2U<sub>T</sub></sup>" },
    { id: "tp4", tp: 4, s: "tp", d: "opt", dn: "RF", t: "VNA: f_T and f_max vs I_C", x: "f_T rises with current (junction capacitances charge faster), peaks, then drops when the Kirk effect pushes the base into the collector.", eq: "1/(2πf<sub>T</sub>) = τ<sub>F</sub> + (C<sub>je</sub>+C<sub>bc</sub>)U<sub>T</sub>/I<sub>C</sub> + (r<sub>e</sub>+r<sub>c</sub>)C<sub>bc</sub><br>f<sub>max</sub> = <span class=\"rt\">√</span><span class=\"rad\">f<sub>T</sub>/(8πr<sub>b</sub>C<sub>bc</sub>)</span>", h: "tall" },
    { id: "a1", chip: "τ_B(Ge)", s: "ana", d: "an", dn: "grading", t: "Base transit time vs Ge grading", x: "A linearly graded band gap creates a drift field in the base. Electrons cross it several times faster than by diffusion alone.", eq: "τ<sub>B</sub> = (W<sub>B</sub>²/D<sub>n</sub>)·(1/η)[1 − (1 − e<sup>−η</sup>)/η] → W<sub>B</sub>²/(2D<sub>n</sub>) when η → 0" },
  ],
  foot: "Model: Gummel–Poon-style DC with high-injection knee (I_KF = 12 mA), emitter/base series resistance (3 Ω / 45 Ω), Early voltage 15 + 400·x_Ge V; base 20 nm, D_n = 4.5 cm²/s, collector transit W_C/2v_sat, Kirk current 8 mA·(1 + V_CB/1.2 V), C_je = 12 fF, C_bc = 6 fF at 0 V; emitter area 1 µm². Illustrative values.",
  sim(st) {
    const p = params(st), pSi = params({ ...st, ge: 0 });
    const R = { p };
    R.op = bjt(st.VBE, st.VCE, p);
    R.sp = speed(R.op.Ic, st.VCE, st.VBE, p);
    R.gIc = map(VBEs, (v) => bjt(v, st.VCE, p).Ic); R.gIb = map(VBEs, (v) => bjt(v, st.VCE, p).Ib);
    R.sIc = map(VBEs, (v) => bjt(v, st.VCE, pSi).Ic);
    R.vce = linspace(0, 3, 121);
    R.fam = [0.8, 0.83, 0.86, 0.89, 0.92].map((vb) => map(R.vce, (vc) => bjt(vb, vc, p).Ic));
    R.cur = map(R.vce, (vc) => bjt(st.VBE, vc, p).Ic);
    R.ic = logspace(-6, -1.6, 90);
    // invert I_C → V_BE by bisection for the RF curves
    const vbeFor = (Ic) => { let lo = 0.4, hi = 1.3; for (let k = 0; k < 50; k++) { const m = (lo + hi) / 2; if (bjt(m, st.VCE, p).Ic > Ic) hi = m; else lo = m; } return (lo + hi) / 2; };
    R.fT = map(R.ic, (Ic) => speed(Ic, st.VCE, vbeFor(Ic), p).fT / 1e9);
    R.fmax = map(R.ic, (Ic) => speed(Ic, st.VCE, vbeFor(Ic), p).fmax / 1e9);
    R.fTsi = map(R.ic, (Ic) => speed(Ic, st.VCE, vbeFor(Ic), pSi).fT / 1e9);
    R.beta = map(R.ic, (Ic) => { const o = bjt(vbeFor(Ic), st.VCE, p); return o.Ic / o.Ib; });
    R.ges = linspace(0, 30, 61);
    R.tauB = map(R.ges, (x) => params({ ...st, ge: x }).tauB * 1e12);
    R.fTpk = map(R.ges, (x) => { const q = params({ ...st, ge: x }); let best = 0; for (const Ic of [2e-3, 4e-3, 6e-3, 8e-3, 1e-2]) best = Math.max(best, speed(Ic, st.VCE, 0.9, q).fT); return best / 1e9; });
    return R;
  },
  render(R, api) {
    const { st, C } = api, p = R.p, op = R.op;
    const beta = op.Ic / Math.max(op.Ib, 1e-30);
    api.status([
      ["I_C", fSI(op.Ic, "A"), ""], ["I_B", fSI(op.Ib, "A"), ""], ["β", beta.toFixed(0), ""],
      ["f_T", (R.sp.fT / 1e9).toFixed(0) + " GHz", ""], ["f_max", (R.sp.fmax / 1e9).toFixed(0) + " GHz", ""],
      ["Region", st.VCE < 0.3 ? "saturation" : op.Ic > R.sp.Ik ? "Kirk (high injection)" : "forward active", st.VCE < 0.3 || op.Ic > R.sp.Ik ? "warn" : "good"],
    ]);
    api.q(".hbttxt").textContent = `${st.ge} % Ge, A_E = 1 µm²`;
    api.plot("tp1", { xmin: 0.4, xmax: 1.0, ylog: true, ymin: 1e-14, ymax: 1e-1, xlabel: "V_BE (V)", ylabel: "I (A)", legend: true,
      series: [{ x: VBEs, y: R.sIc, color: C.muted, w: 1.2, dash: [3, 3], label: "I_C (Si)" }, { x: VBEs, y: R.gIc, color: C.rf, w: 2.2, label: "I_C" }, { x: VBEs, y: R.gIb, color: C.ph, w: 2, label: "I_B" }],
      points: [{ x: st.VBE, y: op.Ic, color: C.rf }, { x: st.VBE, y: op.Ib, color: C.ph }] });
    api.eqv("tp1", `I_S gain from Ge = ×${p.gamma.toFixed(1)} → I_C(${st.VBE.toFixed(3)} V) = ${fSI(op.Ic, "A")}`);
    api.ro("tp1", [["I_C", fSI(op.Ic, "A")], ["I_B", fSI(op.Ib, "A")], ["Internal V_BE", op.vbe.toFixed(3) + " V"]]);
    api.plot("tp2", { xmin: 0, xmax: 3, ymin: 0, xlabel: "V_CE (V)", ylabel: "I_C (mA)", series: [...R.fam.map((y) => ({ x: R.vce, y: map(y, (v) => v * 1e3), color: C.muted, w: 1 })), { x: R.vce, y: map(R.cur, (v) => v * 1e3), color: C.rf, w: 2.2 }],
      vlines: [{ x: 1.8, color: C.bad, dash: [3, 3], label: "BV_CEO ≈ 1.8 V" }], points: [{ x: st.VCE, y: op.Ic * 1e3, color: C.ink }] });
    api.ro("tp2", [["V_A", p.VA.toFixed(0) + " V"], ["r_out", fSI((p.VA + st.VCE) / Math.max(op.Ic, 1e-12), "Ω")], ["g_m", fSI(op.Ic / Ut, "S")]]);
    api.plot("tp3", { xlog: true, xmin: 1e-6, xmax: 0.025, ymin: 0, xlabel: "I_C (A)", ylabel: "β", series: [{ x: R.ic, y: R.beta, color: C.ok, w: 2.2 }], points: [{ x: Math.max(op.Ic, 1e-6), y: beta, color: C.ink }] });
    api.ro("tp3", [["β now", beta.toFixed(0)], ["β peak", Math.max(...R.beta).toFixed(0)]]);
    api.plot("tp4", { xlog: true, xmin: 1e-6, xmax: 0.025, ymin: 0, xlabel: "I_C (A)", ylabel: "f (GHz)", legend: true,
      series: [{ x: R.ic, y: R.fTsi, color: C.muted, w: 1.2, dash: [3, 3], label: "f_T (Si base)" }, { x: R.ic, y: R.fT, color: C.opt, w: 2.2, label: "f_T" }, { x: R.ic, y: R.fmax, color: C.ph, w: 2, label: "f_max" }],
      vlines: [{ x: R.sp.Ik, color: C.bad, dash: [2, 3], label: "Kirk" }], points: [{ x: Math.max(op.Ic, 1e-6), y: R.sp.fT / 1e9, color: C.ink }] });
    api.eqv("tp4", `τ_F = ${(R.sp.tauF * 1e12).toFixed(2)} ps (τ_B = ${(p.tauB * 1e12).toFixed(2)} ps) → f_T = ${(R.sp.fT / 1e9).toFixed(0)} GHz`);
    api.ro("tp4", [["f_T", (R.sp.fT / 1e9).toFixed(0) + " GHz"], ["f_max", (R.sp.fmax / 1e9).toFixed(0) + " GHz"], ["C_bc", (R.sp.Cbc * 1e15).toFixed(1) + " fF"], ["Peak f_T", Math.max(...R.fT).toFixed(0) + " GHz"]]);
    api.plot("a1", { xmin: 0, xmax: 30, ymin: 0, xlabel: "peak Ge (%)", ylabel: "τ_B (ps) · f_T,peak (100 GHz)", legend: true, series: [{ x: R.ges, y: R.tauB, color: C.dc, w: 2, label: "τ_B (ps)" }, { x: R.ges, y: map(R.fTpk, (v) => v / 100), color: C.opt, w: 2, label: "f_T peak (×100 GHz)" }], vlines: [{ x: st.ge, color: C.ink, dash: [2, 3] }] });
    api.ro("a1", [["ΔE_g across base", (p.dEg * 1000).toFixed(0) + " meV"], ["τ_B", (p.tauB * 1e12).toFixed(3) + " ps"], ["vs Si", "÷" + (params({ ...st, ge: 0 }).tauB / p.tauB).toFixed(1)]]);
  },
};

export default { atomic, bench };
