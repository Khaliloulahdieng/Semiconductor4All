// RF-SOI antenna switch: stacked floating-body nFETs on a thick BOX, high-resistivity handle and trap-rich layer.
import { buildGrid, solvePoisson, interp, visDensity, fSI, f } from "../lib/physics.js";
import { map, linspace, logspace } from "../lib/plot.js";

const PI = Math.PI;

// ---------- atomic: vertical stack gate → film → BOX → (trap-rich) → HR handle ----------
const TOX = 5, TSI = 70, TBOX = 400, TTR = 1000, THR = 2500;
function vertical(VG, Vsub, tr) {
  const L = [
    { mat: "SiO2", t: TOX, dx: 0.5 },
    { mat: "Si", t: TSI, N: -1e17, dx: 0.8 },
    { mat: "SiO2", t: TBOX - 2, dx: 10 },
    { mat: "SiO2", t: 2, dx: 0.5, Qf: 1.0e18 },  // ≈ 2×10¹¹ cm⁻² fixed positive charge at the BOX/handle interface
  ];
  if (tr) L.push({ mat: "Si", t: TTR, N: -1e13, Nt: 3e17, dx: 4, phin: Vsub, phip: Vsub });
  L.push({ mat: "Si", t: 60, N: -1e12, dx: 0.6, phin: Vsub, phip: Vsub }, { mat: "Si", t: THR, N: -1e12, dx: 40, phin: Vsub, phip: Vsub });
  const g = buildGrid(L);
  const s = solvePoisson(g, { left: { type: "gate", V: VG, wf: 4.1 }, right: { type: "ohmic", V: Vsub } });
  const hs = TOX + TSI + TBOX + (tr ? TTR : 0); // handle surface depth
  let psc = 0;
  for (let i = 1; i < g.x.length; i++) if (g.x[i] > hs && g.x[i] < hs + 60) psc += s.n[i] * (g.x[i] - g.x[i - 1]) * 1e-7;
  let front = 0, frontH = 0;
  for (let i = 1; i < g.x.length; i++) if (g.x[i] > TOX && g.x[i] < TOX + 10) { front += s.n[i] * (g.x[i] - g.x[i - 1]) * 1e-7; frontH += s.p[i] * (g.x[i] - g.x[i - 1]) * 1e-7; }
  return { g, s, psc, front, frontH, hs };
}
const RSH = (psc) => 1 / (1.602e-19 * 1000 * Math.max(psc, 1e3)); // sheet resistance of the PSC layer (µn ≈ 1000)

const fmtV = (v) => f(v, 2) + " V";
const atomic = {
  intro: "One transistor of an RF switch stack, from the gate down into the wafer. The thick BOX isolates the device, but positive charge in the oxide can pull a thin electron layer into the high-resistivity handle (parasitic surface conduction, PSC). A trap-rich layer kills it. Not to scale.",
  controls: [
    { label: "Gate", color: "ph", items: [{ id: "VG", type: "seg", label: "Switch state", options: [[2.5, "ON (+2.5 V)"], [-2.5, "OFF (−2.5 V)"]], value: 2.5 }] },
    { label: "Handle wafer", color: "rf", items: [{ id: "Vsub", label: "RF swing coupled to handle", min: -3, max: 3, step: 0.1, value: 0, fmt: fmtV }, { type: "note", text: "The RF signal capacitively drags the handle potential up and down." }] },
    { label: "Substrate engineering", color: "dc", items: [{ id: "tr", type: "check", label: "Trap-rich layer under the BOX", value: false }] },
  ],
  presets: [
    { label: "HR-SOI, ON", set: { VG: 2.5, Vsub: 0, tr: false } },
    { label: "HR-SOI, OFF, RF swing −2 V", set: { VG: -2.5, Vsub: -2, tr: false } },
    { label: "Trap-rich, OFF, RF swing −2 V", set: { VG: -2.5, Vsub: -2, tr: true } },
  ],
  look: [
    "Toggle ON/OFF on the top cut: +2.5 V inverts the 70 nm body (electron channel); −2.5 V accumulates holes, so the FET is a small capacitor.",
    "Switch to the second cut (BOX → handle) without trap-rich: an electron layer sits right under the BOX. Move the RF swing slider: its density changes with the signal. That modulation is what creates harmonics and loss.",
    "Tick the trap-rich layer: the traps pin the Fermi level and the electron layer disappears, whatever the RF swing.",
  ],
  world: { w: 200, h: 120 }, aspect: "5/3", lensAt: [100, 33],
  cuts: [{ id: "top", label: "Gate → film → BOX", a: [100, 24], b: [100, 50] }, { id: "sub", label: "BOX → handle (PSC)", a: [60, 44], b: [60, 118] }],
  solve(st) { return vertical(+st.VG, st.Vsub, st.tr); },
  scene(S, st) {
    const on = +st.VG > 0, ytr = st.tr ? 12 : 0, yh = 62 + ytr;
    const pscD = visDensity(S.psc / 3e-6, 13, 18.5);
    const regions = [
      { x: 0, y: yh, w: 200, h: 120 - yh, mat: "hr", label: "HR handle" },
      ...(st.tr ? [{ x: 0, y: 62, w: 200, h: 12, mat: "trap" }] : []),
      { x: 0, y: 40, w: 200, h: 22, mat: "box" },
      { x: 10, y: 28, w: 60, h: 12, mat: "si", dop: "n+" }, { x: 70, y: 28, w: 60, h: 12, mat: "si", dop: "p" }, { x: 130, y: 28, w: 60, h: 12, mat: "si", dop: "n+" },
      { x: 70, y: 25, w: 60, h: 3, mat: "ox" }, { x: 70, y: 10, w: 60, h: 15, mat: "poly" },
    ];
    const zones = [
      { id: "s", type: "e", x: 10, y: 28, w: 60, h: 12, dens: 0.9 }, { id: "d", type: "e", x: 130, y: 28, w: 60, h: 12, dens: 0.9 },
      on ? { id: "ch", type: "e", x: 70, y: 28, w: 60, h: 3, dens: visDensity(S.front / 1e-6, 13, 19.5), vx: 25, jit: 0.4 } : { id: "acc", type: "h", x: 70, y: 28, w: 60, h: 3, dens: visDensity(S.frontH / 1e-6, 13, 19.5), jit: 0.4 },
      { id: "body", type: "h", x: 70, y: 32, w: 60, h: 8, dens: on ? 0.15 : 0.45 },
      { id: "psc", type: "e", x: 0, y: yh, w: 200, h: 3, dens: pscD, vx: st.Vsub * 4, jit: 0.4 },
      { id: "hrh", type: "h", x: 0, y: yh + 10, w: 200, h: 120 - yh - 10, dens: 0.02 },
    ];
    const ions = [{ x: 0, y: 59.5, w: 200, h: 2, sign: 1, dens: 1 }];
    return {
      regions, zones, ions,
      depl: on ? [{ x: 70, y: 31, w: 60, h: 9 }] : [],
      labels: [
        { x: 100, y: 17, text: "gate", size: 10 }, { x: 40, y: 34, text: "n⁺ source", size: 10 }, { x: 160, y: 34, text: "n⁺ drain", size: 10 },
        { x: 100, y: 50, text: "BOX · 400 nm (+ fixed charge at its bottom)", color: "muted", size: 10 },
        ...(st.tr ? [{ x: 100, y: 68, text: "trap-rich poly-Si", size: 10 }] : []),
        { x: 100, y: 100, text: "high-resistivity Si handle (> 1 kΩ·cm)", color: "muted", size: 10 },
        { x: 170, y: yh + 6, text: S.psc > 1e9 ? "PSC electron layer" : "no PSC", color: S.psc > 1e9 ? "e" : "muted", size: 10 },
      ],
      terminals: [{ x: 100, y: 5, text: `G ${on ? "+2.5" : "−2.5"} V` }, { x: 30, y: 113, text: `handle ${f(st.Vsub, 1)} V` }],
    };
  },
  bands(S, st, cut) {
    const { g, s } = S;
    const lo = cut === "top" ? 0 : TOX + TSI + TBOX - 60, hi = cut === "top" ? TOX + TSI + 80 : S.hs + 600;
    const idx = []; for (let i = 0; i < s.x.length; i++) if (s.x[i] >= lo && s.x[i] <= hi) idx.push(i);
    const pick = (a) => Float64Array.from(idx, (i) => a[i]);
    const regs = cut === "top"
      ? [{ x0: 0, x1: TOX, label: "" }, { x0: TOX, x1: TOX + TSI, label: "Si body" }, { x0: TOX + TSI, x1: hi, label: "BOX" }]
      : [{ x0: lo, x1: TOX + TSI + TBOX, label: "BOX" }, ...(st.tr ? [{ x0: TOX + TSI + TBOX, x1: S.hs, label: "trap-rich" }] : []), { x0: S.hs, x1: hi, label: "HR handle" }];
    return { x: pick(s.x), Ec: pick(s.Ec), Ev: pick(s.Ev), EFn: pick(s.EFn), EFp: pick(s.EFp), n: pick(s.n), p: pick(s.p), E: pick(s.E), Nabs: map(pick(g.N), Math.abs), regions: regs, xlabel: "depth from gate (nm)", clip: [-5, 5] };
  },
  readouts(S, st) {
    return [["Channel electrons", S.front.toExponential(1) + " cm⁻²"], ["Accumulated holes", S.frontH.toExponential(1) + " cm⁻²"], ["PSC electrons", S.psc.toExponential(1) + " cm⁻²", S.psc > 1e10 ? "warn" : "good"],
      ["Handle sheet resistance", S.psc > 1e9 ? fSI(RSH(S.psc), "Ω/□", 1) : "very high", S.psc > 1e10 ? "warn" : "good"]];
  },
  foot: "1D Poisson along the gate axis: n⁺-poly gate, 5 nm oxide, 70 nm p-body (10¹⁷), 400 nm BOX with 2×10¹¹ cm⁻² fixed charge at its bottom, optional 1 µm trap-rich layer (amphoteric traps, 3×10¹⁷ cm⁻³), 1 kΩ·cm p-type handle. Floating-body effects are ignored (body tied to source). Illustrative values.",
};

// ---------- bench: series-shunt SPST arm ----------
const Z0 = 50;
const RON_MM = 1.0;     // Ω·mm per FET
const COFF_MM = 0.12;   // pF/mm per FET  → Ron·Coff = 120 fs
const BV = 3.2;         // V per FET (peak) before breakdown / GIDL
function cplx(re, im) { return { re, im }; }
const cadd = (a, b) => cplx(a.re + b.re, a.im + b.im), cmul = (a, b) => cplx(a.re * b.re - a.im * b.im, a.re * b.im + a.im * b.re);
const cdiv = (a, b) => { const d = b.re * b.re + b.im * b.im; return cplx((a.re * b.re + a.im * b.im) / d, (a.im * b.re - a.re * b.im) / d); };
const cabs = (a) => Math.hypot(a.re, a.im);
function arm(st, fGHz) {
  const w = 2 * PI * fGHz * 1e9;
  const Wser = st.W, Wsh = st.W / 2, N = st.N;
  const Ron = (RON_MM / Wser) * N, Coff = (COFF_MM * Wser / N) * 1e-12;
  const RonSh = (RON_MM / Wsh) * N, CoffSh = (COFF_MM * Wsh / N) * 1e-12;
  const on = st.state === "on";
  const Zs = on ? cplx(Ron, 0) : cdiv(cplx(1, 0), cplx(0, w * Coff));
  const Ysh = on ? cplx(0, w * CoffSh) : cplx(1 / RonSh, 0);
  // substrate loss path at the antenna node: C_BOX in series with the handle resistance (low with PSC)
  const Rsub = st.tr ? 8000 : 450, Cbox = 0.25e-12 * st.W;
  const Ysub = cdiv(cplx(1, 0), cadd(cplx(Rsub, 0), cdiv(cplx(1, 0), cplx(0, w * Cbox))));
  const Y = cadd(Ysh, Ysub);
  // ABCD of series Z followed by shunt Y: [[1+ZY, Z],[Y, 1]]
  const A = cadd(cplx(1, 0), cmul(Zs, Y)), B = Zs, C = Y, D = cplx(1, 0);
  const den = cadd(cadd(A, cplx(B.re / Z0, B.im / Z0)), cadd(cplx(C.re * Z0, C.im * Z0), D));
  return 20 * Math.log10(cabs(cdiv(cplx(2, 0), den)));
}
function ladder(N, Vpk, alpha) { // voltage across each FET of an OFF stack with parasitic Cp = α·Coff to ground at each node
  // nodal analysis on a capacitive ladder (normalised Coff = 1)
  const n = N - 1; if (n <= 0) return [Vpk];
  const a = new Float64Array(n), b = new Float64Array(n), c = new Float64Array(n), d = new Float64Array(n);
  for (let i = 0; i < n; i++) { a[i] = -1; b[i] = 2 + alpha; c[i] = -1; d[i] = 0; }
  d[0] = Vpk; // node 0 neighbours the RF port at Vpk; last node neighbours ground
  for (let i = 1; i < n; i++) { const m = a[i] / b[i - 1]; b[i] -= m * c[i - 1]; d[i] -= m * d[i - 1]; }
  const v = new Float64Array(n); v[n - 1] = d[n - 1] / b[n - 1];
  for (let i = n - 2; i >= 0; i--) v[i] = (d[i] - c[i] * v[i + 1]) / b[i];
  const nodes = [Vpk, ...v, 0];
  return nodes.slice(0, -1).map((x, i) => x - nodes[i + 1]);
}
function harmonics(st, PdBm) {
  const k2 = (st.tr ? 128 : 96) + 4 * Math.log10(st.W);                  // H2 dominated by the substrate
  const k3 = 98 + 60 * Math.log10(st.N / 4) + (st.state === "on" ? 6 : 0); // H3 from FET non-linearity, relieved by stacking
  return { h2: 2 * PdBm - k2, h3: 3 * PdBm - k3 };
}

const bench = {
  intro: "One arm of an antenna switch: a series stack of N transistors from the power amplifier to the antenna, and a shunt stack to ground. ON: series conducts, shunt blocks. OFF: the reverse, so the PA's swing must be shared across the OFF stack.",
  animated: true,
  controls: [
    { label: "Switch state", color: "ph", items: [{ id: "state", type: "seg", options: [["on", "Series ON (thru)"], ["off", "Series OFF (isolate)"]], value: "on" }, { id: "N", label: "FETs in each stack", min: 1, max: 14, step: 1, value: 8, fmt: (v) => v + "" }, { id: "W", label: "Series stack width", min: 0.5, max: 6, step: 0.1, value: 3, fmt: (v) => v.toFixed(1) + " mm" }] },
    { label: "RF source (TP1)", color: "rf", items: [{ id: "f", label: "Frequency", min: 0.5, max: 8, step: 0.1, value: 2.4, fmt: (v) => v.toFixed(1) + " GHz" }, { id: "P", label: "Input power", min: 0, max: 40, step: 0.5, value: 30, fmt: (v) => v.toFixed(1) + " dBm" }] },
    { label: "Substrate", color: "dc", items: [{ id: "tr", type: "check", label: "Trap-rich handle (vs plain HR-SOI)", value: true }] },
  ],
  presets: [
    { label: "Wi-Fi thru, 2.4 GHz", set: { state: "on", N: 8, W: 3, f: 2.4, P: 24, tr: true } },
    { label: "Isolate 35 dBm, 4 FETs: breakdown", set: { state: "off", N: 4, W: 3, f: 0.9, P: 35, tr: true } },
    { label: "Isolate 35 dBm, 12 FETs", set: { state: "off", N: 12, W: 3, f: 0.9, P: 35, tr: true } },
    { label: "HR-SOI without trap-rich", set: { state: "on", N: 8, W: 3, f: 2.4, P: 30, tr: false } },
  ],
  schematic: {
    viewBox: "0 0 960 340",
    svg: `
  <rect class="bx" x="20" y="120" width="130" height="60" rx="5"/><text class="lb" x="85" y="146" text-anchor="middle">PA / RF source</text><text class="sub" x="85" y="165" text-anchor="middle">50 Ω</text>
  <path class="rf" d="M150,150 H250"/>
  <g class="ser"><rect class="dev" x="250" y="125" width="330" height="50" rx="6"/><text class="lb" x="415" y="146" text-anchor="middle">Series stack: N × nFET</text><text class="sub sertxt" x="415" y="164" text-anchor="middle"></text></g>
  <path class="rf" d="M580,150 H780"/>
  <rect class="bx" x="780" y="120" width="160" height="60" rx="5"/><text class="lb" x="860" y="146" text-anchor="middle">Antenna</text><text class="sub" x="860" y="165" text-anchor="middle">50 Ω load</text>
  <path class="rf" d="M200,150 V205"/>
  <g class="sh"><rect class="dev" x="140" y="205" width="120" height="70" rx="6"/><text class="lb" x="200" y="232" text-anchor="middle">Shunt stack</text><text class="sub shtxt" x="200" y="252" text-anchor="middle"></text></g>
  <path class="w" d="M200,275 V300 H180 M185,306 H215 M192,312 H208"/>
  <rect class="bx" x="640" y="230" width="170" height="56" rx="5"/><text class="lb" x="725" y="254" text-anchor="middle">Spectrum analyser</text><text class="sub" x="725" y="273" text-anchor="middle">f₀, 2f₀, 3f₀</text>
  <path class="rf" d="M700,150 V230" stroke-dasharray="4 3"/>
  <rect class="bx" x="300" y="20" width="230" height="50" rx="5"/><text class="lb" x="415" y="42" text-anchor="middle">Gate bias network</text><text class="sub" x="415" y="60" text-anchor="middle">+2.5 V ON / −2.5 V OFF via big R</text>
  <path class="dc" d="M415,70 V125"/>
  <text class="cap" x="250" y="205">substrate under the stack: HR-Si (+ trap-rich)</text>`,
  },
  tps: [{ n: 1, x: 200, y: 120, label: "RF source" }, { n: 2, x: 415, y: 195, label: "series stack" }, { n: 3, x: 290, y: 240, label: "shunt stack" }, { n: 4, x: 740, y: 150, label: "antenna port" }, { n: 5, x: 830, y: 258, label: "spectrum analyser" }],
  sections: [{ k: "tp", t: "Test points", n: "From the PA, through the stacks, to the antenna and the spectrum analyser." }, { k: "ana", t: "Design trade-offs", n: "Width, stack height and substrate: the three knobs of an RF switch." }],
  cards: [
    { id: "tp1", tp: 1, s: "tp", d: "rf", dn: "RF", t: "RF source", x: "Incident sine wave. Its peak voltage on 50 Ω is what the OFF stack must survive.", eq: "V<sub>pk</sub> = <span class=\"rt\">√</span><span class=\"rad\">2·P·Z<sub>0</sub></span>,&nbsp; P[W] = 10<sup>(P<sub>dBm</sub>−30)/10</sup>" },
    { id: "tp2", tp: 2, s: "tp", d: "ph", dn: "stack", t: "Series stack: voltage per FET", x: "OFF: the swing divides across the stack; parasitic capacitance to the substrate loads the first FETs most. ON: each FET drops only I·R_on.", eq: "OFF: V<sub>k</sub> from the C<sub>off</sub>–C<sub>p</sub> ladder,&nbsp; ΣV<sub>k</sub> = V<sub>pk</sub><br>ON: V<sub>k</sub> = I·R<sub>on</sub>/W" },
    { id: "tp3", tp: 3, s: "tp", d: "ph", dn: "stack", t: "Shunt stack", x: "Mirror of the series stack. ON-state: the shunt is OFF and adds capacitance (loss at high frequency). OFF-state: the shunt is ON and shorts leakage to ground (isolation).", eq: "Y<sub>sh</sub> = jωC<sub>off,sh</sub> (thru) or 1/R<sub>on,sh</sub> (isolate)" },
    { id: "tp4", tp: 4, s: "tp", d: "opt", dn: "S-parameter", t: "Antenna port: |S21| vs frequency", x: "Insertion loss (ON) or isolation (OFF). Thin line: the other state for comparison. Marker: the source frequency.", eq: "S<sub>21</sub> = 2 / (A + B/Z<sub>0</sub> + CZ<sub>0</sub> + D),&nbsp; ABCD = series Z · shunt (Y<sub>sh</sub> + Y<sub>sub</sub>)", h: "tall" },
    { id: "tp5", tp: 5, s: "tp", d: "rf", dn: "instrument", t: "Spectrum analyser", x: "Output spectrum: fundamental and the 2nd and 3rd harmonics. Phones need harmonics below about −40 dBm…−80 dBm.", eq: "P<sub>H2</sub> ≈ 2P<sub>in</sub> − k<sub>2</sub>(substrate),&nbsp; P<sub>H3</sub> ≈ 3P<sub>in</sub> − k<sub>3</sub>(N)" },
    { id: "a1", chip: "R·C", s: "ana", d: "an", dn: "trade-off", t: "Width trade-off at the source frequency", x: "Wider FETs: lower R_on (less ON loss) but more C_off (worse OFF isolation). The product R_on·C_off is the technology figure of merit.", eq: "R<sub>on</sub>·C<sub>off</sub> = " + (RON_MM * COFF_MM * 1000).toFixed(0) + " fs,&nbsp; f<sub>c</sub> = 1/(2πR<sub>on</sub>C<sub>off</sub>)" },
    { id: "a2", chip: "H vs P", s: "ana", d: "an", dn: "linearity", t: "Harmonics vs input power", x: "Slopes 2:1 and 3:1. Dashed: the other substrate option. Trap-rich mostly helps H2, stacking helps H3.", eq: "H2: slope 2 dB/dB,&nbsp; H3: slope 3 dB/dB" },
  ],
  foot: "Model: R_on = 1.0 Ω·mm and C_off = 0.12 pF/mm per FET (R_on·C_off = 120 fs), shunt stack half the series width, breakdown 3.2 V peak per FET, parasitic C_p = 3 % of C_off per node, substrate loss through C_BOX with 450 Ω (HR-SOI with PSC) or 8 kΩ (trap-rich). Harmonic coefficients are empirical. Illustrative values.",
  sim(st) {
    const R = {};
    R.Pw = Math.pow(10, (st.P - 30) / 10); R.Vpk = Math.sqrt(2 * R.Pw * Z0);
    R.fr = logspace(-1, Math.log10(20), 140);
    R.s21 = map(R.fr, (fq) => arm(st, fq));
    R.s21o = map(R.fr, (fq) => arm({ ...st, state: st.state === "on" ? "off" : "on" }, fq));
    R.now = arm(st, st.f);
    R.vk = st.state === "off" ? ladder(st.N, R.Vpk, 0.03) : Array.from({ length: st.N }, () => (R.Vpk / Z0 / 2) * RON_MM / st.W);
    R.vmax = Math.max(...R.vk);
    R.vsh = st.state === "on" ? ladder(st.N, R.Vpk, 0.03) : Array.from({ length: st.N }, () => 0.002);
    R.H = harmonics(st, st.P);
    R.Ron = (RON_MM / st.W) * st.N; R.Coff = (COFF_MM * st.W) / st.N;
    R.ws = linspace(0.5, 6, 56);
    R.wIL = map(R.ws, (w) => -arm({ ...st, W: w, state: "on" }, st.f));
    R.wIso = map(R.ws, (w) => -arm({ ...st, W: w, state: "off" }, st.f));
    R.ps = linspace(0, 40, 81);
    R.h2 = map(R.ps, (p) => harmonics(st, p).h2); R.h3 = map(R.ps, (p) => harmonics(st, p).h3);
    R.h2o = map(R.ps, (p) => harmonics({ ...st, tr: !st.tr }, p).h2);
    return R;
  },
  render(R, api) {
    const { st, C } = api;
    const on = st.state === "on", bd = st.state === "off" ? R.vmax > BV : Math.max(...R.vsh) > BV;
    api.status([
      ["State", on ? "Thru (series ON)" : "Isolate (series OFF)", ""],
      [on ? "Insertion loss" : "Isolation", (-R.now).toFixed(2) + " dB", on ? (-R.now > 1 ? "warn" : "good") : (-R.now < 20 ? "warn" : "good")],
      ["Max V per FET", R.vmax.toFixed(2) + " V / " + BV + " V", bd ? "warn" : "good"],
      ["R_on (series stack)", R.Ron.toFixed(2) + " Ω", ""], ["C_off (series stack)", (R.Coff * 1000).toFixed(0) + " fF", ""],
      ["H2 / H3", R.H.h2.toFixed(0) + " / " + R.H.h3.toFixed(0) + " dBm", R.H.h2 > -40 || R.H.h3 > -40 ? "warn" : "good"],
    ]);
    api.q(".sertxt").textContent = `${st.N} FETs · ${on ? "ON, R_on = " + R.Ron.toFixed(2) + " Ω" : "OFF, C_off = " + (R.Coff * 1000).toFixed(0) + " fF"}`;
    api.q(".shtxt").textContent = on ? "OFF (capacitive)" : "ON (to ground)";
    api.q(".ser rect").classList.toggle("off", !on); api.q(".sh rect").classList.toggle("off", on);
    api.q(".ser rect").classList.toggle("fault", !on && bd); api.q(".sh rect").classList.toggle("fault", on && bd);
    // TP1: time waveform, 2 periods
    const T = 2 / st.f, ph = (api.frame % 120) / 120 * T;
    const tt = linspace(0, T, 200);
    api.plot("tp1", { xmin: 0, xmax: T, ymin: -R.Vpk * 1.3, ymax: R.Vpk * 1.3, xlabel: "time (ns)", ylabel: "v (V)", series: [{ x: tt, y: map(tt, (t) => R.Vpk * Math.sin(2 * PI * st.f * t)), color: C.rf, w: 2 }], cursor: ph });
    api.ro("tp1", [["P_in", st.P.toFixed(1) + " dBm"], ["P_in", fSI(R.Pw, "W")], ["V_pk", R.Vpk.toFixed(2) + " V"], ["Frequency", st.f.toFixed(1) + " GHz"]]);
    // TP2: bars per FET
    const bars = (vk) => { const xs = [], ys = []; vk.forEach((v, i) => { xs.push(i + 0.6, i + 0.6, i + 1.4, i + 1.4); ys.push(0, v, v, 0); }); return { xs, ys }; };
    const b2 = bars(R.vk);
    api.plot("tp2", { xmin: 0.4, xmax: st.N + 0.6, ymin: 0, ymax: Math.max(BV * 1.25, R.vmax * 1.15), xstep: st.N > 8 ? 2 : 1, xlabel: "FET # (from PA side)", ylabel: "V_peak across FET (V)", series: [{ x: b2.xs, y: b2.ys, color: on ? C.ok : C.ph, w: 1.4, fill: on ? C.ok : C.ph, fillAlpha: 0.3 }], hlines: [{ y: BV, color: C.bad, dash: [4, 3], label: "breakdown" }] });
    api.eqv("tp2", on ? `I_pk = V_pk/(2Z₀) = ${(R.Vpk / 100 * 1000).toFixed(0)} mA → V per FET = ${(R.vk[0] * 1000).toFixed(1)} mV` : `V_pk ${R.Vpk.toFixed(2)} V over ${st.N} FETs: ideal ${(R.Vpk / st.N).toFixed(2)} V each, worst ${R.vmax.toFixed(2)} V`);
    api.ro("tp2", [["Worst FET", R.vmax.toFixed(2) + " V", bd && !on ? "warn" : "good"], ["Margin", ((BV / R.vmax - 1) * 100).toFixed(0) + " %", bd && !on ? "warn" : ""], ["Uniformity", (Math.min(...R.vk) / R.vmax * 100).toFixed(0) + " %"]]);
    const b3 = bars(R.vsh);
    api.plot("tp3", { xmin: 0.4, xmax: st.N + 0.6, ymin: 0, ymax: Math.max(BV * 1.25, Math.max(...R.vsh) * 1.15), xstep: st.N > 8 ? 2 : 1, xlabel: "FET #", ylabel: "V_peak (V)", series: [{ x: b3.xs, y: b3.ys, color: on ? C.ph : C.ok, w: 1.4, fill: on ? C.ph : C.ok, fillAlpha: 0.3 }], hlines: [{ y: BV, color: C.bad, dash: [4, 3], label: "breakdown" }] });
    api.ro("tp3", [["State", on ? "OFF" : "ON"], [on ? "C_off,sh" : "R_on,sh", on ? ((COFF_MM * st.W / 2 / st.N) * 1000).toFixed(0) + " fF" : ((RON_MM / (st.W / 2)) * st.N).toFixed(2) + " Ω"]]);
    api.plot("tp4", { xlog: true, xmin: 0.1, xmax: 20, xlabel: "f (GHz)", ylabel: "|S21| (dB)", ymin: on ? -3 : -70, ymax: on ? 0.2 : 0, series: [{ x: R.fr, y: R.s21o, color: C.muted, w: 1, dash: [3, 3] }, { x: R.fr, y: R.s21, color: C.opt, w: 2.2 }], points: [{ x: st.f, y: R.now, color: C.ink, label: R.now.toFixed(2) + " dB" }] });
    api.eqv("tp4", `f_c = 1/(2πR_onC_off) = ${(1 / (2 * PI * RON_MM * COFF_MM * 1e-12) / 1e9).toFixed(0)} GHz`);
    api.ro("tp4", [[on ? "Insertion loss" : "Isolation", (-R.now).toFixed(2) + " dB"], ["Substrate", st.tr ? "trap-rich" : "HR-SOI (PSC)"], ["At 6 GHz", (-arm(st, 6)).toFixed(2) + " dB"]]);
    // TP5: spectrum bars
    const Pout = st.P + R.now, lines = [[1, Pout], [2, R.H.h2], [3, R.H.h3]];
    const xs = [], ys = []; for (const [k, p] of lines) { xs.push(k, k, NaN); ys.push(-120, p, NaN); }
    api.plot("tp5", { xmin: 0.5, xmax: 3.5, ymin: -120, ymax: 45, xstep: 1, xlabel: "harmonic (× f₀)", ylabel: "P (dBm)", series: [{ x: xs, y: ys, color: C.rf, w: 4 }], hlines: [{ y: -40, color: C.bad, dash: [3, 3], label: "typical limit" }], labels: lines.map(([k, p]) => ({ x: k, y: p, text: p.toFixed(0) + " dBm", dx: 8, color: C.ink })) });
    api.ro("tp5", [["Fundamental", Pout.toFixed(1) + " dBm"], ["H2", R.H.h2.toFixed(1) + " dBm", R.H.h2 > -40 ? "warn" : "good"], ["H3", R.H.h3.toFixed(1) + " dBm", R.H.h3 > -40 ? "warn" : "good"]]);
    api.plot("a1", { xmin: 0.5, xmax: 6, ymin: 0, xlabel: "series stack width W (mm)", ylabel: "dB", series: [{ x: R.ws, y: map(R.wIL, (v) => v * 10), color: C.ok, w: 2, label: "insertion loss ×10" }, { x: R.ws, y: R.wIso, color: C.ph, w: 2, label: "isolation" }], legend: true, vlines: [{ x: st.W, color: C.ink, dash: [2, 3] }] });
    api.ro("a1", [["IL at W", (-arm({ ...st, state: "on" }, st.f)).toFixed(2) + " dB"], ["Isolation at W", (-arm({ ...st, state: "off" }, st.f)).toFixed(1) + " dB"]]);
    api.plot("a2", { xmin: 0, xmax: 40, ymin: -140, ymax: 0, xlabel: "P_in (dBm)", ylabel: "P (dBm)", series: [{ x: R.ps, y: R.h2o, color: C.muted, w: 1, dash: [3, 3] }, { x: R.ps, y: R.h2, color: C.rf, w: 2, label: "H2" }, { x: R.ps, y: R.h3, color: C.ph, w: 2, label: "H3" }], legend: true, vlines: [{ x: st.P, color: C.ink, dash: [2, 3] }], hlines: [{ y: -40, color: C.bad, dash: [3, 3] }] });
    api.ro("a2", [["H2 now", R.H.h2.toFixed(1) + " dBm"], ["H3 now", R.H.h3.toFixed(1) + " dBm"], ["Trap-rich gain on H2", "32 dB"]]);
  },
};

export default { atomic, bench };
