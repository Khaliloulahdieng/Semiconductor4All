// Planar bulk n-MOSFET (65–180 nm class): the classic transistor on a doped p-substrate.
import { buildGrid, solvePoisson, depletedSpans, ekvId, lateralChannel, interp, visDensity, fSI, f, Ut300, q, eps0, MAT, ni } from "../lib/physics.js";
import { linspace, map } from "../lib/plot.js";

const TOX = 2.0, COX = (3.9 * eps0) / (TOX * 1e-7), ES = MAT.Si.eps * eps0;
const fmtV = (v) => f(v, 2) + " V";
const fmtN = (v) => (v / 1e17).toFixed(0) + "×10¹⁷ cm⁻³";

// ---------- compact model ----------
function vtLong(Na, VSB) {
  const phiF = Ut300 * Math.log(Na / ni()), gamma = Math.sqrt(2 * q * ES * Na) / COX;
  const Vfb = -0.56 - phiF; // n+ poly gate on p-Si
  return { Vt: Vfb + 2 * phiF + gamma * Math.sqrt(2 * phiF + VSB), phiF, gamma, Vfb, nB: 1 + gamma / (2 * Math.sqrt(2 * phiF + VSB)) };
}
const wDep = (Na, phiF, VSB) => Math.sqrt((2 * ES * (2 * phiF + VSB)) / (q * Na)) * 1e7; // nm
function params(st) {
  const Na = st.Na, VSB = st.VSB || 0;
  const L0 = vtLong(Na, VSB), Wd = wDep(Na, L0.phiF, VSB);
  const lam = Math.sqrt((11.7 / 3.9) * TOX * Wd), e = Math.exp(-st.L / (2 * lam));
  return { Vt: L0.Vt - 0.8 * e, n: L0.nB + 1.5 * e, beta: (300 * COX * 1) / (st.L * 1e-3), Ut: Ut300, dibl: 0.9 * e, lambda: 0.08 + 1.5 * e, theta: 1.2, lam, Wd, ...L0 };
}
const Id = (VG, VD, p) => ekvId(VG, VD, p);

// ---------- atomic ----------
function vertical(VG, Na, VSB) {
  const g = buildGrid([{ mat: "SiO2", t: TOX, dx: 0.25 }, { mat: "Si", t: 160, N: -Na, dx: 0.6, phin: 0, phip: -VSB }]);
  const s = solvePoisson(g, { left: { type: "gate", V: VG, wf: 4.05 }, right: { type: "ohmic", V: -VSB } });
  let ns = 0; for (let i = 1; i < g.x.length; i++) if (g.x[i] > TOX) ns += s.n[i] * (g.x[i] - g.x[i - 1]) * 1e-7;
  return { g, s, ns, spans: depletedSpans(g, s, 0.5), EcS: interp(s.x, s.Ec, TOX + 0.6) };
}

const atomic = {
  intro: "The textbook transistor: a gate on a thin oxide over a doped p-type substrate, with n⁺ source and drain. A positive gate first pushes holes away (depletion, leaving fixed acceptor ions), then pulls a thin layer of electrons to the surface (inversion). Not to scale.",
  controls: [
    { label: "Gate", color: "ph", items: [{ id: "VG", label: "Gate voltage V_G", min: -1, max: 1.5, step: 0.02, value: 0.8, fmt: fmtV }] },
    { label: "Drain", color: "rf", items: [{ id: "VD", label: "Drain voltage V_D", min: 0, max: 1.2, step: 0.02, value: 0.6, fmt: fmtV }] },
    { label: "Body", color: "dc", items: [{ id: "VSB", label: "Source–body reverse bias V_SB", min: 0, max: 1.5, step: 0.05, value: 0, fmt: fmtV }, { id: "Na", label: "Substrate doping", min: 2e17, max: 3e18, step: 1e17, value: 1e18, fmt: fmtN }] },
  ],
  presets: [
    { label: "Accumulation (−1 V)", set: { VG: -1, VD: 0 } }, { label: "Depletion (0.1 V)", set: { VG: 0.1, VD: 0 } },
    { label: "Inversion (1.2 V)", set: { VG: 1.2, VD: 0.05 } }, { label: "Body effect: V_SB = 1.5 V", set: { VG: 0.6, VSB: 1.5 } },
  ],
  look: [
    "Sweep V_G from −1 V upward on the vertical cut: holes pile up at the surface (accumulation), then disappear leaving acceptor ions (depletion), then electrons appear once the surface band bending reaches about 2φ_F (inversion).",
    "Raise V_SB: the depletion region gets deeper and more gate voltage is needed to invert, which is the body effect.",
    "Lower the doping to 2×10¹⁷ cm⁻³ and look at the channel cut: the depletion region gets deeper, the drain reaches further under the gate, and the barrier drops (short-channel effect).",
  ],
  world: { w: 160, h: 100 }, aspect: "8/5", lensAt: [80, 44],
  cuts: [{ id: "vert", label: "Vertical (gate → substrate)", a: [80, 28], b: [80, 99] }, { id: "lat", label: "Along the channel (S → D)", a: [12, 41], b: [148, 41] }],
  solve(st) {
    const V = vertical(st.VG, st.Na, st.VSB);
    const p = params({ ...st, L: 45 });
    return { V, p, id: Id(st.VG, st.VD, p), lat: lateralChannel({ Ecch: V.EcS, VD: st.VD, LS: 40, LG: 45, LD: 40, lam: p.lam }) };
  },
  scene(S, st) {
    const sp = S.V.spans.find((s) => s[0] < TOX + 3) || [TOX, TOX];
    const dep = Math.min(55, Math.max(0, (sp[1] - TOX) / 2.2)); // nm → world units below the surface
    const inv = visDensity(S.V.ns / 3e-7, 14, 19.5);
    const acc = st.VG < S.p.Vfb + 0.1;
    const flow = S.id > 1e-8 && st.VD > 0.01 ? Math.min(40, 6 * Math.log10(S.id * 1e10)) : 0;
    return {
      regions: [
        { x: 0, y: 40, w: 160, h: 60, mat: "si", dop: "p" },
        { x: 8, y: 40, w: 46, h: 12, mat: "si", dop: "n+" }, { x: 106, y: 40, w: 46, h: 12, mat: "si", dop: "n+" },
        { x: 50, y: 22, w: 4, h: 18, mat: "ox" }, { x: 106, y: 22, w: 4, h: 18, mat: "ox" },
        { x: 54, y: 37, w: 52, h: 3, mat: "ox" }, { x: 54, y: 22, w: 52, h: 15, mat: "poly" },
      ],
      depl: dep > 0.5 && !acc ? [{ x: 54, y: 40, w: 52, h: dep }] : [],
      ions: dep > 0.5 && !acc ? [{ x: 54, y: 40.5, w: 52, h: dep - 0.5, sign: -1, dens: Math.min(1, st.Na / 1.5e18) }] : [],
      zones: [
        { id: "s", type: "e", x: 8, y: 40, w: 46, h: 12, dens: 0.95 }, { id: "d", type: "e", x: 106, y: 40, w: 46, h: 12, dens: 0.95 },
        { id: "ch", type: "e", x: 54, y: 40, w: 52, h: 2.2, dens: inv, vx: flow, jit: 0.3 },
        { id: "acc", type: "h", x: 54, y: 40, w: 52, h: 2.2, dens: acc ? 0.9 : 0, jit: 0.3 },
        { id: "sub", type: "h", x: 0, y: 40 + Math.max(dep, 12), w: 160, h: 60 - Math.max(dep, 12), dens: 0.35 + 0.35 * Math.min(1, st.Na / 2e18) },
        { id: "subL", type: "h", x: 0, y: 52, w: 54, h: Math.max(0.5, Math.max(dep, 12) - 12), dens: 0.5 }, { id: "subR", type: "h", x: 106, y: 52, w: 54, h: Math.max(0.5, Math.max(dep, 12) - 12), dens: 0.5 },
      ],
      arrows: flow > 0 ? [{ x1: 60, y1: 36, x2: 100, y2: 36, color: "e", lw: 1.4 }] : [],
      labels: [{ x: 80, y: 30, text: "n⁺ poly gate", size: 10 }, { x: 31, y: 46, text: "n⁺ source", size: 10 }, { x: 129, y: 46, text: "n⁺ drain", size: 10 }, { x: 140, y: 92, text: "p-substrate", size: 10, color: "muted" }],
      terminals: [{ x: 80, y: 15, text: `G ${f(st.VG, 2)} V` }, { x: 30, y: 33, text: "S 0 V" }, { x: 130, y: 33, text: `D ${f(st.VD, 2)} V` }, { x: 30, y: 94, text: `B ${f(-st.VSB, 2)} V` }],
    };
  },
  bands(S, st, cut) {
    if (cut === "vert") {
      const { g, s } = S.V;
      return { x: s.x, Ec: s.Ec, Ev: s.Ev, EFn: s.EFn, EFp: s.EFp, n: s.n, p: s.p, E: s.E, Nabs: map(g.N, Math.abs), regions: [{ x0: 0, x1: TOX, label: "" }, { x0: TOX, x1: TOX + 160, label: "p-substrate" }], xlabel: "depth from gate (nm)", clip: [-3, 3] };
    }
    return { ...S.lat, regions: [{ x0: 0, x1: 40, label: "source" }, { x0: 40, x1: 85, label: "channel (L = 45 nm)" }, { x0: 85, x1: 125, label: "drain" }], xlabel: "position along surface (nm)" };
  },
  readouts(S, st) {
    const sp = S.V.spans.find((s) => s[0] < TOX + 3);
    return [["Regime", st.VG < S.p.Vfb + 0.1 ? "accumulation" : S.V.ns > 5e11 ? "inversion" : "depletion"], ["Depletion depth", sp ? (sp[1] - TOX).toFixed(1) + " nm" : "—"],
      ["Inversion electrons", S.V.ns.toExponential(1) + " cm⁻²"], ["V_t (long channel)", f(vtLong(st.Na, st.VSB).Vt, 3) + " V"], ["2φ_F", (2 * S.p.phiF).toFixed(3) + " V"]];
  },
  foot: "Vertical cut: 1D Poisson, n⁺-poly gate, 2 nm oxide, uniform p-substrate, electron quasi-Fermi level of the source and hole quasi-Fermi level of the body. Channel cut: natural-length model with λ = √(ε_Si t_ox W_dep/ε_ox) for L = 45 nm. Illustrative values.",
};

// ---------- bench ----------
const VGs = linspace(-0.3, 1.4, 120);
const bench = {
  intro: "A four-terminal measurement: gate, drain, source and the substrate (body). The body terminal is what makes a bulk transistor different from FD-SOI: it shifts V_t through the depletion charge.",
  controls: [
    { label: "Gate SMU (TP1)", color: "ph", items: [{ id: "VG", label: "V_G", min: -0.3, max: 1.4, step: 0.01, value: 1.0, fmt: fmtV }] },
    { label: "Drain SMU (TP2)", color: "rf", items: [{ id: "VD", label: "V_D", min: 0, max: 1.4, step: 0.01, value: 1.0, fmt: fmtV }] },
    { label: "Body SMU (TP3)", color: "dc", items: [{ id: "VSB", label: "V_SB (body below source)", min: 0, max: 2, step: 0.05, value: 0, fmt: fmtV }] },
    { label: "Process", color: "opt", items: [{ id: "Na", label: "Channel doping", min: 2e17, max: 3e18, step: 1e17, value: 1e18, fmt: fmtN }, { id: "L", label: "Gate length", min: 30, max: 250, step: 5, value: 65, fmt: (v) => v + " nm" }] },
  ],
  presets: [
    { label: "65 nm nominal", set: { VG: 1, VD: 1, VSB: 0, Na: 1e18, L: 65, } },
    { label: "Body effect V_SB = 1.5 V", set: { VSB: 1.5 } },
    { label: "Too short: L = 30 nm", set: { L: 30, Na: 1e18 } },
    { label: "Light doping, short L", set: { L: 45, Na: 3e17 } },
  ],
  schematic: {
    viewBox: "0 0 900 330",
    svg: `
  <rect class="bx" x="30" y="135" width="150" height="60" rx="5"/><text class="lb" x="105" y="161" text-anchor="middle">Gate SMU</text><text class="sub" x="105" y="181" text-anchor="middle">V_G sweep</text>
  <rect class="bx" x="470" y="18" width="160" height="56" rx="5"/><text class="lb" x="550" y="42" text-anchor="middle">Drain SMU</text><text class="sub" x="550" y="61" text-anchor="middle">V_D, measures I_D</text>
  <rect class="bx" x="690" y="230" width="170" height="60" rx="5"/><text class="lb" x="775" y="256" text-anchor="middle">Body SMU</text><text class="sub" x="775" y="276" text-anchor="middle">−V_SB to the substrate</text>
  <path class="w" d="M180,165 H395 M395,120 V210"/>
  <rect class="dev" x="410" y="110" width="120" height="110" rx="4"/>
  <path class="w" d="M425,120 V210" stroke-width="3"/><path class="w" d="M425,130 H550 V74 M425,200 H460 V300 H440 M445,306 H475 M452,312 H468"/>
  <path class="dc" d="M425,165 H500 M470,165 V240 H690"/><path class="w" d="M488,159 l12,6 -12,6" fill="var(--ink)"/>
  <text class="sub" x="470" y="296">source (0 V)</text><text class="lb" x="470" y="104" text-anchor="middle">bulk nMOS</text>`,
  },
  tps: [{ n: 1, x: 300, y: 165, label: "gate" }, { n: 2, x: 550, y: 100, label: "drain current" }, { n: 3, x: 600, y: 240, label: "body" }, { n: 4, x: 455, y: 188, label: "channel" }],
  sections: [{ k: "tp", t: "Test points", n: "Four terminals, four knobs." }, { k: "ana", t: "Scaling limits", n: "Why bulk planar stopped scaling around 28 nm." }],
  cards: [
    { id: "tp1", tp: 1, s: "tp", d: "ph", dn: "transfer", t: "Gate sweep: I_D vs V_G", x: "Grey: V_SB = 0, 0.75 and 1.5 V. Reverse body bias shifts the curve right (higher V_t) and slightly flattens the slope.", eq: "V<sub>t</sub> = V<sub>FB</sub> + 2φ<sub>F</sub> + γ<span class=\"rt\">√</span><span class=\"rad\">2φ<sub>F</sub> + V<sub>SB</sub></span>,&nbsp; γ = <span class=\"rt\">√</span><span class=\"rad\">2qε<sub>Si</sub>N<sub>A</sub></span>/C<sub>ox</sub>", h: "tall" },
    { id: "tp2", tp: 2, s: "tp", d: "rf", dn: "output", t: "Drain SMU: I_D vs V_D", x: "Output curves for V_G = 0.4 … 1.4 V (W = 1 µm). Short channels show a steeper saturation slope (channel-length modulation and DIBL).", eq: "I<sub>D,sat</sub> ≈ (β/2n)(V<sub>G</sub> − V<sub>t</sub>)²(1 + λV<sub>D</sub>)", h: "tall" },
    { id: "tp3", tp: 3, s: "tp", d: "dc", dn: "body effect", t: "Body: V_t vs V_SB", x: "Square-root dependence: more reverse body bias, more depletion charge to support before inversion. Three dopings shown; marker = current.", eq: "∂V<sub>t</sub>/∂V<sub>SB</sub> = γ/(2<span class=\"rt\">√</span><span class=\"rad\">2φ<sub>F</sub> + V<sub>SB</sub></span>) = n − 1" },
    { id: "tp4", tp: 4, s: "tp", d: "ph", dn: "channel", t: "Channel: source barrier along the surface", x: "Conduction band from source to drain at threshold. Dashed: V_D = 0.05 V; solid: the set V_D. The drop of the barrier peak is DIBL.", eq: "E<sub>c</sub>(x): natural-length solution, λ = <span class=\"rt\">√</span><span class=\"rad\">(ε<sub>Si</sub>/ε<sub>ox</sub>)t<sub>ox</sub>W<sub>dep</sub></span>" },
    { id: "a1", chip: "V_t(L)", s: "ana", d: "an", dn: "roll-off", t: "Threshold roll-off vs gate length", x: "Shorter gates lose V_t as source and drain depletion share the channel charge. More doping shortens λ and pushes the cliff to smaller L, at the price of mobility and junction leakage.", eq: "ΔV<sub>t</sub> ≈ −0.8·e<sup>−L/2λ</sup> − DIBL·V<sub>D</sub>" },
  ],
  foot: "Model: long-channel V_t from the depletion approximation (n⁺ poly, 2 nm oxide), body factor n = 1 + γ/(2√(2φ_F+V_SB)), short-channel terms from the natural length λ; EKV current with µ_eff = 300 cm²/V·s, W = 1 µm, θ = 1.2 V⁻¹. Illustrative values.",
  sim(st) {
    const p = params(st);
    const R = { p, id: Id(st.VG, st.VD, p) };
    R.idg = map(VGs, (v) => Id(v, st.VD, p));
    R.cmp = [0, 0.75, 1.5].map((vsb) => map(VGs, (v) => Id(v, st.VD, params({ ...st, VSB: vsb }))));
    R.vds = linspace(0, 1.4, 113);
    R.fam = [0.4, 0.6, 0.8, 1.0, 1.2, 1.4].map((vg) => map(R.vds, (vd) => Id(vg, vd, p)));
    R.cur = map(R.vds, (vd) => Id(st.VG, vd, p));
    R.vsb = linspace(0, 2, 41);
    R.body = [3e17, 1e18, 3e18].map((Na) => map(R.vsb, (v) => vtLong(Na, v).Vt));
    const Ecch = 0.56 - 2 * p.phiF + 0.1; // barrier near threshold
    R.bar = lateralChannel({ Ecch, VD: st.VD, LS: 30, LG: st.L, LD: 30, lam: p.lam });
    R.bar0 = lateralChannel({ Ecch, VD: 0.05, LS: 30, LG: st.L, LD: 30, lam: p.lam });
    R.Ls = linspace(25, 250, 91);
    R.roll = [3e17, 1e18, 3e18].map((Na) => map(R.Ls, (L) => { const q2 = params({ ...st, Na, L }); return q2.Vt - q2.dibl * st.VD; }));
    R.ss = p.n * Ut300 * Math.log(10) * 1000;
    return R;
  },
  render(R, api) {
    const { st, C } = api, p = R.p;
    api.status([["I_D", fSI(R.id, "A"), ""], ["V_t", f(p.Vt - p.dibl * st.VD, 3) + " V", ""], ["SS", R.ss.toFixed(1) + " mV/dec", R.ss > 100 ? "warn" : ""],
      ["DIBL", (p.dibl * 1000).toFixed(0) + " mV/V", p.dibl > 0.15 ? "warn" : "good"], ["Body factor γ", p.gamma.toFixed(3) + " V^½", ""], ["λ", p.lam.toFixed(1) + " nm", ""]]);
    api.plot("tp1", { xmin: -0.3, xmax: 1.4, ylog: true, ymin: 1e-13, ymax: 1e-2, xlabel: "V_G (V)", ylabel: "I_D (A)", series: [...R.cmp.map((y) => ({ x: VGs, y, color: C.muted, w: 1, dash: [3, 3] })), { x: VGs, y: R.idg, color: C.ph, w: 2.2 }], points: [{ x: st.VG, y: Math.max(R.id, 1e-13), color: C.ink }] });
    api.eqv("tp1", `V_FB = ${f(p.Vfb, 2)} V, 2φ_F = ${(2 * p.phiF).toFixed(2)} V, γ = ${p.gamma.toFixed(3)} → V_t,long = ${f(p.Vt + 0.8 * Math.exp(-st.L / (2 * p.lam)), 3)} V`);
    api.ro("tp1", [["I_D", fSI(R.id, "A")], ["I_off (V_G = 0)", fSI(Id(0, st.VD, p), "A")], ["SS", R.ss.toFixed(1) + " mV/dec"]]);
    api.plot("tp2", { xmin: 0, xmax: 1.4, ymin: 0, xlabel: "V_D (V)", ylabel: "I_D (mA)", series: [...R.fam.map((y) => ({ x: R.vds, y: map(y, (v) => v * 1e3), color: C.muted, w: 1 })), { x: R.vds, y: map(R.cur, (v) => v * 1e3), color: C.rf, w: 2.2 }], points: [{ x: st.VD, y: R.id * 1e3, color: C.ink }] });
    api.ro("tp2", [["I_D", fSI(R.id, "A")], ["λ (CLM)", p.lambda.toFixed(2) + " V⁻¹"]]);
    api.plot("tp3", { xmin: 0, xmax: 2, xlabel: "V_SB (V)", ylabel: "V_t,long (V)", legend: true, series: R.body.map((y, i) => ({ x: R.vsb, y, color: [C.ok, C.dc, C.bad][i], w: 1.8, label: ["3×10¹⁷", "10¹⁸", "3×10¹⁸"][i] })), points: [{ x: st.VSB, y: vtLong(st.Na, st.VSB).Vt, color: C.ink }] });
    api.ro("tp3", [["V_t,long", f(vtLong(st.Na, st.VSB).Vt, 3) + " V"], ["Body factor n", p.nB.toFixed(3)], ["Depletion depth", p.Wd.toFixed(1) + " nm"]]);
    api.plot("tp4", { xmin: 0, xmax: 60 + st.L, xlabel: "x (nm)", ylabel: "E_c (eV)", series: [{ x: R.bar0.x, y: R.bar0.Ec, color: C.muted, w: 1.4, dash: [4, 3] }, { x: R.bar.x, y: R.bar.Ec, color: C.ph, w: 2.2 }], vbands: [{ x0: 30, x1: 30 + st.L, color: C.edge, a: 0.12, label: "gate" }] });
    const pk = (a) => Math.max(...a.Ec);
    api.ro("tp4", [["Barrier drop", ((pk(R.bar0) - pk(R.bar)) * 1000).toFixed(0) + " meV"], ["L/2λ", (st.L / (2 * p.lam)).toFixed(2)]]);
    api.plot("a1", { xmin: 25, xmax: 250, xlabel: "L (nm)", ylabel: "V_t (V)", legend: true, series: R.roll.map((y, i) => ({ x: R.Ls, y, color: [C.ok, C.dc, C.bad][i], w: 1.8, label: ["3×10¹⁷", "10¹⁸", "3×10¹⁸"][i] })), points: [{ x: st.L, y: p.Vt - p.dibl * st.VD, color: C.ink, label: "this device" }] });
    api.ro("a1", [["V_t at L", f(p.Vt - p.dibl * st.VD, 3) + " V"], ["Roll-off", (-0.8 * Math.exp(-st.L / (2 * p.lam)) * 1000).toFixed(0) + " mV"]]);
  },
};

export default { atomic, bench };
