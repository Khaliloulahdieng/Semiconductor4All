// CMOS inverter: one nMOS pull-down and one pMOS pull-up sharing the input and the output.
import { buildGrid, solvePoisson, ekvId, visDensity, fSI, f, Ut300 } from "../lib/physics.js";
import { linspace, map } from "../lib/plot.js";

// ---------- compact model ----------
const NM = { Vt: 0.35, n: 1.3, beta: 2.2e-4, Ut: Ut300, dibl: 0.05, lambda: 0.1, theta: 1.0 };
const pm = (ratio) => ({ ...NM, beta: NM.beta * 0.45 * ratio }); // holes ≈ 0.45× electron mobility
const In = (Vin, Vout) => ekvId(Vin, Vout, NM);
const Ip = (Vin, Vout, VDD, ratio) => ekvId(VDD - Vin, VDD - Vout, pm(ratio));
function vout(Vin, VDD, ratio) { // DC: I_n(V_in, V_out) = I_p
  let lo = 0, hi = VDD;
  for (let k = 0; k < 50; k++) { const m = (lo + hi) / 2; if (In(Vin, m) > Ip(Vin, m, VDD, ratio)) hi = m; else lo = m; }
  return (lo + hi) / 2;
}
function vtc(VDD, ratio, n = 161) {
  const x = linspace(0, VDD, n), y = map(x, (v) => vout(v, VDD, ratio));
  const g = map(x, (v, i) => (i === 0 ? 0 : (y[i] - y[i - 1]) / (x[i] - x[i - 1])));
  // unity-gain points → noise margins
  let VIL = 0, VIH = VDD, VM = VDD / 2;
  for (let i = 1; i < n; i++) { if (g[i] < -1 && VIL === 0) VIL = x[i]; if (g[i] < -1) VIH = x[i]; if (y[i - 1] >= x[i - 1] && y[i] < x[i]) VM = x[i]; }
  const VOH = vout(VIL, VDD, ratio), VOL = vout(VIH, VDD, ratio);
  return { x, y, VIL, VIH, VM, NMH: VOH - VIH, NML: VIL - VOL, gain: Math.min(...g) };
}

// ---------- atomic ----------
const TOX = 1.6;
function mos(VG, body, Vb, wf) { // vertical cut through one gate: n-type body for the pMOS, p-type for the nMOS
  const g = buildGrid([{ mat: "SiO2", t: TOX, dx: 0.25 }, { mat: "Si", t: 80, N: body, dx: 0.5, phin: Vb, phip: Vb }]);
  const s = solvePoisson(g, { left: { type: "gate", V: VG, wf }, right: { type: "ohmic", V: Vb } });
  let ns = 0, ps = 0;
  for (let i = 1; i < g.x.length; i++) if (g.x[i] > TOX && g.x[i] < TOX + 8) { const dx = (g.x[i] - g.x[i - 1]) * 1e-7; ns += s.n[i] * dx; ps += s.p[i] * dx; }
  return { g, s, ns, ps };
}

const atomic = {
  intro: "Both transistors of an inverter, side by side in their wells: the nMOS in a p-well (left) and the pMOS in an n-well (right). One input drives both gates. When the input is high the nMOS channel fills with electrons and pulls the output to ground; when it is low the pMOS channel fills with holes and pulls the output to V_DD. Not to scale.",
  controls: [
    { label: "Input", color: "ph", items: [{ id: "Vin", label: "V_in (both gates)", min: 0, max: 1.0, step: 0.01, value: 0.2, fmt: (v) => v.toFixed(2) + " V" }] },
    { label: "Supply", color: "dc", items: [{ id: "VDD", label: "V_DD", min: 0.5, max: 1.0, step: 0.05, value: 1.0, fmt: (v) => v.toFixed(2) + " V" }] },
  ],
  presets: [{ label: "Input low", set: { Vin: 0 } }, { label: "Switching point", set: { Vin: 0.5 } }, { label: "Input high", set: { Vin: 1.0 } }],
  look: [
    "At V_in = 0 the pMOS (right) is inverted (holes under its gate) and the nMOS is off: the output sits at V_DD.",
    "Around V_DD/2 both channels conduct a little: a short-circuit current flows from V_DD to ground while the output swings.",
    "Compare the two vertical cuts: the same gate voltage bends the bands down in the p-well (attracts electrons) and up relative to V_DD in the n-well (attracts holes).",
  ],
  world: { w: 200, h: 100 }, aspect: "2/1", lensAt: [50, 44],
  cuts: [{ id: "n", label: "nMOS gate → p-well", a: [50, 32], b: [50, 99] }, { id: "p", label: "pMOS gate → n-well", a: [150, 32], b: [150, 99] }],
  solve(st) {
    const Vin = Math.min(st.Vin, st.VDD), Vo = vout(Vin, st.VDD, 2);
    return { Vin, Vo, n: mos(Vin, -5e17, 0, 4.05), p: mos(Vin, 5e17, st.VDD, 5.17), I: In(Vin, Vo) };
  },
  scene(S, st) {
    const dn = visDensity(S.n.ns / 8e-7, 14, 19.5), dp = visDensity(S.p.ps / 8e-7, 14, 19.5);
    const flow = S.I > 1e-9 ? Math.min(30, 5 * Math.log10(S.I * 1e11)) : 0;
    const hiOut = S.Vo > st.VDD / 2;
    return {
      regions: [
        { x: 0, y: 40, w: 100, h: 60, mat: "si", dop: "p" }, { x: 100, y: 40, w: 100, h: 60, mat: "si", dop: "n" },
        { x: 94, y: 40, w: 12, h: 18, mat: "ox" },
        { x: 8, y: 40, w: 30, h: 10, mat: "si", dop: "n+" }, { x: 62, y: 40, w: 30, h: 10, mat: "si", dop: "n+" },
        { x: 108, y: 40, w: 30, h: 10, mat: "si", dop: "p+" }, { x: 162, y: 40, w: 30, h: 10, mat: "si", dop: "p+" },
        { x: 38, y: 37, w: 24, h: 3, mat: "ox" }, { x: 38, y: 24, w: 24, h: 13, mat: "poly" },
        { x: 138, y: 37, w: 24, h: 3, mat: "ox" }, { x: 138, y: 24, w: 24, h: 13, mat: "poly" },
        { x: 67, y: 8, w: 66, h: 6, mat: "metal" }, { x: 72, y: 14, w: 8, h: 26, mat: "metal" }, { x: 120, y: 14, w: 8, h: 26, mat: "metal" },
      ],
      depl: [...(dn < 0.3 ? [{ x: 38, y: 40, w: 24, h: 8 }] : []), ...(dp < 0.3 ? [{ x: 138, y: 40, w: 24, h: 8 }] : [])],
      zones: [
        { id: "ns", type: "e", x: 8, y: 40, w: 30, h: 10, dens: 0.9 }, { id: "nd", type: "e", x: 62, y: 40, w: 30, h: 10, dens: 0.9 },
        { id: "nch", type: "e", x: 38, y: 40, w: 24, h: 2.2, dens: dn, vx: hiOut ? 0 : -flow, jit: 0.3 },
        { id: "pw", type: "h", x: 0, y: 52, w: 94, h: 48, dens: 0.35 },
        { id: "ps", type: "h", x: 162, y: 40, w: 30, h: 10, dens: 0.9 }, { id: "pd", type: "h", x: 108, y: 40, w: 30, h: 10, dens: 0.9 },
        { id: "pch", type: "h", x: 138, y: 40, w: 24, h: 2.2, dens: dp, vx: hiOut ? -flow : 0, jit: 0.3 },
        { id: "nw", type: "e", x: 106, y: 52, w: 94, h: 48, dens: 0.35 },
      ],
      labels: [{ x: 50, y: 90, text: "p-well: nMOS", size: 10 }, { x: 150, y: 90, text: "n-well: pMOS", size: 10 }, { x: 100, y: 11, text: "output node", size: 9 }],
      terminals: [{ x: 50, y: 18, text: `IN ${S.Vin.toFixed(2)}` }, { x: 150, y: 18, text: `IN ${S.Vin.toFixed(2)}` }, { x: 100, y: 3, text: `OUT ${S.Vo.toFixed(2)} V` }, { x: 23, y: 32, text: "GND" }, { x: 177, y: 32, text: `V_DD ${st.VDD.toFixed(2)}` }],
    };
  },
  bands(S, st, cut) {
    const M = cut === "n" ? S.n : S.p;
    const { g, s } = M;
    return { x: s.x, Ec: s.Ec, Ev: s.Ev, EFn: s.EFn, EFp: s.EFp, n: s.n, p: s.p, E: s.E, Nabs: map(g.N, Math.abs), regions: [{ x0: 0, x1: TOX, label: "" }, { x0: TOX, x1: TOX + 80, label: cut === "n" ? "p-well" : "n-well" }], xlabel: "depth from gate (nm)", clip: [-3, 3] };
  },
  readouts(S, st) {
    return [["V_out", S.Vo.toFixed(3) + " V"], ["nMOS channel e⁻", S.n.ns.toExponential(1) + " cm⁻²"], ["pMOS channel h⁺", S.p.ps.toExponential(1) + " cm⁻²"], ["Supply current", fSI(S.I, "A")]];
  },
  foot: "Vertical cuts: 1D Poisson under each gate (n⁺ poly on a 5×10¹⁷ p-well, p⁺ poly on a 5×10¹⁷ n-well at V_DD), 1.6 nm oxide. Output from the DC balance I_n = I_p of EKV models (W_p/W_n = 2). Illustrative values.",
};

// ---------- bench ----------
function transient(st) {
  const VDD = st.VDD, T = 1 / st.f, tr = Math.min(0.05 * T, 20e-12), C = st.CL * 1e-15;
  const N = 1200, dt = (2 * T) / N;
  const t = new Float64Array(N), vi = new Float64Array(N), vo = new Float64Array(N), idd = new Float64Array(N);
  let v = VDD, E = 0;
  for (let i = 0; i < N; i++) {
    const ti = i * dt, ph = ti % T;
    const x = ph < T / 2 ? Math.min(1, ph / tr) : Math.max(0, 1 - (ph - T / 2) / tr);
    const Vin = x * VDD;
    for (let k = 0; k < 8; k++) { const ip = Ip(Vin, v, VDD, st.ratio), inn = In(Vin, v); v += ((ip - inn) * dt) / 8 / C; v = Math.min(VDD, Math.max(0, v)); }
    t[i] = ti * 1e12; vi[i] = Vin; vo[i] = v; idd[i] = Ip(Vin, v, VDD, st.ratio); E += idd[i] * VDD * dt;
  }
  const cross = (arr, from, rising) => { for (let i = from + 1; i < N; i++) if (rising ? arr[i - 1] < VDD / 2 && arr[i] >= VDD / 2 : arr[i - 1] > VDD / 2 && arr[i] <= VDD / 2) return t[i]; return NaN; };
  const tinR = cross(vi, 0, true), toutF = cross(vo, 0, false);
  const half = Math.floor(N / 2);
  const tinF = cross(vi, Math.floor(N / 4), false), toutR = cross(vo, Math.floor(N / 4), true);
  return { t, vi, vo, idd, tpHL: toutF - tinR, tpLH: toutR - tinF, E: E / 2, half };
}
const bench = {
  intro: "A pulse generator drives the inverter input; the output drives a load capacitance (the next gates and wires). A current probe on V_DD shows where the energy goes.",
  animated: true,
  controls: [
    { label: "Supply (TP3)", color: "dc", items: [{ id: "VDD", label: "V_DD", min: 0.4, max: 1.2, step: 0.02, value: 0.9, fmt: (v) => v.toFixed(2) + " V" }] },
    { label: "Input generator (TP1)", color: "ph", items: [{ id: "f", label: "Frequency", min: 0.5e9, max: 10e9, step: 0.5e9, value: 2e9, fmt: (v) => (v / 1e9).toFixed(1) + " GHz" }] },
    { label: "Sizing and load (TP2)", color: "rf", items: [{ id: "ratio", label: "W_p / W_n", min: 0.5, max: 4, step: 0.1, value: 2, fmt: (v) => v.toFixed(1) }, { id: "CL", label: "Load capacitance", min: 1, max: 30, step: 1, value: 5, fmt: (v) => v + " fF" }] },
  ],
  presets: [
    { label: "Nominal 0.9 V, 2 GHz", set: { VDD: 0.9, f: 2e9, ratio: 2, CL: 5 } },
    { label: "Near threshold 0.45 V", set: { VDD: 0.45, f: 0.5e9, ratio: 2, CL: 5 } },
    { label: "Weak pMOS (ratio 0.6)", set: { ratio: 0.6 } },
    { label: "Heavy load 30 fF", set: { CL: 30 } },
  ],
  schematic: {
    viewBox: "0 0 900 340",
    svg: `
  <rect class="bx" x="30" y="140" width="150" height="56" rx="5"/><text class="lb" x="105" y="164" text-anchor="middle">Pulse generator</text><text class="sub" x="105" y="183" text-anchor="middle">0 ↔ V_DD</text>
  <path class="w" d="M180,168 H330 M330,100 V236 M330,100 H380 M330,236 H380"/>
  <rect class="dev" x="380" y="70" width="90" height="60" rx="4"/><text class="lb" x="425" y="96" text-anchor="middle">pMOS</text><text class="sub" x="425" y="114" text-anchor="middle">W_p</text>
  <rect class="dev" x="380" y="206" width="90" height="60" rx="4"/><text class="lb" x="425" y="232" text-anchor="middle">nMOS</text><text class="sub" x="425" y="250" text-anchor="middle">W_n</text>
  <path class="w" d="M425,130 V206 M425,168 H620 M425,266 V300 H405 M410,306 H440 M417,312 H433"/>
  <path class="dc" d="M425,70 V30 H700"/><rect class="bx" x="700" y="10" width="160" height="44" rx="5"/><text class="lb" x="780" y="37" text-anchor="middle">V_DD supply + probe</text>
  <rect class="bx chip" x="600" y="200" width="70" height="40" rx="4"/><text class="lb" x="635" y="225" text-anchor="middle">C_L</text>
  <path class="w" d="M635,168 V200 M635,240 V270 H615 M620,276 H650 M627,282 H643"/>
  <rect class="bx" x="700" y="140" width="160" height="56" rx="5"/><text class="lb" x="780" y="164" text-anchor="middle">Scope</text><text class="sub" x="780" y="183" text-anchor="middle">V_in, V_out</text>
  <path class="rf" d="M620,168 H700" stroke-dasharray="4 3"/>`,
  },
  tps: [{ n: 1, x: 260, y: 168, label: "input" }, { n: 2, x: 540, y: 168, label: "output" }, { n: 3, x: 560, y: 30, label: "supply current" }, { n: 4, x: 425, y: 168, label: "transfer curve" }],
  sections: [{ k: "tr", t: "Switching", n: "Time axis in picoseconds." }, { k: "dc", t: "DC behaviour and scaling", n: "" }],
  cards: [
    { id: "tp1", tp: 1, s: "tr", d: "ph", dn: "input", t: "Input waveform", x: "Square wave with finite edges, 0 ↔ V_DD.", eq: "V<sub>in</sub>(t): rise/fall time = 5 % of the period (≤ 20 ps)" },
    { id: "tp2", tp: 2, s: "tr", d: "rf", dn: "output", t: "Output waveform", x: "The output charges and discharges C_L through the pMOS and nMOS. Propagation delays are measured at V_DD/2.", eq: "t<sub>p</sub> ≈ C<sub>L</sub>V<sub>DD</sub>/(2I<sub>on</sub>),&nbsp; I<sub>on</sub> ∝ (V<sub>DD</sub> − V<sub>t</sub>)<sup>α</sup>" },
    { id: "tp3", tp: 3, s: "tr", d: "dc", dn: "power", t: "Supply current", x: "Current from V_DD: a spike when the output charges (pMOS on), a small blip on the falling edge (short-circuit current).", eq: "E<sub>cycle</sub> = C<sub>L</sub>V<sub>DD</sub>² + E<sub>sc</sub>,&nbsp; P = E<sub>cycle</sub>·f + I<sub>leak</sub>V<sub>DD</sub>" },
    { id: "tp4", tp: 4, s: "dc", d: "an", dn: "DC", t: "Voltage transfer curve", x: "V_out vs V_in with the mirror curve (dashed). V_M is the switching threshold; the unity-gain points define the noise margins.", eq: "NM<sub>H</sub> = V<sub>OH</sub> − V<sub>IH</sub>,&nbsp; NM<sub>L</sub> = V<sub>IL</sub> − V<sub>OL</sub>,&nbsp; I<sub>n</sub>(V<sub>M</sub>) = I<sub>p</sub>(V<sub>M</sub>)" },
    { id: "a1", chip: "E–t", s: "dc", d: "an", dn: "scaling", t: "Delay and energy vs V_DD", x: "Lowering V_DD saves energy quadratically but slows the gate dramatically near threshold. The energy-delay product has a minimum in between.", eq: "E ∝ V<sub>DD</sub>²,&nbsp; t<sub>p</sub> ∝ V<sub>DD</sub>/(V<sub>DD</sub> − V<sub>t</sub>)<sup>α</sup>" },
  ],
  foot: "Model: EKV nMOS and pMOS (V_t = 0.35 V, n = 1.3, hole mobility 0.45× electrons), output node integrated with C_L dV/dt = I_p − I_n. Wire resistance and input capacitance of the gate itself are ignored. Illustrative values.",
  sim(st) {
    const R = { tr: transient(st), vtc: vtc(st.VDD, st.ratio) };
    R.vdd = linspace(0.3, 1.2, 46);
    R.delay = map(R.vdd, (v) => { const iOn = (In(v, v) + Ip(0, 0, v, st.ratio)) / 2; return (st.CL * 1e-15 * v) / (2 * iOn) * 1e12; });
    R.energy = map(R.vdd, (v) => st.CL * v * v);
    return R;
  },
  render(R, api) {
    const { st, C } = api, T = R.tr, V = R.vtc;
    const n = T.t.length, cur = (api.frame * 6) % n;
    api.status([["t_pHL / t_pLH", (T.tpHL || 0).toFixed(1) + " / " + (T.tpLH || 0).toFixed(1) + " ps", ""], ["Switching point V_M", V.VM.toFixed(3) + " V", Math.abs(V.VM - st.VDD / 2) > 0.1 * st.VDD ? "warn" : "good"],
      ["NM_L / NM_H", V.NML.toFixed(2) + " / " + V.NMH.toFixed(2) + " V", ""], ["Energy / cycle", (T.E * 1e15).toFixed(2) + " fJ", ""], ["Dynamic power", fSI(T.E * st.f, "W"), ""],
      ["Full swing?", Math.min(...T.vo) < 0.1 * st.VDD && Math.max(...T.vo) > 0.9 * st.VDD ? "yes" : "no: too fast", Math.min(...T.vo) < 0.1 * st.VDD && Math.max(...T.vo) > 0.9 * st.VDD ? "good" : "warn"]]);
    const xmax = T.t[n - 1];
    api.plot("tp1", { xmin: 0, xmax, ymin: -0.1, ymax: st.VDD * 1.15, xlabel: "time (ps)", ylabel: "V_in (V)", series: [{ x: T.t, y: T.vi, color: C.ph, w: 2 }], cursor: T.t[cur] });
    api.ro("tp1", [["Period", (1e12 / st.f).toFixed(0) + " ps"], ["V_in at cursor", T.vi[cur].toFixed(2) + " V"]]);
    api.plot("tp2", { xmin: 0, xmax, ymin: -0.1, ymax: st.VDD * 1.15, xlabel: "time (ps)", ylabel: "V (V)", series: [{ x: T.t, y: T.vi, color: C.muted, w: 1, dash: [3, 3] }, { x: T.t, y: T.vo, color: C.rf, w: 2.2 }], hlines: [{ y: st.VDD / 2, color: C.muted, dash: [2, 3], label: "V_DD/2" }], cursor: T.t[cur] });
    api.eqv("tp2", `t_pHL = ${(T.tpHL || 0).toFixed(1)} ps, t_pLH = ${(T.tpLH || 0).toFixed(1)} ps for C_L = ${st.CL} fF`);
    api.ro("tp2", [["V_out at cursor", T.vo[cur].toFixed(3) + " V"], ["t_pHL", (T.tpHL || 0).toFixed(1) + " ps"], ["t_pLH", (T.tpLH || 0).toFixed(1) + " ps"]]);
    api.plot("tp3", { xmin: 0, xmax, ymin: 0, xlabel: "time (ps)", ylabel: "I_DD (µA)", series: [{ x: T.t, y: map(T.idd, (v) => v * 1e6), color: C.dc, w: 1.8, fill: C.dc }], cursor: T.t[cur] });
    api.eqv("tp3", `E = ${(T.E * 1e15).toFixed(2)} fJ per cycle vs C_L·V_DD² = ${(st.CL * st.VDD * st.VDD).toFixed(2)} fJ`);
    api.ro("tp3", [["Peak I_DD", fSI(Math.max(...T.idd), "A")], ["Energy/cycle", (T.E * 1e15).toFixed(2) + " fJ"]]);
    api.plot("tp4", { xmin: 0, xmax: st.VDD, ymin: 0, ymax: st.VDD, xlabel: "V_in (V)", ylabel: "V_out (V)", series: [{ x: V.y, y: V.x, color: C.muted, w: 1.2, dash: [4, 3] }, { x: V.x, y: V.y, color: C.ink, w: 2.2 }, { x: V.x, y: V.x, color: C.edge, w: 1, dash: [1, 3] }], vlines: [{ x: V.VIL, color: C.ok, dash: [2, 3], label: "V_IL" }, { x: V.VIH, color: C.bad, dash: [2, 3], label: "V_IH" }], points: [{ x: V.VM, y: V.VM, color: C.ph, label: "V_M" }] });
    api.ro("tp4", [["V_M", V.VM.toFixed(3) + " V"], ["NM_L", V.NML.toFixed(3) + " V"], ["NM_H", V.NMH.toFixed(3) + " V"], ["Peak gain", Math.abs(V.gain).toFixed(1)]]);
    api.plot("a1", { xmin: 0.3, xmax: 1.2, ylog: true, ymin: 0.1, ymax: 1e4, xlabel: "V_DD (V)", ylabel: "delay (ps) · energy (fJ)", legend: true, series: [{ x: R.vdd, y: R.delay, color: C.rf, w: 2, label: "delay ps" }, { x: R.vdd, y: R.energy, color: C.dc, w: 2, label: "energy fJ" }, { x: R.vdd, y: map(R.vdd, (v, i) => R.delay[i] * R.energy[i] / 10), color: C.ink, w: 1.4, dash: [4, 3], label: "EDP/10" }], vlines: [{ x: st.VDD, color: C.ink, dash: [2, 3] }] });
    api.ro("a1", [["Delay at V_DD", (R.delay[Math.round((st.VDD - 0.3) / 0.02)] || 0).toFixed(1) + " ps"], ["C·V²", (st.CL * st.VDD * st.VDD).toFixed(2) + " fJ"]]);
  },
};

export default { atomic, bench };
