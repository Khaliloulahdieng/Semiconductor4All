// Bulk n-FinFET (7–16 nm class): a thin silicon fin wrapped on three sides by the gate.
import { buildGrid, solvePoisson, ekvId, lateralChannel, interp, visDensity, fSI, f, Ut300 } from "../lib/physics.js";
import { linspace, map } from "../lib/plot.js";

const HFIN = 42, TOX = 1.0; // nm; EOT of the high-k stack
const natLen = (W) => Math.sqrt((11.7 / (2 * 3.9)) * W * TOX); // double-gate natural length λ (nm)

// ---------- compact model ----------
function params(st) {
  const lam = natLen(st.W), e = Math.exp(-st.L / (2 * lam));
  const n = 1 / (1 - 2 * e), dibl = 0.9 * e, roll = 0.55 * e;
  const Weff = st.nfin * (2 * HFIN + st.W); // nm
  const beta = 120 * 3.45e-6 * Weff / st.L;  // µ_eff·C_ox·W/L
  return { Vt: 0.32 - roll, n, beta, Ut: Ut300, dibl, lambda: 0.15, theta: 1.6, lam, Weff };
}
const Id = (VG, VD, p) => ekvId(VG, VD, p);
const ssOf = (p) => p.n * Ut300 * Math.log(10) * 1000;
function vtCC(p, VD, Weff) {
  const target = 1e-7 * (Weff / 1000) / 0.02; // 100 nA·W/L with L normalised to 20 nm
  let lo = -1, hi = 1.5;
  for (let k = 0; k < 50; k++) { const m = (lo + hi) / 2; if (Id(m, VD, p) > target) hi = m; else lo = m; }
  return (lo + hi) / 2;
}

// ---------- atomic: double-gate cut across the fin ----------
const WF = 4.6;
function across(VG, W) {
  const g = buildGrid([
    { mat: "SiO2", t: TOX, dx: 0.2 },
    { mat: "Si", t: W, N: -1e16, dx: 0.25 },
    { mat: "SiO2", t: TOX, dx: 0.2 },
  ]);
  const s = solvePoisson(g, { left: { type: "gate", V: VG, wf: WF }, right: { type: "gate", V: VG, wf: WF } });
  let ns = 0;
  for (let i = 1; i < g.x.length; i++) if (g.x[i] > TOX && g.x[i] <= TOX + W) ns += s.n[i] * (g.x[i] - g.x[i - 1]) * 1e-7;
  const mid = TOX + W / 2;
  return { g, s, ns, nEdge: interp(s.x, s.n, TOX + 0.4), nMid: interp(s.x, s.n, mid), EcMid: interp(s.x, s.Ec, mid) };
}

const fmtV = (v) => f(v, 2) + " V";
const atomic = {
  intro: "Cross-section through the gate, perpendicular to the current: the fin is a silicon wall a few nanometres wide, and the gate wraps its two sides and its top. Current flows into the page. Hover the fin to see the lattice; thin the fin to watch the whole volume invert at once. Not to scale.",
  controls: [
    { label: "Gate", color: "ph", items: [{ id: "VG", label: "Gate voltage V_G", min: -0.3, max: 0.9, step: 0.01, value: 0.5, fmt: fmtV }] },
    { label: "Drain", color: "rf", items: [{ id: "VD", label: "Drain voltage V_D", min: 0, max: 0.9, step: 0.01, value: 0.7, fmt: fmtV }] },
    { label: "Fin geometry", color: "dc", items: [{ id: "W", label: "Fin width", min: 5, max: 15, step: 0.5, value: 7, fmt: (v) => v.toFixed(1) + " nm" }, { type: "note", text: "Gate length L = 20 nm (fixed here)." }] },
  ],
  presets: [
    { label: "Off", set: { VG: 0, VD: 0.7 } }, { label: "Threshold", set: { VG: 0.3, VD: 0.05 } }, { label: "On", set: { VG: 0.8, VD: 0.7 } },
    { label: "Thin fin 5 nm", set: { W: 5, VG: 0.3 } }, { label: "Wide fin 15 nm", set: { W: 15, VG: 0.3 } },
  ],
  look: [
    "On the cut across the fin, raise V_G: the bands bend down from both sides at once. With a 5 nm fin the centre bends almost as much as the surfaces (volume inversion).",
    "Widen the fin to 15 nm: the centre of the fin no longer follows the gate, and on the channel cut the drain pulls the barrier down more (larger DIBL).",
    "Compare with the FD-SOI device: two side gates control the channel better than one top gate, so the natural length λ is smaller.",
  ],
  world: { w: 160, h: 100 }, aspect: "8/5", lensAt: [80, 40],
  cuts: [{ id: "across", label: "Across the fin (gate → gate)", a: [56, 40], b: [104, 40] }, { id: "lat", label: "Along the channel (S → D)", a: [80, 30], b: [80, 30] }],
  solve(st) {
    const A = across(st.VG, st.W);
    const p = params({ ...st, L: 20, nfin: 1 });
    return { A, p, id: Id(st.VG, st.VD, p), lat: lateralChannel({ Ecch: A.EcMid, VD: st.VD, LS: 30, LG: 20, LD: 30, lam: natLen(st.W) }) };
  },
  scene(S, st) {
    const hw = st.W * 1.1, cx = 80, x0 = cx - hw, x1 = cx + hw, ox = 1.6;
    const dEdge = visDensity(S.A.nEdge, 14, 19.5), dMid = visDensity(S.A.nMid, 14, 19.5);
    const sw = Math.max(0.6, hw * 0.35);
    return {
      regions: [
        { x: 0, y: 75, w: 160, h: 25, mat: "si", dop: "p", label: "substrate" },
        { x: x0, y: 55, w: 2 * hw, h: 20, mat: "si", dop: "p+" },
        { x: 0, y: 55, w: x0, h: 20, mat: "ox" }, { x: x1, y: 55, w: 160 - x1, h: 20, mat: "ox" },
        { x: x0 - ox - 20, y: 8, w: 2 * hw + 2 * ox + 40, h: 47, mat: "metal" },
        { x: x0 - ox, y: 22 - ox, w: 2 * hw + 2 * ox, h: 55 - 22 + ox, mat: "ox" },
        { x: x0, y: 22, w: 2 * hw, h: 33, mat: "si", dop: "i" },
      ],
      zones: [
        { id: "l", type: "e", x: x0, y: 22, w: sw, h: 33, dens: dEdge, jit: 0.3 },
        { id: "r", type: "e", x: x1 - sw, y: 22, w: sw, h: 33, dens: dEdge, jit: 0.3 },
        { id: "t", type: "e", x: x0, y: 22, w: 2 * hw, h: 2.2, dens: dEdge, jit: 0.3 },
        { id: "c", type: "e", x: x0 + sw, y: 24, w: Math.max(0.5, 2 * hw - 2 * sw), h: 31, dens: dMid, jit: 0.3 },
        { id: "sub", type: "h", x: 0, y: 76, w: 160, h: 24, dens: 0.4 },
        { id: "pts", type: "h", x: x0, y: 56, w: 2 * hw, h: 18, dens: 0.7 },
      ],
      depl: dMid < 0.3 ? [{ x: x0, y: 22, w: 2 * hw, h: 33 }] : [],
      labels: [
        { x: 30, y: 30, text: "metal gate", size: 10 }, { x: 30, y: 66, text: "STI oxide", size: 10, color: "muted" },
        { x: 130, y: 88, text: "p-substrate", size: 10, color: "muted" }, { x: cx, y: 82, text: "punch-through stop", size: 9, color: "muted" },
        { x: cx + hw + 14, y: 50, text: `fin ${st.W.toFixed(1)} nm`, size: 9, align: "left" },
      ],
      terminals: [{ x: 80, y: 4, text: `G ${f(st.VG, 2)} V` }, { x: 136, y: 16, text: `D ${f(st.VD, 2)} V (behind)` }],
    };
  },
  bands(S, st, cut) {
    if (cut === "across") {
      const { g, s } = S.A;
      return { x: s.x, Ec: s.Ec, Ev: s.Ev, EFn: s.EFn, EFp: s.EFp, n: s.n, p: s.p, E: s.E, Nabs: map(g.N, Math.abs),
        regions: [{ x0: 0, x1: TOX, label: "" }, { x0: TOX, x1: TOX + st.W, label: "fin" }, { x0: TOX + st.W, x1: 2 * TOX + st.W, label: "" }], xlabel: "position across the fin (nm)", clip: [-4, 4] };
    }
    return { ...S.lat, regions: [{ x0: 0, x1: 30, label: "source" }, { x0: 30, x1: 50, label: "channel" }, { x0: 50, x1: 80, label: "drain" }], xlabel: "position along the fin (nm)" };
  },
  readouts(S, st) {
    return [["Electrons in fin", S.A.ns.toExponential(1) + " cm⁻²"], ["Centre/surface density", (S.A.nMid / Math.max(S.A.nEdge, 1)).toFixed(2)],
      ["Natural length λ", natLen(st.W).toFixed(2) + " nm"], ["SS", ssOf(S.p).toFixed(1) + " mV/dec"], ["DIBL", (S.p.dibl * 1000).toFixed(0) + " mV/V"]];
  },
  foot: "Cut across the fin: 1D Poisson between two identical gates (EOT 1 nm, fin doping 10¹⁶ cm⁻³), quasi-Fermi level of the source. Channel cut: natural-length model with λ = √(ε_Si·W·t_ox/(2ε_ox)). Quantum confinement is ignored. Illustrative values.",
};

// ---------- bench ----------
const VGs = linspace(-0.2, 0.9, 111);
const bench = {
  intro: "A parameter analyser on a multi-fin transistor. Gate length, fin width and fin count are layout choices; follow how each one changes leakage, slope and drive.",
  controls: [
    { label: "Gate SMU (TP1)", color: "ph", items: [{ id: "VG", label: "Gate voltage V_G", min: -0.2, max: 0.9, step: 0.01, value: 0.75, fmt: fmtV }] },
    { label: "Drain SMU (TP2)", color: "rf", items: [{ id: "VD", label: "Drain voltage V_D", min: 0, max: 0.9, step: 0.01, value: 0.75, fmt: fmtV }] },
    { label: "Fin (TP3)", color: "dc", items: [{ id: "W", label: "Fin width", min: 5, max: 15, step: 0.5, value: 7, fmt: (v) => v.toFixed(1) + " nm" }, { id: "L", label: "Gate length L", min: 12, max: 40, step: 1, value: 20, fmt: (v) => v + " nm" }] },
    { label: "Layout (TP4)", color: "opt", items: [{ id: "nfin", label: "Number of fins", min: 1, max: 8, step: 1, value: 2, fmt: (v) => v + "" }] },
  ],
  presets: [
    { label: "Nominal: 2 fins, 7 nm, L 20 nm", set: { VG: 0.75, VD: 0.75, W: 7, L: 20, nfin: 2 } },
    { label: "Short gate L = 12 nm", set: { L: 12, W: 7 } },
    { label: "Fat fin 15 nm, L 12 nm", set: { L: 12, W: 15 } },
    { label: "Strong driver: 8 fins", set: { nfin: 8 } },
  ],
  schematic: {
    viewBox: "0 0 900 330",
    svg: `
  <rect class="bx" x="30" y="135" width="150" height="60" rx="5"/><text class="lb" x="105" y="161" text-anchor="middle">Gate SMU</text><text class="sub" x="105" y="181" text-anchor="middle">V_G sweep</text>
  <rect class="bx" x="560" y="18" width="160" height="56" rx="5"/><text class="lb" x="640" y="42" text-anchor="middle">Drain SMU</text><text class="sub" x="640" y="61" text-anchor="middle">V_D, measures I_D</text>
  <path class="w" d="M180,165 H340"/>
  <rect class="dev" x="340" y="95" width="230" height="150" rx="6"/>
  <g class="fins"></g>
  <rect x="352" y="150" width="206" height="28" fill="var(--m-metal)" opacity=".85"/><text class="sub" x="455" y="168" text-anchor="middle">gate wraps every fin</text>
  <path class="w" d="M570,120 H640 V74"/>
  <path class="w" d="M570,220 H640 V290 H620 M625,296 H655 M632,302 H648"/>
  <text class="sub" x="650" y="286">source (0 V)</text>
  <text class="lb" x="455" y="88" text-anchor="middle">n-FinFET</text>
  <text class="sub fintxt" x="455" y="262" text-anchor="middle"></text>
  <text class="cap" x="700" y="170">W_eff = n_fin · (2H_fin + W_fin)</text>`,
  },
  tps: [{ n: 1, x: 260, y: 165, label: "gate" }, { n: 2, x: 640, y: 100, label: "drain current" }, { n: 3, x: 455, y: 205, label: "fin electrostatics" }, { n: 4, x: 600, y: 250, label: "fin count" }],
  sections: [{ k: "tp", t: "Test points", n: "What the instruments measure, and why the fin shape matters." }, { k: "ana", t: "Scaling", n: "Why FinFETs replaced planar bulk transistors below about 22 nm." }],
  cards: [
    { id: "tp1", tp: 1, s: "tp", d: "ph", dn: "transfer", t: "Gate sweep: I_D vs V_G", x: "Log scale. Grey: fin widths 5, 10 and 15 nm at the same gate length; wide fins leak more and turn on more slowly.", eq: "SS = n·U<sub>T</sub>·ln10,&nbsp; n ≈ 1/(1 − 2e<sup>−L/2λ</sup>)<br>λ = <span class=\"rt\">√</span><span class=\"rad\">ε<sub>Si</sub>W<sub>fin</sub>t<sub>ox</sub>/(2ε<sub>ox</sub>)</span>", h: "tall" },
    { id: "tp2", tp: 2, s: "tp", d: "rf", dn: "output", t: "Drain SMU: I_D vs V_D", x: "Output curves for V_G = 0.3 … 0.9 V. Total current of all fins.", eq: "I<sub>D</sub> = n<sub>fin</sub>·I<sub>fin</sub>,&nbsp; β ∝ µC<sub>ox</sub>(2H<sub>fin</sub> + W<sub>fin</sub>)/L", h: "tall" },
    { id: "tp3", tp: 3, s: "tp", d: "dc", dn: "electrostatics", t: "Fin width: SS and DIBL", x: "Thinner fins shorten λ, so both the sub-threshold slope and DIBL improve. The marker is the current fin.", eq: "DIBL ≈ 0.9·e<sup>−L/2λ</sup> V/V,&nbsp; ΔV<sub>t,roll-off</sub> ≈ 0.55·e<sup>−L/2λ</sup> V" },
    { id: "tp4", tp: 4, s: "tp", d: "opt", dn: "layout", t: "Drive vs number of fins", x: "Width is quantised: you can only add whole fins. Bars: on-current for 1…8 fins at V_G = V_D = 0.75 V.", eq: "W<sub>eff</sub> = n<sub>fin</sub>(2H<sub>fin</sub> + W<sub>fin</sub>),&nbsp; H<sub>fin</sub> = 42 nm" },
    { id: "a1", chip: "V_t(L)", s: "ana", d: "an", dn: "short channel", t: "Threshold roll-off vs gate length", x: "As L shrinks toward λ, the drain and source take control of the channel and V_t falls. Thin fins push this cliff to shorter L.", eq: "V<sub>t</sub>(L) = V<sub>t,long</sub> − 0.55e<sup>−L/2λ</sup> − DIBL·V<sub>D</sub>" },
  ],
  foot: "Model: EKV channel per fin with n, DIBL and V_t roll-off from the double-gate natural length λ; µ_eff = 120 cm²/V·s, EOT 1 nm, H_fin = 42 nm, θ = 1.6 V⁻¹ for mobility degradation and velocity saturation. Illustrative values.",
  sim(st) {
    const p = params(st);
    const R = { p };
    R.id = Id(st.VG, st.VD, p);
    R.idg = map(VGs, (v) => Id(v, st.VD, p));
    R.cmp = [5, 10, 15].map((w) => map(VGs, (v) => Id(v, st.VD, params({ ...st, W: w }))));
    R.vt = vtCC(p, st.VD, p.Weff);
    R.vds = linspace(0, 0.9, 91);
    R.fam = [0.3, 0.45, 0.6, 0.75, 0.9].map((vg) => map(R.vds, (vd) => Id(vg, vd, p)));
    R.cur = map(R.vds, (vd) => Id(st.VG, vd, p));
    R.ws = linspace(5, 15, 41);
    R.ssW = map(R.ws, (w) => ssOf(params({ ...st, W: w })));
    R.diblW = map(R.ws, (w) => params({ ...st, W: w }).dibl * 1000);
    R.ionN = [1, 2, 3, 4, 5, 6, 7, 8].map((k) => Id(0.75, 0.75, params({ ...st, nfin: k })));
    R.Ls = linspace(10, 40, 61);
    R.roll = [5, 10, 15].map((w) => map(R.Ls, (L) => { const q = params({ ...st, W: w, L }); return q.Vt - q.dibl * st.VD; }));
    R.ion = Id(0.75, 0.75, p); R.ioff = Id(0, 0.75, p);
    return R;
  },
  render(R, api) {
    const { st, C } = api, p = R.p;
    api.status([
      ["I_D", fSI(R.id, "A"), ""], ["V_t (CC)", f(R.vt, 3) + " V", ""], ["SS", ssOf(p).toFixed(1) + " mV/dec", ssOf(p) > 80 ? "warn" : "good"],
      ["DIBL", (p.dibl * 1000).toFixed(0) + " mV/V", p.dibl > 0.1 ? "warn" : "good"], ["λ", p.lam.toFixed(2) + " nm", ""], ["I_on/I_off", (R.ion / R.ioff).toExponential(1), R.ion / R.ioff < 1e4 ? "warn" : "good"],
    ]);
    // fins drawn in the schematic
    const g = api.q(".fins");
    let h = "";
    const pitch = 200 / st.nfin;
    for (let k = 0; k < st.nfin; k++) { const x = 355 + pitch * k + pitch / 2 - 6; h += `<rect x="${x}" y="110" width="12" height="110" rx="2" fill="var(--m-si)" stroke="var(--edge)"/>`; }
    g.innerHTML = h;
    api.q(".fintxt").textContent = `${st.nfin} fin${st.nfin > 1 ? "s" : ""} · W_fin ${st.W} nm · L ${st.L} nm · W_eff ${(p.Weff / 1000).toFixed(3)} µm`;
    api.plot("tp1", { xmin: -0.2, xmax: 0.9, ylog: true, ymin: 1e-12, ymax: 1e-2, xlabel: "V_G (V)", ylabel: "I_D (A)",
      series: [...R.cmp.map((y) => ({ x: VGs, y, color: C.muted, w: 1, dash: [3, 3] })), { x: VGs, y: R.idg, color: C.ph, w: 2.2 }],
      vlines: [{ x: R.vt, color: C.ph, dash: [2, 3], label: "V_t" }], points: [{ x: st.VG, y: Math.max(R.id, 1e-12), color: C.ink }] });
    api.eqv("tp1", `λ = ${p.lam.toFixed(2)} nm, L/2λ = ${(st.L / (2 * p.lam)).toFixed(2)} → n = ${p.n.toFixed(3)}, SS = ${ssOf(p).toFixed(1)} mV/dec`);
    api.ro("tp1", [["I_D", fSI(R.id, "A")], ["I_off (V_G = 0)", fSI(R.ioff, "A")], ["V_t", f(R.vt, 3) + " V"]]);
    api.plot("tp2", { xmin: 0, xmax: 0.9, ymin: 0, xlabel: "V_D (V)", ylabel: "I_D (µA)", series: [...R.fam.map((y) => ({ x: R.vds, y: map(y, (v) => v * 1e6), color: C.muted, w: 1 })), { x: R.vds, y: map(R.cur, (v) => v * 1e6), color: C.rf, w: 2.2 }], points: [{ x: st.VD, y: R.id * 1e6, color: C.ink, label: "V_G = " + st.VG.toFixed(2) }] });
    api.ro("tp2", [["I_D", fSI(R.id, "A")], ["Per fin", fSI(R.id / st.nfin, "A")], ["Per µm W_eff", fSI(R.id / (p.Weff / 1000), "A")]]);
    api.plot("tp3", { xmin: 5, xmax: 15, xlabel: "fin width (nm)", ylabel: "SS (mV/dec) · DIBL (mV/V)", legend: true, series: [{ x: R.ws, y: R.ssW, color: C.dc, w: 2, label: "SS" }, { x: R.ws, y: R.diblW, color: C.rf, w: 2, label: "DIBL" }], hlines: [{ y: 60, color: C.muted, dash: [2, 3], label: "60 mV/dec limit" }], points: [{ x: st.W, y: ssOf(p), color: C.dc }, { x: st.W, y: p.dibl * 1000, color: C.rf }] });
    api.ro("tp3", [["SS", ssOf(p).toFixed(1) + " mV/dec"], ["DIBL", (p.dibl * 1000).toFixed(0) + " mV/V"], ["Roll-off", (0.55 * Math.exp(-st.L / (2 * p.lam)) * 1000).toFixed(0) + " mV"]]);
    const xs = [], ys = [];
    R.ionN.forEach((v, i) => { xs.push(i + 0.65, i + 0.65, i + 1.35, i + 1.35, NaN); ys.push(0, v * 1e6, v * 1e6, 0, NaN); });
    api.plot("tp4", { xmin: 0.4, xmax: 8.6, ymin: 0, xstep: 1, xlabel: "fins", ylabel: "I_on (µA)", series: [{ x: xs, y: ys, color: C.opt, w: 1.4, fill: C.opt, fillAlpha: 0.25 }], points: [{ x: st.nfin, y: R.ionN[st.nfin - 1] * 1e6, color: C.ink, label: "this layout" }] });
    api.ro("tp4", [["W_eff", (p.Weff / 1000).toFixed(3) + " µm"], ["I_on", fSI(R.ion, "A")], ["Gate capacitance ∝ fins", "×" + st.nfin]]);
    api.plot("a1", { xmin: 10, xmax: 40, xlabel: "gate length L (nm)", ylabel: "V_t (V)", legend: true,
      series: R.roll.map((y, i) => ({ x: R.Ls, y, color: [C.ok, C.ph, C.bad][i], w: i === 1 ? 1.6 : 1.6, label: ["W 5 nm", "W 10 nm", "W 15 nm"][i] })), points: [{ x: st.L, y: p.Vt - p.dibl * st.VD, color: C.ink, label: "this device" }] });
    api.ro("a1", [["V_t,lin at L", f(p.Vt, 3) + " V"], ["V_t,sat at L", f(p.Vt - p.dibl * st.VD, 3) + " V"]]);
  },
};

export default { atomic, bench };
