// 6T SRAM bitcell: two cross-coupled inverters (PU/PD) plus two access transistors (PG) on the bit lines.
import { buildGrid, solvePoisson, interp, ekvId, visDensity, fSI, f, MAT, Ut300 } from "../lib/physics.js";
import { map, linspace } from "../lib/plot.js";

// ---------- compact models (widths relative to the pass-gate) ----------
const N0 = { Vt: 0.35, n: 1.35, beta: 2e-4, Ut: Ut300, dibl: 0.06, lambda: 0.1, theta: 1.0 };
const P0 = { ...N0, beta: 0.9e-4 };
const nfet = (W, VGS, VDS, dvt = 0) => (VDS >= 0 ? ekvId(VGS, VDS, { ...N0, beta: N0.beta * W, Vt: N0.Vt + dvt }) : -ekvId(VGS - VDS, -VDS, { ...N0, beta: N0.beta * W, Vt: N0.Vt + dvt }));
const pfet = (W, VSG, VSD) => (VSD >= 0 ? ekvId(VSG, VSD, { ...P0, beta: P0.beta * W }) : 0);
function bisect(fn, lo, hi, iters = 32) { for (let k = 0; k < iters; k++) { const m = (lo + hi) / 2; if (fn(m) > 0) hi = m; else lo = m; } return (lo + hi) / 2; }
// one half-cell: output node voltage for input Vin, with the pass-gate to a bit line at Vbl (null = word line off)
function half(Vin, c, Vbl, dvt = 0) {
  const VDD = c.VDD, WL = c.WL * VDD;
  return bisect((V) => nfet(c.CR, Vin, V, dvt) - pfet(c.PR, VDD - Vin, VDD - V) + (Vbl === null ? 0 : nfet(1, WL - Math.min(V, Vbl), Math.abs(V - Vbl)) * Math.sign(V - Vbl)), 0, VDD);
}
// butterfly curves and static noise margin (largest square in the smaller lobe, Seevinck)
function butterfly(c, read) {
  const VDD = c.VDD, xs = linspace(0, VDD, 81);
  const A = map(xs, (x) => half(x, c, read ? VDD : null, c.dvt));   // inverter 1: QB = f1(Q)
  const B = map(xs, (y) => half(y, c, read ? VDD : null, 0));       // inverter 2: Q = f2(QB)
  // rotate by 45°: v = (y − x)/√2 runs monotonically along each (decreasing) curve, u = (x + y)/√2 is the diagonal.
  // The largest square in a lobe has its diagonal along u, so its side = max |u_A − u_B| / √2 at equal v.
  const r2 = Math.SQRT2, V = linspace(-VDD / r2, VDD / r2, 241);
  const rot = (px, py) => { const o = []; for (let i = 0; i < px.length; i++) o.push([(py[i] - px[i]) / r2, (px[i] + py[i]) / r2]); o.sort((a, b) => a[0] - b[0]); return [o.map((p) => p[0]), o.map((p) => p[1])]; };
  const [va, ua] = rot(xs, A), [vb, ub] = rot(B, xs);
  let best1 = { d: 0, v: 0, ua: 0, ub: 0 }, best2 = { d: 0, v: 0, ua: 0, ub: 0 };
  for (const v of V) {
    if (v < va[0] || v > va[va.length - 1] || v < vb[0] || v > vb[vb.length - 1]) continue;
    const a = interp(va, ua, v), b = interp(vb, ub, v), d = a - b;
    if (d > best1.d) best1 = { d, v, ua: a, ub: b }; if (-d > best2.d) best2 = { d: -d, v, ua: a, ub: b };
  }
  const sq = (bst) => { const x1 = (bst.ua - bst.v) / r2, y1 = (bst.ua + bst.v) / r2, x2 = (bst.ub - bst.v) / r2, y2 = (bst.ub + bst.v) / r2; return { x: [x1, x2, x2, x1, x1], y: [y1, y1, y2, y2, y1] }; };
  return { xs, A, B, snm: Math.min(best1.d, best2.d) / r2, sq1: sq(best1), sq2: sq(best2) };
}
// full cell with both bit lines; returns final Q, QB starting from the stored state
function settle(c, Vbl, Vblb, Qstart, loops = 30, init = null) {
  let Q = init ? init.Q : Qstart ? c.VDD : 0, QB = init ? init.QB : Qstart ? 0 : c.VDD;
  for (let k = 0; k < loops; k++) { Q = half(QB, { ...c }, c.WL > 0.05 ? Vbl : null, 0); QB = half(Q, c, c.WL > 0.05 ? Vblb : null, c.dvt); }
  return { Q, QB };
}
function writeMargin(c) { // highest BL voltage that still flips a stored '1' (BLB held at V_DD)
  return bisect((v) => (settle(c, v, c.VDD, 1).Q > c.VDD / 2 ? 1 : -1), 0, c.VDD, 12);
}

// ---------- atomic ----------
const TOX = 1.6;
function gateCut(VG) {
  const g = buildGrid([{ mat: "SiO2", t: TOX, dx: 0.25 }, { mat: "Si", t: 60, N: -8e17, dx: 0.5 }]);
  const s = solvePoisson(g, { left: { type: "gate", V: VG, wf: 4.05 }, right: { type: "ohmic", V: 0 } });
  let ns = 0; for (let i = 1; i < g.x.length; i++) if (g.x[i] > TOX) ns += s.n[i] * (g.x[i] - g.x[i - 1]) * 1e-7;
  return { g, s, ns, EcS: interp(s.x, s.Ec, TOX + 0.5) };
}
// surface conduction band along BL | PG | Q | PD | GND (natural-length barriers between n+ nodes)
function chain(nodes, gates, lam = 7) {
  const seg = 30, gl = 22, x = [], Ec = [], EF = [];
  let x0 = 0;
  for (let k = 0; k < nodes.length; k++) {
    for (let i = 0; i <= 20; i++) { x.push(x0 + (seg * i) / 20); Ec.push(-nodes[k] - 0.06); EF.push(-nodes[k]); }
    x0 += seg;
    if (k < gates.length) {
      const L = -nodes[k] - 0.06, R = -nodes[k + 1] - 0.06, M = gates[k], sh = Math.sinh(gl / lam);
      for (let i = 1; i < 30; i++) { const xp = (gl * i) / 30; x.push(x0 + xp); Ec.push(M + ((L - M) * Math.sinh((gl - xp) / lam)) / sh + ((R - M) * Math.sinh(xp / lam)) / sh); EF.push(-(nodes[k] + (nodes[k + 1] - nodes[k]) * xp / gl)); }
      x0 += gl;
    }
  }
  const m = MAT.Si, A = (a) => Float64Array.from(a);
  const n = Ec.map((e, i) => Math.min(1e20, m.Nc * Math.exp((EF[i] - e) / Ut300))), p = Ec.map((e, i) => m.Nv * Math.exp((e - m.Eg - EF[i]) / Ut300));
  const E = Ec.map((e, i) => { const a = Math.max(0, i - 1), b = Math.min(Ec.length - 1, i + 1); return ((Ec[b] - Ec[a]) / (x[b] - x[a])) * 1e7; });
  return { x: A(x), Ec: A(Ec), Ev: A(Ec.map((e) => e - m.Eg)), EFn: A(EF), EFp: A(EF), n: A(n), p: A(p), E: A(E), Nabs: A(x.map(() => 1e18)) };
}
const cellOf = (st) => ({ VDD: st.VDD, CR: 2, PR: 1, WL: st.WL / st.VDD, dvt: 0 });

const atomic = {
  intro: "Cross-section along the active area of one half of the cell: bit line contact → pass-gate (gate = word line) → storage node Q → pull-down (gate = the other node, QB) → ground. The bit is the voltage on Q. Reading opens the pass-gate and lets the bit line discharge through Q; that small current briefly lifts Q (read disturb). Not to scale.",
  controls: [
    { label: "Cell", color: "ph", items: [{ id: "bit", type: "seg", label: "Stored bit on Q", options: [[0, "Q = 0"], [1, "Q = 1"]], value: 0 }, { id: "VDD", label: "V_DD", min: 0.5, max: 1.1, step: 0.05, value: 0.9, fmt: (v) => v.toFixed(2) + " V" }] },
    { label: "Word line", color: "rf", items: [{ id: "WL", label: "V_WL", min: 0, max: 1.1, step: 0.01, value: 0.9, fmt: (v) => v.toFixed(2) + " V" }] },
    { label: "Bit line", color: "dc", items: [{ id: "BL", label: "V_BL", min: 0, max: 1.1, step: 0.01, value: 0.9, fmt: (v) => v.toFixed(2) + " V" }, { type: "note", text: "Read: BL precharged to V_DD. Write a 0: pull BL to 0 V." }] },
  ],
  presets: [{ label: "Hold (WL off)", set: { bit: 0, WL: 0, BL: 0.9, VDD: 0.9 } }, { label: "Read a 0", set: { bit: 0, WL: 0.9, BL: 0.9, VDD: 0.9 } }, { label: "Write 0 over a 1", set: { bit: 1, WL: 0.9, BL: 0, VDD: 0.9 } }, { label: "Read at low V_DD 0.5 V", set: { bit: 0, WL: 0.5, BL: 0.5, VDD: 0.5 } }],
  look: [
    "Read a 0: both gates are on, so electrons flow from ground through the pull-down and the pass-gate into the bit line. Q sits slightly above 0 V. The pull-down is made wider than the pass-gate so that this bump stays small.",
    "On the surface cut, the Q node is a small well between two barriers; its level is the stored voltage.",
    "Write: with Q = 1 and BL pulled to 0, the pass-gate drags Q down until the cross-coupled inverters flip. Watch QB change in the readouts.",
  ],
  world: { w: 220, h: 80 }, aspect: "11/4", lensAt: [90, 33],
  cuts: [{ id: "lat", label: "Surface: BL → Q → GND", a: [8, 32], b: [212, 32] }, { id: "pg", label: "Pass-gate gate → substrate", a: [62, 18], b: [62, 79] }],
  solve(st) {
    const c = cellOf(st);
    const Qs = st.WL > 0.05 ? settle(c, st.BL, st.VDD, +st.bit) : { Q: st.bit ? st.VDD : 0, QB: st.bit ? 0 : st.VDD };
    const pg = gateCut(st.WL - Math.min(Qs.Q, st.BL)), pd = gateCut(Qs.QB);
    const Ipg = st.WL > 0.05 ? nfet(1, st.WL - Math.min(Qs.Q, st.BL), Math.abs(st.BL - Qs.Q)) : 0;
    const lat = chain([st.BL, Qs.Q, 0], [gateCut(st.WL).EcS, pd.EcS]);
    return { ...Qs, pg, pd, Ipg, lat };
  },
  scene(S, st) {
    const dpg = visDensity(S.pg.ns / 3e-7, 14, 19.5), dpd = visDensity(S.pd.ns / 3e-7, 14, 19.5);
    const flow = S.Ipg > 1e-7 ? Math.min(40, 6 * Math.log10(S.Ipg * 1e9)) : 0;
    const dir = st.BL > S.Q ? -1 : 1; // electrons move from the lower-voltage side
    return {
      regions: [
        { x: 0, y: 32, w: 220, h: 48, mat: "si", dop: "p" },
        { x: 8, y: 32, w: 40, h: 10, mat: "si", dop: "n+" }, { x: 88, y: 32, w: 44, h: 10, mat: "si", dop: "n+" }, { x: 172, y: 32, w: 40, h: 10, mat: "si", dop: "n+" },
        { x: 48, y: 29, w: 40, h: 3, mat: "ox" }, { x: 48, y: 17, w: 40, h: 12, mat: "poly" },
        { x: 132, y: 29, w: 40, h: 3, mat: "ox" }, { x: 132, y: 17, w: 40, h: 12, mat: "poly" },
        { x: 22, y: 4, w: 12, h: 28, mat: "metal" }, { x: 104, y: 4, w: 12, h: 28, mat: "metal" }, { x: 186, y: 4, w: 12, h: 28, mat: "metal" },
      ],
      depl: [...(dpg < 0.3 ? [{ x: 48, y: 32, w: 40, h: 8 }] : []), ...(dpd < 0.3 ? [{ x: 132, y: 32, w: 40, h: 8 }] : [])],
      zones: [
        { id: "bl", type: "e", x: 8, y: 32, w: 40, h: 10, dens: 0.9 }, { id: "q", type: "e", x: 88, y: 32, w: 44, h: 10, dens: 0.9 }, { id: "gnd", type: "e", x: 172, y: 32, w: 40, h: 10, dens: 0.9 },
        { id: "pg", type: "e", x: 48, y: 32, w: 40, h: 2, dens: dpg, vx: flow * dir, jit: 0.3 },
        { id: "pd", type: "e", x: 132, y: 32, w: 40, h: 2, dens: dpd, vx: S.Q > 0.02 ? -flow : 0, jit: 0.3 },
        { id: "sub", type: "h", x: 0, y: 44, w: 220, h: 36, dens: 0.45 },
      ],
      labels: [{ x: 68, y: 23, text: "pass-gate", size: 9 }, { x: 152, y: 23, text: "pull-down", size: 9 }, { x: 110, y: 72, text: "p-well", size: 9, color: "muted" }],
      terminals: [{ x: 28, y: 6, text: `BL ${st.BL.toFixed(2)}` }, { x: 68, y: 10, text: `WL ${st.WL.toFixed(2)}` }, { x: 110, y: 6, text: `Q ${S.Q.toFixed(3)} V` }, { x: 152, y: 10, text: `QB ${S.QB.toFixed(2)}` }, { x: 192, y: 6, text: "GND" }],
    };
  },
  bands(S, st, cut) {
    if (cut === "lat") return { ...S.lat, regions: [{ x0: 0, x1: 30, label: "BL" }, { x0: 30, x1: 52, label: "PG" }, { x0: 52, x1: 82, label: "Q" }, { x0: 82, x1: 104, label: "PD" }, { x0: 104, x1: 134, label: "GND" }], xlabel: "position along the active area (nm, schematic)" };
    const { g, s } = gateCut(st.WL);
    return { x: s.x, Ec: s.Ec, Ev: s.Ev, EFn: s.EFn, EFp: s.EFp, n: s.n, p: s.p, E: s.E, Nabs: map(g.N, Math.abs), regions: [{ x0: 0, x1: TOX, label: "" }, { x0: TOX, x1: TOX + 60, label: "p-well" }], xlabel: "depth (nm)", clip: [-3, 3] };
  },
  readouts(S, st) {
    const flipped = (st.bit ? S.Q < st.VDD / 2 : S.Q > st.VDD / 2);
    return [["Q", S.Q.toFixed(3) + " V"], ["QB", S.QB.toFixed(3) + " V"], ["Pass-gate current", fSI(Math.abs(S.Ipg), "A")], ["Cell state", flipped ? "flipped (written)" : "holds its bit", flipped ? "warn" : "good"]];
  },
  foot: "Node voltages from DC solutions of the six EKV transistors (pull-down 2× and pull-up 1× the pass-gate width). Vertical cut: 1D Poisson under a gate on an 8×10¹⁷ p-well. Surface cut: n⁺ node levels joined by natural-length barriers whose heights come from the Poisson surface potential. Illustrative values.",
};

// ---------- bench ----------
const CBL = 25e-15; // bit-line capacitance (128 cells)
function readTransient(c) {
  const N = 900, dt = 1e-12, t = [], wl = [], bl = [], blb = [], q = [], qb = [];
  let Vbl = c.VDD, tsense = NaN, prev = { Q: 0, QB: c.VDD };
  for (let i = 0; i < N; i++) {
    const ti = i * dt, w = Math.max(0, Math.min(1, (ti - 40e-12) / 20e-12)) * c.WL;
    const cc = { ...c, WL: w };
    const st = w > 0.01 ? (prev = settle(cc, Vbl, c.VDD, 0, 3, prev)) : { Q: 0, QB: c.VDD }; // warm start: 3 relaxation steps per ps
    const I = w > 0.01 ? nfet(1, w * c.VDD - st.Q, Vbl - st.Q) : 0;
    Vbl -= (I * dt) / CBL;
    if (isNaN(tsense) && c.VDD - Vbl > 0.1) tsense = ti - 40e-12;
    t.push(ti * 1e12); wl.push(w * c.VDD); bl.push(Vbl); blb.push(c.VDD); q.push(st.Q); qb.push(st.QB);
  }
  const A = (a) => Float64Array.from(a);
  return { t: A(t), wl: A(wl), bl: A(bl), blb: A(blb), q: A(q), qb: A(qb), tsense };
}
const bench = {
  intro: "A row of the memory array: word-line driver, the cell, and bit lines going to a sense amplifier. Size the transistors and pick V_DD, then check the three things a cell must do: hold, be read without flipping, and be writable.",
  animated: true,
  controls: [
    { label: "Supply", color: "dc", items: [{ id: "VDD", label: "V_DD", min: 0.4, max: 1.1, step: 0.02, value: 0.8, fmt: (v) => v.toFixed(2) + " V" }] },
    { label: "Sizing (relative to pass-gate)", color: "ph", items: [{ id: "CR", label: "Cell ratio PD/PG", min: 1, max: 3, step: 0.1, value: 2, fmt: (v) => v.toFixed(1) }, { id: "PR", label: "Pull-up ratio PU/PG", min: 0.3, max: 2, step: 0.05, value: 0.8, fmt: (v) => v.toFixed(2) }] },
    { label: "Assist and variability", color: "rf", items: [{ id: "WL", label: "Word-line level (× V_DD)", min: 0.6, max: 1.2, step: 0.02, value: 1, fmt: (v) => (v * 100).toFixed(0) + " %" }, { id: "dvt", label: "V_t mismatch on one pull-down", min: -0.12, max: 0.12, step: 0.005, value: 0, fmt: (v) => f(v * 1000, 0) + " mV" }] },
  ],
  presets: [
    { label: "Balanced cell, 0.8 V", set: { VDD: 0.8, CR: 2, PR: 0.8, WL: 1, dvt: 0 } },
    { label: "Weak pull-down (CR 1): read upset", set: { CR: 1, PR: 0.8 } },
    { label: "Strong pull-up: hard to write", set: { PR: 2, CR: 2 } },
    { label: "Low voltage 0.45 V + mismatch", set: { VDD: 0.45, dvt: 0.08 } },
    { label: "Word-line underdrive 85 %", set: { WL: 0.85 } },
  ],
  schematic: {
    viewBox: "0 0 900 340",
    svg: `
  <path class="rf" d="M120,30 V310"/><text class="lb" x="120" y="24" text-anchor="middle">BL</text>
  <path class="rf" d="M780,30 V310"/><text class="lb" x="780" y="24" text-anchor="middle">BLB</text>
  <path class="ph wl" d="M60,170 H840" stroke="var(--ph)" stroke-width="2.4"/><text class="lb" x="40" y="174">WL</text>
  <rect class="dev" x="170" y="140" width="70" height="40" rx="4"/><text class="lb" x="205" y="165" text-anchor="middle">PG1</text>
  <rect class="dev" x="660" y="140" width="70" height="40" rx="4"/><text class="lb" x="695" y="165" text-anchor="middle">PG2</text>
  <path class="w" d="M120,160 H170 M240,160 H330 M730,160 H780 M570,160 H660"/>
  <rect class="dev" x="300" y="70" width="70" height="40" rx="4"/><text class="lb" x="335" y="95" text-anchor="middle">PU1</text>
  <rect class="dev" x="300" y="220" width="70" height="40" rx="4"/><text class="lb" x="335" y="245" text-anchor="middle">PD1</text>
  <rect class="dev" x="530" y="70" width="70" height="40" rx="4"/><text class="lb" x="565" y="95" text-anchor="middle">PU2</text>
  <rect class="dev" x="530" y="220" width="70" height="40" rx="4"/><text class="lb" x="565" y="245" text-anchor="middle">PD2</text>
  <path class="w" d="M335,110 V220 M565,110 V220 M335,160 H400 L500,240 H530 M565,160 H500 L400,240 H370"/>
  <path class="dc" d="M300,60 H600"/><text class="sub" x="450" y="54" text-anchor="middle">V_DD</text>
  <path class="w" d="M335,260 V290 H565 V260"/><text class="sub" x="450" y="304" text-anchor="middle">GND</text>
  <text class="lb qtxt" x="360" y="150">Q</text><text class="lb qbtxt" x="520" y="150" text-anchor="end">QB</text>
  <rect class="bx" x="380" y="315" width="140" height="22" rx="4"/><text class="sub" x="450" y="331" text-anchor="middle">sense amplifier (BL vs BLB)</text>`,
  },
  tps: [{ n: 1, x: 120, y: 120, label: "word line and bit line" }, { n: 2, x: 335, y: 160, label: "storage nodes" }, { n: 3, x: 450, y: 200, label: "butterfly" }, { n: 4, x: 780, y: 240, label: "write" }],
  sections: [{ k: "op", t: "Read operation", n: "Bit line precharged to V_DD, cell stores Q = 0." }, { k: "st", t: "Stability margins", n: "Hold, read and write." }],
  cards: [
    { id: "tp1", tp: 1, s: "op", d: "rf", dn: "array", t: "Word line and bit lines", x: "WL rises at 40 ps; BL discharges through the cell into its 25 fF capacitance while BLB stays high. The sense amplifier fires at 100 mV of split.", eq: "dV<sub>BL</sub>/dt = −I<sub>read</sub>/C<sub>BL</sub>,&nbsp; t<sub>sense</sub> = C<sub>BL</sub>·ΔV/I<sub>read</sub>" },
    { id: "tp2", tp: 2, s: "op", d: "ph", dn: "nodes", t: "Storage nodes during the read", x: "Q bumps up (read disturb) while the pass-gate and pull-down fight. If the bump crosses the other inverter's trip point, the cell flips.", eq: "I<sub>PG</sub>(V<sub>WL</sub> − V<sub>Q</sub>, V<sub>BL</sub> − V<sub>Q</sub>) = I<sub>PD</sub>(V<sub>QB</sub>, V<sub>Q</sub>)" },
    { id: "tp3", tp: 3, s: "st", d: "an", dn: "SNM", t: "Butterfly curves: hold and read", x: "The two inverter curves, one mirrored. Grey: hold (WL off). Coloured: read (WL on, BL at V_DD). The largest square in each lobe is the static noise margin.", eq: "SNM = side of the largest square inside the smaller lobe", h: "tall" },
    { id: "tp4", tp: 4, s: "st", d: "rf", dn: "write", t: "Write: Q vs bit-line voltage", x: "Cell storing Q = 1, WL on, BL lowered. Q drops and flips once BL is below the write trip point. Higher trip point = easier write.", eq: "write margin = V<sub>BL</sub> at which Q flips,&nbsp; needs I<sub>PG</sub> &gt; I<sub>PU</sub>" },
    { id: "a1", chip: "V_min", s: "st", d: "an", dn: "scaling", t: "Margins vs supply voltage", x: "Hold SNM, read SNM and write margin vs V_DD. The lowest V_DD where all stay above ~10 % of V_DD sets the array's V_min.", eq: "V<sub>min</sub>: min(SNM<sub>read</sub>, WM) ≥ 0.1·V<sub>DD</sub>" },
  ],
  foot: "Model: six EKV transistors (V_t = 0.35 V, n = 1.35), widths relative to the pass-gate, pMOS 0.45× nMOS strength, DC node solutions by bisection, bit-line capacitance 25 fF (128 cells). Mismatch is applied to one pull-down. Illustrative values.",
  sim(st) {
    const c = { VDD: st.VDD, CR: st.CR, PR: st.PR, WL: st.WL, dvt: st.dvt };
    const R = { hold: butterfly(c, false), read: butterfly(c, true), tr: readTransient(c) };
    R.wm = writeMargin(c);
    R.trip = bisect((v) => v - half(v, c, null, 0), 0, st.VDD);
    R.vbl = linspace(0, st.VDD, 31);
    R.qw = map(R.vbl, (v) => settle(c, v, st.VDD, 1).Q);
    R.vdd = linspace(0.4, 1.1, 8);
    R.mh = map(R.vdd, (v) => butterfly({ ...c, VDD: v }, false).snm * 1000);
    R.mr = map(R.vdd, (v) => butterfly({ ...c, VDD: v }, true).snm * 1000);
    R.mw = map(R.vdd, (v) => writeMargin({ ...c, VDD: v }) * 1000);
    const ok = R.vdd.findIndex((v, i) => Math.min(R.mr[i], R.mw[i]) >= 100 * v);
    R.vmin = ok < 0 ? NaN : R.vdd[ok];
    return R;
  },
  render(R, api) {
    const { st, C } = api, T = R.tr;
    const n = T.t.length, cur = (api.frame * 3) % n;
    const flipped = Math.max(...T.q) > st.VDD / 2;
    api.status([["Hold SNM", (R.hold.snm * 1000).toFixed(0) + " mV", ""], ["Read SNM", (R.read.snm * 1000).toFixed(0) + " mV", R.read.snm < 0.1 * st.VDD ? "warn" : "good"],
      ["Write margin", (R.wm * 1000).toFixed(0) + " mV", R.wm < 0.1 * st.VDD ? "warn" : "good"], ["Read time to 100 mV", isNaN(T.tsense) ? "> 860 ps" : (T.tsense * 1e12).toFixed(0) + " ps", ""],
      ["Read", flipped ? "destructive: cell flipped" : "safe", flipped ? "warn" : "good"], ["V_min estimate", isNaN(R.vmin) ? "> 1.1 V" : R.vmin.toFixed(2) + " V", ""]]);
    api.q(".qtxt").textContent = `Q ${T.q[cur].toFixed(2)}`; api.q(".qbtxt").textContent = `QB ${T.qb[cur].toFixed(2)}`;
    api.plot("tp1", { xmin: 0, xmax: T.t[n - 1], ymin: -0.05, ymax: st.VDD * 1.25, xlabel: "time (ps)", ylabel: "V (V)", legend: true, series: [{ x: T.t, y: T.wl, color: C.ph, w: 1.6, label: "WL" }, { x: T.t, y: T.blb, color: C.muted, w: 1.4, dash: [4, 3], label: "BLB" }, { x: T.t, y: T.bl, color: C.rf, w: 2.2, label: "BL" }], hlines: [{ y: st.VDD - 0.1, color: C.ok, dash: [2, 3], label: "sense" }], cursor: T.t[cur] });
    api.ro("tp1", [["BL at cursor", T.bl[cur].toFixed(3) + " V"], ["Read current", fSI(nfet(1, st.WL * st.VDD - T.q[n - 1], T.bl[n - 1] - T.q[n - 1]), "A")], ["t_sense", isNaN(T.tsense) ? "—" : (T.tsense * 1e12).toFixed(0) + " ps"]]);
    api.plot("tp2", { xmin: 0, xmax: T.t[n - 1], ymin: -0.05, ymax: st.VDD * 1.1, xlabel: "time (ps)", ylabel: "V (V)", legend: true, series: [{ x: T.t, y: T.q, color: C.ph, w: 2.2, label: "Q" }, { x: T.t, y: T.qb, color: C.dc, w: 2, label: "QB" }], hlines: [{ y: R.trip, color: C.bad, dash: [3, 3], label: "QB inverter trip point" }], cursor: T.t[cur] });
    api.ro("tp2", [["Peak Q bump", (Math.max(...T.q) * 1000).toFixed(0) + " mV", flipped ? "warn" : ""], ["Q at cursor", T.q[cur].toFixed(3) + " V"]]);
    const H = R.hold, D = R.read;
    api.plot("tp3", { xmin: 0, xmax: st.VDD, ymin: 0, ymax: st.VDD, xlabel: "Q (V)", ylabel: "QB (V)", series: [
      { x: H.xs, y: H.A, color: C.muted, w: 1.2 }, { x: H.B, y: H.xs, color: C.muted, w: 1.2 },
      { x: D.xs, y: D.A, color: C.ph, w: 2 }, { x: D.B, y: D.xs, color: C.rf, w: 2 },
      { x: D.sq1.x, y: D.sq1.y, color: C.ok, w: 1.6 }, { x: D.sq2.x, y: D.sq2.y, color: C.ok, w: 1.6 }] });
    api.eqv("tp3", `hold SNM = ${(H.snm * 1000).toFixed(0)} mV, read SNM = ${(D.snm * 1000).toFixed(0)} mV (green squares)`);
    api.ro("tp3", [["Hold SNM", (H.snm * 1000).toFixed(0) + " mV"], ["Read SNM", (D.snm * 1000).toFixed(0) + " mV", D.snm < 0.1 * st.VDD ? "warn" : "good"], ["Mismatch", f(st.dvt * 1000, 0) + " mV"]]);
    api.plot("tp4", { xmin: 0, xmax: st.VDD, ymin: 0, ymax: st.VDD, xlabel: "V_BL (V)", ylabel: "final Q (V)", series: [{ x: R.vbl, y: R.qw, color: C.rf, w: 2.2 }], vlines: [{ x: R.wm, color: C.ok, dash: [3, 3], label: "write trip" }] });
    api.ro("tp4", [["Write margin", (R.wm * 1000).toFixed(0) + " mV", R.wm < 0.1 * st.VDD ? "warn" : "good"], ["PU/PG", st.PR.toFixed(2)]]);
    api.plot("a1", { xmin: 0.4, xmax: 1.1, ymin: 0, xlabel: "V_DD (V)", ylabel: "margin (mV)", legend: true, series: [{ x: R.vdd, y: R.mh, color: C.muted, w: 1.6, label: "hold SNM" }, { x: R.vdd, y: R.mr, color: C.ph, w: 2, label: "read SNM" }, { x: R.vdd, y: R.mw, color: C.rf, w: 2, label: "write margin" }, { x: R.vdd, y: map(R.vdd, (v) => 100 * v), color: C.bad, w: 1, dash: [3, 3], label: "10 % V_DD" }], vlines: [{ x: st.VDD, color: C.ink, dash: [2, 3] }] });
    api.ro("a1", [["V_min", isNaN(R.vmin) ? "> 1.1 V" : R.vmin.toFixed(2) + " V"]]);
  },
};

export default { atomic, bench };
