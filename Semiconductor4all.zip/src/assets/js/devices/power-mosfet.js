// Trench power MOSFET (80 V class): vertical n+/p-body/n- drift/n+ substrate with a trench gate.
import { buildGrid, solvePoisson, depletedSpans, interp, ekvId, visDensity, fSI, f, MAT, q, eps0 } from "../lib/physics.js";
import { map, linspace, logspace } from "../lib/plot.js";

// ---------- atomic ----------
const L_SRC = 300, L_BODY = 1000, L_DRIFT = 5000, L_SUB = 500;
const N_BODY = 2e17, N_DRIFT = 5e15;
const DEPTHS = [0, L_SRC, L_SRC + L_BODY, L_SRC + L_BODY + L_DRIFT, L_SRC + L_BODY + L_DRIFT + L_SUB];
const YW = [8, 16, 36, 100, 114];  // world y of each layer boundary
const d2y = (d) => { for (let k = 0; k < 4; k++) if (d <= DEPTHS[k + 1]) return YW[k] + (YW[k + 1] - YW[k]) * (d - DEPTHS[k]) / (DEPTHS[k + 1] - DEPTHS[k]); return YW[4]; };
const ECRIT = 3.2e5; // V/cm, avalanche onset (approx. for 5e15 cm⁻³)

function verticalCut(VDS) {
  const g = buildGrid([
    { mat: "Si", t: L_SRC, N: 1e20, dx: 10, phin: 0, phip: 0 },
    { mat: "Si", t: L_BODY, N: -N_BODY, dx: 5, phin: 0, phip: 0 },
    { mat: "Si", t: L_DRIFT, N: N_DRIFT, dx: 12, phin: VDS, phip: 0 },
    { mat: "Si", t: L_SUB, N: 1e19, dx: 12, phin: VDS, phip: 0 },
  ]);
  return { g, s: solvePoisson(g, { left: { type: "ohmic", V: 0 }, right: { type: "ohmic", V: VDS } }) };
}
const TOXG = 50;
function mosCut(VGS) {
  const g = buildGrid([{ mat: "SiO2", t: TOXG, dx: 2 }, { mat: "Si", t: 600, N: -N_BODY, dx: 1.5 }]);
  const s = solvePoisson(g, { left: { type: "gate", V: VGS, wf: 4.05 }, right: { type: "ohmic", V: 0 } });
  let ns = 0;
  for (let i = 1; i < g.x.length; i++) if (g.x[i] > TOXG) ns += s.n[i] * (g.x[i] - g.x[i - 1]) * 1e-7;
  return { g, s, ns };
}

const atomic = {
  intro: "Half-pitch cross-section of a trench MOSFET. Current flows vertically: from the source at the top, down a channel along the trench sidewall, through the lightly doped drift region, to the drain on the back. The drift region is what blocks the voltage when the device is off. Not to scale.",
  controls: [
    { label: "Gate", color: "ph", items: [{ id: "VGS", label: "Gate–source voltage V_GS", min: 0, max: 10, step: 0.1, value: 0, fmt: (v) => v.toFixed(1) + " V" }] },
    { label: "Drain", color: "rf", items: [{ id: "VDS", label: "Drain–source voltage V_DS", min: 0, max: 100, step: 1, value: 40, fmt: (v) => v.toFixed(0) + " V" }, { type: "note", text: "Avalanche starts when the peak field reaches ≈ 3×10⁵ V/cm." }] },
  ],
  presets: [
    { label: "Blocking 40 V", set: { VGS: 0, VDS: 40 } }, { label: "Near breakdown, 90 V", set: { VGS: 0, VDS: 90 } },
    { label: "Fully on: 10 V gate, 0.2 V drain", set: { VGS: 10, VDS: 0.2 } }, { label: "At threshold", set: { VGS: 3.3, VDS: 5 } },
  ],
  look: [
    "Blocking: raise V_DS to 90 V. The depletion region spreads almost entirely into the lightly doped drift layer, and the field plot becomes a triangle whose peak sits at the body/drift junction.",
    "Turn the gate on (10 V) with V_DS low: on the gate-oxide cut the bands bend down at the sidewall and an electron channel forms across the p-body.",
    "Lens on the drift region: few dopants (5×10¹⁵ cm⁻³) means few electrons, which is why the drift region dominates the on-resistance.",
  ],
  world: { w: 160, h: 120 }, aspect: "4/3", lensAt: [40, 60],
  cuts: [{ id: "vert", label: "Vertical: source → drain", a: [35, 8], b: [35, 114] }, { id: "mos", label: "Gate oxide → p-body", a: [78, 26], b: [40, 26] }],
  solve(st) {
    const V = verticalCut(st.VDS), M = mosCut(st.VGS);
    let Emax = 0; for (const e of V.s.E) Emax = Math.max(Emax, Math.abs(e));
    const p = devParams(25);
    const id = idDC(st.VGS, st.VDS, p);
    return { V, M, Emax, spans: depletedSpans(V.g, V.s, 0.5), id };
  },
  scene(S, st) {
    const span = S.spans.find((sp) => sp[0] < L_SRC + L_BODY + 50 && sp[1] > L_SRC + L_BODY) || [L_SRC + L_BODY, L_SRC + L_BODY];
    const yt = d2y(span[0]), yb = d2y(span[1]);
    const chD = visDensity(S.M.ns / 5e-6, 13, 19.5);
    const flow = S.id > 1e-3 ? Math.min(40, 6 * Math.log10(S.id * 1e3 + 1)) : 0;
    const zones = [];
    for (const [x0, x1, side] of [[2, 66, "L"], [94, 158, "R"]]) {
      zones.push({ id: "src" + side, type: "e", x: x0, y: 8, w: x1 - x0, h: 8, dens: 0.95 });
      zones.push({ id: "body" + side, type: "h", x: x0, y: 16, w: x1 - x0, h: Math.max(0.5, yt - 16), dens: 0.75 });
      zones.push({ id: "drift" + side, type: "e", x: x0, y: yb, w: x1 - x0, h: Math.max(0.5, 100 - yb), dens: 0.42, vy: flow * 0.8 });
    }
    zones.push({ id: "drift-mid", type: "e", x: 66, y: Math.max(yb, 50), w: 28, h: Math.max(0.5, 100 - Math.max(yb, 50)), dens: 0.42, vy: flow * 0.8 });
    zones.push({ id: "sub", type: "e", x: 2, y: 100, w: 156, h: 14, dens: 0.95, vy: flow * 0.3 });
    if (chD > 0.05) {
      zones.push({ id: "chL", type: "e", x: 66, y: 16, w: 2.5, h: 20, dens: chD, vy: flow, jit: 0.6, max: 40, px: 30 });
      zones.push({ id: "chR", type: "e", x: 91.5, y: 16, w: 2.5, h: 20, dens: chD, vy: flow, jit: 0.6, max: 40, px: 30 });
      zones.push({ id: "acc", type: "e", x: 66, y: 36, w: 28, h: 14, dens: chD * 0.5, vy: flow, jit: 0.2 });
    }
    const depl = yb - yt > 0.4 ? [{ x: 2, y: yt, w: 64, h: yb - yt }, { x: 94, y: yt, w: 64, h: yb - yt }, ...(yb > 50 ? [{ x: 66, y: 50, w: 28, h: yb - 50 }] : [])] : [];
    const yj = YW[2];
    const ions = yb - yt > 0.4 ? [{ x: 2, y: yt, w: 64, h: Math.max(0, yj - yt), sign: -1 }, { x: 94, y: yt, w: 64, h: Math.max(0, yj - yt), sign: -1 },
      { x: 2, y: yj, w: 64, h: yb - yj, sign: 1, dens: 0.25 }, { x: 94, y: yj, w: 64, h: yb - yj, sign: 1, dens: 0.25 }] : [];
    const arrows = flow > 0 ? [{ x1: 60, y1: 12, x2: 60, y2: 30, color: "e", label: "e⁻" }, { x1: 80, y1: 60, x2: 80, y2: 92, color: "e", label: "e⁻ to drain" }] : [];
    if (S.Emax > ECRIT * 0.9) arrows.push({ x1: 30, y1: yj + 6, x2: 30, y2: yj - 2, color: "bad", label: "avalanche!" });
    return {
      regions: [
        { x: 0, y: 114, w: 160, h: 6, mat: "metal" },
        { x: 0, y: 100, w: 160, h: 14, mat: "si", dop: "n+" },
        { x: 0, y: 36, w: 160, h: 64, mat: "si", dop: "n" },
        { x: 0, y: 16, w: 66, h: 20, mat: "si", dop: "p" }, { x: 94, y: 16, w: 66, h: 20, mat: "si", dop: "p" },
        { x: 0, y: 8, w: 66, h: 8, mat: "si", dop: "n+" }, { x: 94, y: 8, w: 66, h: 8, mat: "si", dop: "n+" },
        { x: 66, y: 8, w: 28, h: 44, mat: "ox" }, { x: 70, y: 10, w: 20, h: 38, mat: "poly" },
        { x: 0, y: 0, w: 160, h: 8, mat: "metal" },
      ],
      depl, ions, zones, arrows,
      labels: [
        { x: 80, y: 30, text: "gate", size: 10 }, { x: 20, y: 12, text: "n⁺", bold: true }, { x: 20, y: 22, text: "p-body", size: 10 },
        { x: 130, y: 70, text: "n⁻ drift (5×10¹⁵)", size: 10 }, { x: 130, y: 107, text: "n⁺ substrate", size: 10 },
      ],
      terminals: [{ x: 120, y: 4, text: "S 0 V" }, { x: 80, y: 4, text: `G ${st.VGS.toFixed(1)} V` }, { x: 120, y: 117, text: `D ${st.VDS.toFixed(0)} V` }],
    };
  },
  bands(S, st, cut) {
    if (cut === "mos") {
      const { g, s } = S.M;
      return { x: s.x, Ec: s.Ec, Ev: s.Ev, EFn: s.EFn, EFp: s.EFp, n: s.n, p: s.p, E: s.E, Nabs: map(g.N, Math.abs), regions: [{ x0: 0, x1: TOXG, label: "gate oxide" }, { x0: TOXG, x1: TOXG + 600, label: "p-body" }], xlabel: "distance from trench gate (nm)", clip: [-6, 6] };
    }
    const { g, s } = S.V;
    const um = map(s.x, (v) => v / 1000);
    return { x: um, Ec: s.Ec, Ev: s.Ev, EFn: s.EFn, EFp: s.EFp, n: s.n, p: s.p, E: s.E, Nabs: map(g.N, Math.abs),
      regions: [{ x0: 0, x1: 0.3, label: "n⁺" }, { x0: 0.3, x1: 1.3, label: "p-body" }, { x0: 1.3, x1: 6.3, label: "n⁻ drift" }, { x0: 6.3, x1: 6.8, label: "n⁺" }], xlabel: "depth (µm)" };
  },
  readouts(S, st) {
    const span = S.spans.find((sp) => sp[0] < L_SRC + L_BODY + 50 && sp[1] > L_SRC + L_BODY);
    return [["Peak field", (S.Emax / 1e5).toFixed(2) + "×10⁵ V/cm", S.Emax > ECRIT ? "warn" : S.Emax > 0.8 * ECRIT ? "" : "good"],
      ["Depletion into drift", span ? ((span[1] - L_SRC - L_BODY) / 1000).toFixed(2) + " µm" : "—"],
      ["Channel electrons", S.M.ns.toExponential(1) + " cm⁻²"], ["I_D (model)", fSI(S.id, "A")]];
  },
  foot: "Vertical 1D Poisson through the body (n⁺ 10²⁰ | p-body 2×10¹⁷ | n⁻ drift 5×10¹⁵, 5 µm | n⁺ 10¹⁹), quasi-Fermi levels at the contacts. Gate cut: 50 nm trench oxide on the p-body with an n⁺-poly gate. Avalanche is flagged, not modelled. Illustrative values.",
};

// ---------- compact model ----------
function devParams(Tj) {
  const k = Math.pow((Tj + 273.15) / 300, 2.3);
  return { Vt: 3.2 - 0.005 * (Tj - 25), n: 1.4, beta: 55 / Math.pow((Tj + 273.15) / 300, 1.5), Ut: 0.0259 * (Tj + 273.15) / 300, theta: 0.06, lambda: 0.002, Rd: 0.0042 * k, Rs: 0.0008 * k };
}
function idDC(VGS, VDS, p) { // channel in series with drift + substrate resistance (quasi-saturation)
  if (VDS <= 0) return 0;
  let lo = 0, hi = Math.min(VDS / (p.Rd + p.Rs), 2000);
  for (let k = 0; k < 60; k++) {
    const m = (lo + hi) / 2;
    const ich = ekvId(VGS - m * p.Rs, VDS - m * (p.Rd + p.Rs), p);
    if (ich > m) lo = m; else hi = m;
  }
  return (lo + hi) / 2;
}
const ronAt = (VGS, p) => { const v = 0.1; return v / Math.max(idDC(VGS, v, p), 1e-9); };
const CGS = 4.2e-9, CGD0 = 0.9e-9, CDS0 = 2.2e-9;
const Cgd = (v) => CGD0 / Math.sqrt(1 + Math.max(v, 0) / 0.8);
function vplat(IL, p) { let lo = p.Vt - 0.5, hi = 15; for (let k = 0; k < 50; k++) { const m = (lo + hi) / 2; if (ekvId(m, 40, p) > IL) hi = m; else lo = m; } return (lo + hi) / 2; }

function switching(st) {
  const p = devParams(st.Tj);
  const Ron = ronAt(st.Vdrv, p), Vpl = vplat(st.IL, p);
  const dt = 0.25e-9, out = { t: [], vgs: [], vds: [], id: [], qg: [] };
  let t = 0, vgs = 0, vds = st.Vbus, id = 0, qg = 0, Eon = 0, Eoff = 0;
  const push = () => { out.t.push(t * 1e9); out.vgs.push(vgs); out.vds.push(vds); out.id.push(id); out.qg.push(qg * 1e9); };
  // turn-on
  // run each edge until the gate has settled, then 30 % longer, so the time axis fits the transition
  let settle = 0;
  while (t < 3e-6 && (settle === 0 || t < settle * 1.3)) {
    if (!settle && vgs > 0.985 * st.Vdrv) settle = t;
    const ig = (st.Vdrv - vgs) / st.Rg;
    const isat = ekvId(vgs, st.Vbus, p);
    if (id < st.IL - 1e-6 && vds >= st.Vbus - 1e-9) { // current rise, drain clamped at V_bus by the freewheeling diode
      vgs += ig * dt / (CGS + Cgd(vds)); id = Math.min(st.IL, isat);
    } else if (vds > st.IL * Ron * 1.02) { // Miller plateau: gate current discharges C_gd
      id = st.IL; vds = Math.max(st.IL * Ron, vds - ig * dt / Cgd(vds)); vgs = Math.max(vgs, Vpl);
    } else { vgs += ig * dt / (CGS + Cgd(vds)); id = st.IL; vds = st.IL * ronAt(Math.max(vgs, p.Vt + 0.5), p); }
    qg += ig * dt; Eon += vds * id * dt; t += dt; push();
  }
  // turn-off
  const t0 = t;
  let settle2 = 0;
  while (t - t0 < 3e-6 && (settle2 === 0 || t - t0 < settle2 * 1.3)) {
    if (!settle2 && vgs < 0.015 * st.Vdrv) settle2 = t - t0;
    const ig = (0 - vgs) / st.Rg; // negative
    const isat = ekvId(vgs, st.Vbus, p);
    if (vgs > Vpl + 1e-3 && vds < st.Vbus - 1e-6 && vds <= st.IL * Ron * 1.05) { vgs += ig * dt / (CGS + Cgd(vds)); vds = st.IL * ronAt(Math.max(vgs, p.Vt + 0.5), p); id = st.IL; }
    else if (vds < st.Vbus - 1e-6) { vgs = Math.min(vgs, Vpl); id = st.IL; vds = Math.min(st.Vbus, vds - ig * dt / Cgd(vds)); }
    else { vgs += ig * dt / (CGS + Cgd(vds)); id = Math.min(st.IL, isat); vds = st.Vbus; }
    qg += ig * dt; Eoff += vds * id * dt; t += dt; push();
  }
  return { ...out, Eon, Eoff, Ron, Vpl, tOff: t0 * 1e9, nOn: out.t.findIndex((x) => x >= t0 * 1e9) };
}

// drift-region field at blocking voltage (abrupt p⁺/n⁻, punch-through allowed)
function driftField(V) {
  const es = MAT.Si.eps * eps0, a = q * N_DRIFT / es; // V/cm²
  const Wd = L_DRIFT * 1e-7;
  let W = Math.sqrt(2 * V / a), Emax, pt = false;
  if (W <= Wd) Emax = a * W;
  else { pt = true; W = Wd; Emax = V / Wd + a * Wd / 2; }
  const y = linspace(0, L_DRIFT / 1000, 101);
  const E = map(y, (yy) => { const yc = yy * 1e-4; return yc > W ? 0 : Math.max(0, Emax - a * yc); });
  return { y, E, Emax, W: W * 1e4, pt };
}

const bench = {
  intro: "A gate driver switches the MOSFET in a clamped inductive circuit (a buck-converter leg): the load inductor holds the current constant, a freewheeling diode clamps the drain to the bus. This is the standard double-pulse test.",
  animated: true,
  controls: [
    { label: "Bus and load", color: "rf", items: [{ id: "Vbus", label: "Bus voltage V_bus", min: 12, max: 80, step: 1, value: 48, fmt: (v) => v + " V" }, { id: "IL", label: "Load current I_L", min: 5, max: 100, step: 1, value: 40, fmt: (v) => v + " A" }] },
    { label: "Gate driver (TP1)", color: "ph", items: [{ id: "Vdrv", label: "Drive level", min: 6, max: 12, step: 0.5, value: 10, fmt: (v) => v.toFixed(1) + " V" }, { id: "Rg", label: "Gate resistance R_g", min: 0.5, max: 20, step: 0.5, value: 4, fmt: (v) => v.toFixed(1) + " Ω" }] },
    { label: "Operation", color: "heat", items: [{ id: "fsw", label: "Switching frequency", min: 10, max: 1000, step: 10, value: 200, fmt: (v) => v + " kHz" }, { id: "Tj", label: "Junction temperature", min: 25, max: 175, step: 5, value: 100, fmt: (v) => v + " °C" }] },
  ],
  presets: [
    { label: "48 V, 40 A, R_g 4 Ω", set: { Vbus: 48, IL: 40, Vdrv: 10, Rg: 4, fsw: 200, Tj: 100 } },
    { label: "Slow gate: R_g 20 Ω", set: { Vbus: 48, IL: 40, Vdrv: 10, Rg: 20, fsw: 200, Tj: 100 } },
    { label: "Weak drive: 6 V", set: { Vbus: 48, IL: 80, Vdrv: 6, Rg: 4, fsw: 200, Tj: 100 } },
    { label: "1 MHz switching", set: { Vbus: 48, IL: 30, Vdrv: 10, Rg: 2, fsw: 1000, Tj: 100 } },
  ],
  schematic: {
    viewBox: "0 0 900 340",
    svg: `
  <rect class="bx" x="20" y="20" width="120" height="56" rx="5"/><text class="lb" x="80" y="44" text-anchor="middle">Bus supply</text><text class="sub" x="80" y="63" text-anchor="middle">V_bus</text>
  <path class="dc" d="M140,48 H560 V80"/>
  <rect class="bx" x="520" y="80" width="80" height="44" rx="5"/><text class="lb" x="560" y="107" text-anchor="middle">Diode</text>
  <path class="dc" d="M560,124 V160 H700"/>
  <rect class="bx" x="700" y="132" width="150" height="56" rx="5"/><text class="lb" x="775" y="156" text-anchor="middle">Load inductor</text><text class="sub" x="775" y="175" text-anchor="middle">holds I_L</text>
  <path class="dc" d="M775,132 V48 H560"/>
  <path class="w" d="M560,160 V200"/>
  <rect class="dev" x="500" y="200" width="120" height="76" rx="6"/><text class="lb" x="560" y="232" text-anchor="middle">Trench MOSFET</text><text class="sub" x="560" y="252" text-anchor="middle">80 V class</text>
  <path class="w" d="M560,276 V300 H540 M545,306 H575 M552,312 H568"/>
  <rect class="bx" x="40" y="210" width="140" height="56" rx="5"/><text class="lb" x="110" y="234" text-anchor="middle">Gate driver</text><text class="sub" x="110" y="253" text-anchor="middle">0 → V_drv</text>
  <rect class="bx chip" x="260" y="222" width="80" height="32" rx="4"/><text class="lb" x="300" y="243" text-anchor="middle">R_g</text>
  <path class="mix" d="M180,238 H260 M340,238 H500"/>
  <rect class="bx" x="660" y="250" width="170" height="56" rx="5"/><text class="lb" x="745" y="274" text-anchor="middle">Scope + current probe</text><text class="sub" x="745" y="293" text-anchor="middle">V_DS, I_D</text>
  <path class="rf" d="M620,240 H660 V250" stroke-dasharray="4 3"/>
  <text class="cap" x="20" y="320">Clamped inductive switching: I_L is constant during each transition.</text>`,
  },
  tps: [{ n: 1, x: 420, y: 238, label: "gate voltage" }, { n: 2, x: 560, y: 180, label: "drain" }, { n: 3, x: 640, y: 215, label: "device DC curves" }, { n: 4, x: 470, y: 280, label: "drift region" }, { n: 5, x: 760, y: 220, label: "losses" }],
  sections: [{ k: "sw", t: "Switching waveforms", n: "One turn-on and one turn-off of the double-pulse test." }, { k: "dev", t: "Inside the device", n: "DC behaviour, blocking field and the limits of silicon." }],
  cards: [
    { id: "tp1", tp: 1, s: "sw", d: "ph", dn: "gate", t: "Gate voltage V_GS(t)", x: "Charging through R_g, then the Miller plateau (flat part) while the drain voltage swings, then the rest of the charge.", eq: "I<sub>G</sub> = (V<sub>drv</sub> − V<sub>GS</sub>)/R<sub>g</sub>,&nbsp; plateau: V<sub>GS</sub> = V<sub>pl</sub> where I<sub>D</sub>(V<sub>pl</sub>) = I<sub>L</sub><br>dV<sub>DS</sub>/dt = −I<sub>G</sub>/C<sub>gd</sub>(V<sub>DS</sub>)" },
    { id: "tp2", tp: 2, s: "sw", d: "rf", dn: "drain", t: "Drain voltage and current", x: "Top: V_DS. Bottom: I_D. Where both are high at the same time, energy is lost.", eq: "E<sub>on/off</sub> = ∫ V<sub>DS</sub>·I<sub>D</sub> dt", kind: "dual" },
    { id: "a3", chip: "Q_G", s: "sw", d: "an", dn: "gate charge", t: "Gate charge curve", x: "V_GS vs charge delivered: the flat step is the Miller charge Q_gd.", eq: "Q<sub>G</sub> = ∫ I<sub>G</sub> dt,&nbsp; driver power = Q<sub>G</sub>·V<sub>drv</sub>·f<sub>sw</sub>" },
    { id: "tp3", tp: 3, s: "dev", d: "an", dn: "DC", t: "Output characteristics", x: "I_D vs V_DS for V_GS = 4…10 V. At high current the drift resistance bends the curves (quasi-saturation). Marker: on-state operating point.", eq: "I<sub>D</sub> = I<sub>ch</sub>(V<sub>GS</sub>, V<sub>DS</sub> − I<sub>D</sub>R<sub>drift</sub>),&nbsp; R<sub>on</sub> = R<sub>ch</sub> + R<sub>drift</sub> + R<sub>sub</sub>" },
    { id: "tp4", tp: 4, s: "dev", d: "dc", dn: "blocking", t: "Drift region: field when blocking V_bus", x: "Triangular field profile from the body junction into the drift layer. If it reaches the substrate the profile becomes a trapezoid (punch-through).", eq: "E(y) = E<sub>max</sub> − qN<sub>D</sub>y/ε,&nbsp; V = ∫E dy,&nbsp; avalanche when E<sub>max</sub> ≈ E<sub>crit</sub>" },
    { id: "tp5", tp: 5, s: "dev", d: "rf", dn: "losses", t: "Power loss vs switching frequency", x: "Conduction loss is flat, switching loss grows with f_sw. The crossover sets the practical frequency.", eq: "P = I<sub>L</sub>²R<sub>on</sub>·D + (E<sub>on</sub> + E<sub>off</sub>)·f<sub>sw</sub> + Q<sub>G</sub>V<sub>drv</sub>f<sub>sw</sub>,&nbsp; D = 0.5" },
    { id: "a1", chip: "R–BV", s: "dev", d: "an", dn: "limits", t: "Specific on-resistance vs breakdown", x: "The drift region sets a hard trade-off: R_on,sp ∝ BV^2.5 for silicon. SiC (10× higher critical field) and superjunction devices beat the silicon line.", eq: "R<sub>on,sp</sub> = 4BV²/(εµE<sub>c</sub>³)  ≈ 5.9×10⁻⁹·BV<sup>2.5</sup> Ω·cm² (Si)" },
  ],
  foot: "Model: EKV channel (V_t = 3.2 V, n = 1.4) in series with drift and substrate resistance (R_on ≈ 6 mΩ at 10 V, 25 °C, ∝ T^2.3); C_gs = 4.2 nF, C_gd = 0.9 nF/√(1+V/0.8), ideal diode and inductor, no stray inductance (no ringing). Drift layer 5 µm at 5×10¹⁵ cm⁻³. Illustrative values.",
  sim(st) {
    const R = { p: devParams(st.Tj) };
    R.sw = switching(st);
    R.vds = linspace(0, 3, 121);
    R.fam = [4, 5, 6, 8, 10].map((vg) => ({ vg, y: map(R.vds, (v) => idDC(vg, v, R.p)) }));
    R.df = driftField(st.Vbus);
    R.qgTot = R.sw.qg[R.sw.nOn - 1];
    R.fr = logspace(1, 3.3, 60);
    const Pc = st.IL * st.IL * R.sw.Ron * 0.5;
    R.Pc = Pc;
    R.Psw = map(R.fr, (fk) => (R.sw.Eon + R.sw.Eoff) * fk * 1e3);
    R.Pg = map(R.fr, (fk) => R.qgTot * 1e-9 * st.Vdrv * fk * 1e3);
    R.Ptot = map(R.fr, (fk, i) => Pc + R.Psw[i] + R.Pg[i]);
    R.Pnow = Pc + (R.sw.Eon + R.sw.Eoff) * st.fsw * 1e3 + R.qgTot * 1e-9 * st.Vdrv * st.fsw * 1e3;
    R.bv = linspace(20, 1200, 120);
    return R;
  },
  render(R, api) {
    const { st, C } = api, S = R.sw;
    const n = S.t.length, cur = (api.frame * 4) % n, tc = S.t[cur];
    const bd = R.df.Emax > ECRIT;
    api.status([
      ["R_on at V_drv", (S.Ron * 1000).toFixed(2) + " mΩ", ""], ["Miller plateau", S.Vpl.toFixed(2) + " V", st.Vdrv - S.Vpl < 2 ? "warn" : ""],
      ["E_on + E_off", ((S.Eon + S.Eoff) * 1e6).toFixed(1) + " µJ", ""], ["Total loss", R.Pnow.toFixed(1) + " W", R.Pnow > 30 ? "warn" : ""],
      ["Blocking field", (R.df.Emax / 1e5).toFixed(2) + "×10⁵ V/cm", bd ? "warn" : "good"],
      ["Efficiency (leg)", (100 * (1 - R.Pnow / (st.Vbus * st.IL * 0.5))).toFixed(1) + " %", ""],
    ]);
    api.q(".dev")?.classList.toggle("fault", bd);
    const tt = Float64Array.from(S.t);
    api.plot("tp1", { xmin: 0, xmax: tt[n - 1], ymin: -0.5, ymax: st.Vdrv + 1, xlabel: "time (ns)", ylabel: "V_GS (V)", series: [{ x: tt, y: Float64Array.from(S.vgs), color: C.ph, w: 2 }], hlines: [{ y: S.Vpl, color: C.muted, dash: [3, 3], label: "plateau" }, { y: R.p.Vt, color: C.muted, dash: [1, 3], label: "V_t" }], vlines: [{ x: S.tOff, color: C.edge, dash: [2, 3], label: "turn-off" }], cursor: tc });
    api.eqv("tp1", `V_pl = ${S.Vpl.toFixed(2)} V → I_G on the plateau = ${((st.Vdrv - S.Vpl) / st.Rg).toFixed(2)} A (on), ${(S.Vpl / st.Rg).toFixed(2)} A (off)`);
    api.ro("tp1", [["V_GS at cursor", S.vgs[cur].toFixed(2) + " V"], ["Q_G total", R.qgTot.toFixed(1) + " nC"], ["Driver power", (R.qgTot * 1e-9 * st.Vdrv * st.fsw * 1e3).toFixed(2) + " W"]]);
    api.plot("tp2", { xmin: 0, xmax: tt[n - 1], ymin: -2, ymax: st.Vbus * 1.15, xlabel: "time (ns)", ylabel: "V_DS (V)", series: [{ x: tt, y: Float64Array.from(S.vds), color: C.rf, w: 2 }], cursor: tc }, 0);
    api.plot("tp2", { xmin: 0, xmax: tt[n - 1], ymin: -2, ymax: st.IL * 1.15, ylabel: "I_D (A)", series: [{ x: tt, y: Float64Array.from(S.id), color: C.opt, w: 2, fill: C.opt }], cursor: tc }, 1);
    api.eqv("tp2", `E_on = ${(S.Eon * 1e6).toFixed(1)} µJ, E_off = ${(S.Eoff * 1e6).toFixed(1)} µJ`);
    api.ro("tp2", [["V_DS at cursor", S.vds[cur].toFixed(2) + " V"], ["I_D at cursor", S.id[cur].toFixed(1) + " A"], ["Conduction V_DS", (st.IL * S.Ron).toFixed(3) + " V"]]);
    const half = S.nOn;
    api.plot("a3", { xmin: 0, ymin: 0, ymax: st.Vdrv + 0.5, xlabel: "Q_G (nC)", ylabel: "V_GS (V)", series: [{ x: Float64Array.from(S.qg.slice(0, half)), y: Float64Array.from(S.vgs.slice(0, half)), color: C.ph, w: 2 }], hlines: [{ y: S.Vpl, color: C.muted, dash: [3, 3], label: "Miller" }] });
    api.ro("a3", [["Q_G", R.qgTot.toFixed(1) + " nC"], ["Plateau", S.Vpl.toFixed(2) + " V"]]);
    api.plot("tp3", { xmin: 0, xmax: 3, ymin: 0, ymax: 220, xlabel: "V_DS (V)", ylabel: "I_D (A)", series: R.fam.map((c) => ({ x: R.vds, y: c.y, color: c.vg === 10 ? C.ink : C.muted, w: c.vg === 10 ? 2 : 1.2 })), labels: R.fam.map((c) => ({ x: 2.95, y: Math.min(c.y[120], 210), text: c.vg + " V", align: "right", dy: -7 })), points: [{ x: st.IL * S.Ron, y: st.IL, color: C.ph, label: "on-state" }] });
    api.ro("tp3", [["R_on (V_drv, T_j)", (S.Ron * 1000).toFixed(2) + " mΩ"], ["V_t at T_j", R.p.Vt.toFixed(2) + " V"], ["Conduction loss", R.Pc.toFixed(2) + " W"]]);
    api.plot("tp4", { xmin: 0, xmax: L_DRIFT / 1000, ymin: 0, ymax: Math.max(ECRIT * 1.2, R.df.Emax * 1.1) / 1e5, xlabel: "depth into drift (µm)", ylabel: "E (10⁵ V/cm)", series: [{ x: R.df.y, y: map(R.df.E, (v) => v / 1e5), color: C.dc, w: 2, fill: C.dc }], hlines: [{ y: ECRIT / 1e5, color: C.bad, dash: [4, 3], label: "E_crit" }] });
    api.eqv("tp4", `V_bus = ${st.Vbus} V → E_max = ${(R.df.Emax / 1e5).toFixed(2)}×10⁵ V/cm, depletion ${R.df.W.toFixed(2)} µm${R.df.pt ? " (punch-through)" : ""}`);
    api.ro("tp4", [["E_max", (R.df.Emax / 1e5).toFixed(2) + "×10⁵ V/cm", bd ? "warn" : "good"], ["Depletion depth", R.df.W.toFixed(2) + " µm"], ["Margin to avalanche", ((1 - R.df.Emax / ECRIT) * 100).toFixed(0) + " %", bd ? "warn" : ""]]);
    api.plot("tp5", { xlog: true, xmin: 10, xmax: 2000, ymin: 0, xlabel: "f_sw (kHz)", ylabel: "P (W)", legend: true, series: [{ x: R.fr, y: map(R.fr, () => R.Pc), color: C.dc, w: 1.6, label: "conduction" }, { x: R.fr, y: R.Psw, color: C.rf, w: 1.6, label: "switching" }, { x: R.fr, y: R.Ptot, color: C.ink, w: 2.2, label: "total" }], points: [{ x: st.fsw, y: R.Pnow, color: C.ink, label: R.Pnow.toFixed(1) + " W" }] });
    api.ro("tp5", [["Conduction", R.Pc.toFixed(2) + " W"], ["Switching", ((S.Eon + S.Eoff) * st.fsw * 1e3).toFixed(2) + " W"], ["Gate drive", (R.qgTot * 1e-9 * st.Vdrv * st.fsw * 1e3).toFixed(2) + " W"]]);
    const si = map(R.bv, (b) => 5.93e-9 * Math.pow(b, 2.5) * 1000), sic = map(R.bv, (b) => 5.93e-9 * Math.pow(b, 2.5) * 1000 / 400), sj = map(R.bv, (b) => 5.93e-9 * Math.pow(b, 2.5) * 1000 / 6);
    const thisBV = 90, thisR = 5.93e-9 * Math.pow(thisBV, 2.5) * 1000 * 1.6;
    api.plot("a1", { xlog: true, ylog: true, xmin: 20, xmax: 1200, ymin: 1e-4, ymax: 1e3, xlabel: "BV (V)", ylabel: "R_on,sp (mΩ·cm²)", legend: true,
      series: [{ x: R.bv, y: si, color: C.ink, w: 2, label: "Si limit" }, { x: R.bv, y: sj, color: C.ph, w: 1.4, dash: [4, 3], label: "superjunction" }, { x: R.bv, y: sic, color: C.ok, w: 1.4, dash: [2, 3], label: "4H-SiC limit" }],
      points: [{ x: thisBV, y: thisR, color: C.rf, label: "this device" }] });
    api.ro("a1", [["This device BV", "≈ 90 V"], ["R_on,sp", thisR.toFixed(3) + " mΩ·cm²"]]);
  },
};

export default { atomic, bench };
