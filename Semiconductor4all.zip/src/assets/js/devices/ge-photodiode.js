// Waveguide-coupled Ge-on-Si vertical PIN photodiode (1310/1550 nm).
import { buildGrid, solvePoisson, depletedSpans, interp, visDensity, fSI, f, MAT, eps0 } from "../lib/physics.js";
import { map, linspace } from "../lib/plot.js";

const PI = Math.PI;
// ---------- optical and electrical model ----------
// absorption of tensile-strained Ge-on-Si: direct edge at 0.78 eV (≈1590 nm) plus a weak indirect tail
const alphaGe = (lamNm) => { const E = 1239.84 / lamNm; return 18400 * Math.sqrt(Math.max(E - 0.78, 0)) + 60 * Math.max(0, (E - 0.66) / 0.12); };
const GAMMA = 0.35, WI = 0.4; // mode overlap with Ge, intrinsic thickness (µm)
function optics(st) {
  const a = alphaGe(st.lam);
  const eta = 0.9 * (1 - Math.exp(-GAMMA * a * st.L * 1e-4)); // 0.9: coupling into the PD section
  return { a, eta, R: (eta * st.lam) / 1239.84 };
}
const collection = (Vd) => 1 / (1 + Math.exp((Vd - 0.22) / 0.05));          // carriers lost once the field collapses
function iv(Vd, st, Iph) {                                                    // Vd = V_anode − V_cathode (reverse < 0)
  const Is = 2e-9 * st.L / 15, Igen = 3e-9 * (st.L / 15) * (1 + 1.5 * Math.max(-Vd, 0));
  return Is * (Math.exp(Math.min(Vd, 0.7) / (1.3 * 0.02585)) - 1) - (Vd < 0 ? Igen * (1 - Math.exp(Vd / 0.05)) : 0) - Iph * collection(Vd);
}
function bandwidth(VR, L) {
  const E = Math.max(VR + 0.45, 0.05) / (WI * 1e-4);            // V/cm across the i-Ge
  const ve = 6e6 * E / (E + 2e3), vh = 6e6 * E / (E + 8e3);       // cm/s (holes saturate later)
  const ftr = (0.45 * 2 / (1 / ve + 1 / vh)) / (WI * 1e-4) / 1e9; // GHz
  const C = (16 * eps0 * L * 1e-4 * 0.8e-4) / (WI * 1e-4) + 8e-15;
  const frc = 1 / (2 * PI * 80 * C) / 1e9;
  return { ftr, frc, f3: 1 / Math.sqrt(1 / (ftr * ftr) + 1 / (frc * frc)), C };
}

// ---------- atomic: vertical cut n+ Ge → i-Ge → p+ Si ----------
const TN = 70, TI = 400, TP = 220;
function vertical(VR) {
  const g = buildGrid([
    { mat: "Ge", t: TN, N: 1e19, dx: 2, phin: VR, phip: 0 },
    { mat: "Ge", t: TI, N: 1e15, dx: 3, phin: VR, phip: 0 },
    { mat: "Si", t: TP, N: -1e19, dx: 2, phin: VR, phip: 0 },
  ]);
  return { g, s: solvePoisson(g, { left: { type: "ohmic", V: VR }, right: { type: "ohmic", V: 0 } }) };
}
const D2Y = (d) => (d <= TN ? 15 + 7 * d / TN : d <= TN + TI ? 22 + 23 * (d - TN) / TI : 45 + 15 * (d - TN - TI) / TP);

const atomic = {
  intro: "Cross-section across a waveguide photodiode: light travels in the silicon waveguide (into the page) and leaks up into a germanium block, which absorbs it. Each absorbed photon makes an electron–hole pair; the field in the intrinsic Ge sweeps electrons up to the n⁺ contact and holes down to the p⁺ silicon. Not to scale.",
  controls: [
    { label: "Bias", color: "dc", items: [{ id: "VR", label: "Reverse bias V_R", min: -0.5, max: 3, step: 0.05, value: 1, fmt: (v) => f(v, 2) + " V" }] },
    { label: "Light", color: "opt", items: [{ id: "P", label: "Optical power", min: 0, max: 2, step: 0.02, value: 0.8, fmt: (v) => v.toFixed(2) + " mW" }, { id: "lam", type: "seg", options: [[1310, "1310 nm"], [1550, "1550 nm"], [1610, "1610 nm"]], value: 1550 }] },
  ],
  presets: [
    { label: "Dark, 1 V", set: { P: 0, VR: 1 } }, { label: "1 mW at 1550 nm, 1 V", set: { P: 1, VR: 1, lam: 1550 } },
    { label: "Zero bias (photovoltaic)", set: { P: 1, VR: 0 } }, { label: "1610 nm: past the band edge", set: { P: 1, VR: 1, lam: 1610 } },
  ],
  look: [
    "Look at the bands: germanium's gap (0.66 eV) is much smaller than silicon's (1.12 eV). Photons at 1550 nm (0.80 eV) pass through silicon but are absorbed in Ge.",
    "Even at 0 V the intrinsic Ge is fully depleted by the built-in field, so carriers are still collected. Forward-bias it and the field collapses.",
    "Switch to 1610 nm: the photon energy drops below Ge's direct gap and generation almost stops.",
    "Lens on the i-Ge: an intrinsic crystal, but every photon creates a free electron and a hole.",
  ],
  world: { w: 200, h: 80 }, aspect: "5/2", lensAt: [100, 33],
  cuts: [{ id: "vert", label: "Vertical: n⁺ Ge → i-Ge → p⁺ Si", a: [100, 15], b: [100, 60] }],
  solve(st) {
    const dev = { ...st, L: 15 }; // the atomic view shows a 15 µm long diode
    const V = vertical(st.VR), o = optics(dev);
    const Iph = o.R * st.P * 1e-3;
    return { V, o, Iph, I: iv(-st.VR, dev, Iph), bw: bandwidth(Math.max(st.VR, 0), 15), spans: depletedSpans(V.g, V.s, 0.5) };
  },
  scene(S, st) {
    const gen = st.P > 0 ? Math.min(1, 0.25 + 0.75 * S.o.eta) * Math.min(1, st.P / 1.2) : 0;
    const coll = collection(-st.VR);
    const v = 30 * coll;
    const dark = 0.03;
    const span = S.spans.find((s) => s[0] < TN + 10) || [TN, TN + TI];
    return {
      regions: [
        { x: 0, y: 0, w: 200, h: 60, mat: "clad" },
        { x: 0, y: 60, w: 200, h: 20, mat: "box" },
        { x: 10, y: 45, w: 180, h: 15, mat: "si", dop: "p+" },
        { x: 60, y: 22, w: 80, h: 23, mat: "ge", dop: "i" },
        { x: 60, y: 15, w: 80, h: 7, mat: "ge", dop: "n+" },
        { x: 85, y: 3, w: 30, h: 12, mat: "metal" }, { x: 16, y: 18, w: 12, h: 27, mat: "metal" }, { x: 172, y: 18, w: 12, h: 27, mat: "metal" },
      ],
      glows: st.P > 0 ? [{ cx: 100, cy: 49, rx: 46, ry: 9, color: "opt", a: 0.2 + 0.4 * Math.min(1, st.P) }] : [],
      depl: [{ x: 60, y: D2Y(span[0]), w: 80, h: Math.max(1, D2Y(span[1]) - D2Y(span[0])) }],
      ions: [],
      zones: [
        { id: "ph", type: "ph", x: 55, y: 46, w: 90, h: 12, dens: st.P > 0 ? Math.min(0.9, 0.3 + 0.4 * st.P) : 0, jit: 0.5, px: 60 },
        { id: "ge", type: "e", x: 62, y: 23, w: 76, h: 21, dens: gen * 0.55 + dark, vy: -v, jit: 0.25 },
        { id: "gh", type: "h", x: 62, y: 23, w: 76, h: 21, dens: gen * 0.55 + dark, vy: v * 0.7, jit: 0.25 },
        { id: "nn", type: "e", x: 60, y: 15, w: 80, h: 7, dens: 0.9 },
        { id: "pp", type: "h", x: 10, y: 45, w: 180, h: 15, dens: 0.85 },
      ],
      arrows: st.VR > -0.2 ? [{ x1: 150, y1: 40, x2: 150, y2: 26, color: "e", label: "e⁻ → n⁺" }, { x1: 160, y1: 26, x2: 160, y2: 40, color: "h", label: "h⁺ → p⁺" }] : [],
      labels: [
        { x: 100, y: 34, text: "intrinsic Ge", size: 10 }, { x: 150, y: 18, text: "n⁺ Ge", size: 9, align: "left" },
        { x: 40, y: 53, text: "p⁺ Si waveguide", size: 10 }, { x: 100, y: 72, text: "buried oxide", size: 10, color: "muted" },
        { x: 100, y: 57, text: st.P > 0 ? `λ = ${st.lam} nm, light into the page ⊙` : "dark", size: 9, color: "opt" },
      ],
      terminals: [{ x: 100, y: 4, text: `n ${f(st.VR, 2)} V` }, { x: 22, y: 12, text: "p 0 V" }],
    };
  },
  bands(S) {
    const { g, s } = S.V;
    return { x: s.x, Ec: s.Ec, Ev: s.Ev, EFn: s.EFn, EFp: s.EFp, n: s.n, p: s.p, E: s.E, Nabs: map(g.N, Math.abs),
      regions: [{ x0: 0, x1: TN, label: "n⁺ Ge" }, { x0: TN, x1: TN + TI, label: "i-Ge" }, { x0: TN + TI, x1: TN + TI + TP, label: "p⁺ Si" }], xlabel: "depth from top contact (nm)" };
  },
  readouts(S, st) {
    return [["Absorption α", S.o.a.toFixed(0) + " cm⁻¹"], ["Quantum efficiency", (S.o.eta * 100).toFixed(1) + " %"], ["Responsivity", S.o.R.toFixed(3) + " A/W"],
      ["Photocurrent", fSI(S.Iph * collection(-st.VR), "A")], ["Field in i-Ge", (Math.abs(interp(S.V.s.x, S.V.s.E, TN + TI / 2)) / 1e4).toFixed(1) + "×10⁴ V/cm"]];
  },
  foot: "1D Poisson through the Ge mesa (n⁺ Ge 10¹⁹ | i-Ge 10¹⁵, 400 nm | p⁺ Si 10¹⁹) with Ge/Si band offsets; quasi-Fermi levels pinned at the contacts (photocarriers do not perturb the bands). Absorption: strained-Ge direct edge at 0.78 eV, mode overlap 0.35, 15 µm long. Illustrative values.",
};

// ---------- bench ----------
const BITS = (() => { let s = 0x7f; const b = []; for (let i = 0; i < 127; i++) { const n = ((s >> 6) ^ (s >> 5)) & 1; s = ((s << 1) | n) & 0x7f; b.push(n); } return b; })();
let seed = 1;
const rnd = () => ((seed = (seed * 1664525 + 1013904223) >>> 0) / 4294967296);
const gauss = () => { let u = 0; while (!u) u = rnd(); return Math.sqrt(-2 * Math.log(u)) * Math.cos(2 * PI * rnd()); };

const bench = {
  intro: "A modulated laser feeds the waveguide; the photodiode, biased by a source-meter through a bias-tee, converts light back to current; a 50 Ω scope (or TIA) reads it. Follow the signal from photons to the eye diagram.",
  animated: true,
  controls: [
    { label: "Optical input (TP1)", color: "opt", items: [{ id: "P", label: "Average power", min: 0.02, max: 2, step: 0.02, value: 0.5, fmt: (v) => v.toFixed(2) + " mW" }, { id: "lam", label: "Wavelength", min: 1260, max: 1640, step: 5, value: 1550, fmt: (v) => v + " nm" }, { id: "rate", label: "Data rate (NRZ, ER 6 dB)", min: 10, max: 100, step: 2, value: 50, fmt: (v) => v + " Gb/s" }] },
    { label: "Bias SMU (TP2)", color: "dc", items: [{ id: "VR", label: "Reverse bias V_R", min: -0.4, max: 3, step: 0.05, value: 1, fmt: (v) => f(v, 2) + " V" }] },
    { label: "Device", color: "ph", items: [{ id: "L", label: "Ge length", min: 5, max: 50, step: 1, value: 15, fmt: (v) => v + " µm" }] },
  ],
  presets: [
    { label: "50 Gb/s at 1550 nm", set: { P: 0.5, lam: 1550, rate: 50, VR: 1, L: 15 } },
    { label: "O-band 1310 nm", set: { P: 0.5, lam: 1310, rate: 50, VR: 1, L: 15 } },
    { label: "Zero bias, 100 Gb/s", set: { P: 0.5, lam: 1550, rate: 100, VR: 0, L: 15 } },
    { label: "Long Ge (50 µm): slow", set: { P: 0.5, lam: 1550, rate: 100, VR: 1, L: 50 } },
  ],
  schematic: {
    viewBox: "0 0 960 320",
    svg: `
  <rect class="bx" x="20" y="120" width="120" height="56" rx="5"/><text class="lb" x="80" y="144" text-anchor="middle">Laser + MZM</text><text class="sub" x="80" y="163" text-anchor="middle">NRZ data</text>
  <path class="o" d="M140,148 H420"/><path class="flow" d="M140,148 H420"/>
  <rect class="die" x="250" y="90" width="410" height="120" rx="10"/><text class="cap" x="262" y="108">SiPh die</text>
  <rect class="bx chip" x="300" y="135" width="90" height="26" rx="4"/><text class="sub" x="345" y="152" text-anchor="middle">grating</text>
  <rect class="dev" x="420" y="124" width="170" height="48" rx="6"/><text class="lb" x="505" y="146" text-anchor="middle">Ge PIN photodiode</text><text class="sub pdtxt" x="505" y="163" text-anchor="middle"></text>
  <path class="mix" d="M590,148 H700"/>
  <rect class="bx chip" x="700" y="130" width="90" height="36" rx="4"/><text class="lb" x="745" y="153" text-anchor="middle">Bias-tee</text>
  <path class="rf" d="M790,148 H830"/>
  <rect class="bx" x="830" y="120" width="110" height="56" rx="5"/><text class="lb" x="885" y="144" text-anchor="middle">Scope</text><text class="sub" x="885" y="163" text-anchor="middle">50 Ω</text>
  <path class="dc" d="M745,166 V240"/>
  <rect class="bx" x="680" y="240" width="130" height="50" rx="5"/><text class="lb" x="745" y="262" text-anchor="middle">Source-meter</text><text class="sub" x="745" y="280" text-anchor="middle">−V_R, reads I</text>`,
  },
  tps: [{ n: 1, x: 220, y: 148, label: "optical input" }, { n: 2, x: 745, y: 210, label: "bias and I-V" }, { n: 3, x: 810, y: 148, label: "photocurrent" }, { n: 4, x: 505, y: 195, label: "spectral response" }],
  sections: [{ k: "sig", t: "Signal path", n: "Photons in, electrons out." }, { k: "ana", t: "Device trade-offs", n: "Speed against efficiency." }],
  cards: [
    { id: "tp1", tp: 1, s: "sig", d: "opt", dn: "optical", t: "Optical input", x: "Modulated light in the waveguide: NRZ PRBS7 with a 6 dB extinction ratio.", eq: "P(t) = P̄·[1 ± (ER−1)/(ER+1)]" },
    { id: "tp2", tp: 2, s: "sig", d: "dc", dn: "DC", t: "Source-meter: I–V, dark and illuminated", x: "|I| on a log scale. Dark: generation current in the depleted Ge. Light shifts the curve by the photocurrent. Diamond: bias point.", eq: "I(V) = I<sub>s</sub>(e<sup>V/nU<sub>T</sub></sup> − 1) − I<sub>gen</sub> − I<sub>ph</sub>·χ(V),&nbsp; I<sub>ph</sub> = ℛ·P" },
    { id: "tp3", tp: 3, s: "sig", d: "rf", dn: "instrument", t: "Photocurrent on the scope", x: "Eye diagram of i(t) after the PD bandwidth and receiver noise. A closing eye means the PD is too slow for the data rate.", eq: "i(t) = ℛP(t) ∗ h<sub>PD</sub>(t),&nbsp; f<sub>3dB</sub> = (f<sub>tr</sub><sup>−2</sup> + f<sub>RC</sub><sup>−2</sup>)<sup>−½</sup>", h: "tall" },
    { id: "tp4", tp: 4, s: "sig", d: "ph", dn: "spectral", t: "Responsivity vs wavelength", x: "Germanium absorbs strongly up to its direct band edge (≈1590 nm here, thanks to tensile strain). Past it, responsivity collapses.", eq: "η = 0.9·(1 − e<sup>−Γα(λ)L</sup>),&nbsp; ℛ = η·qλ/(hc) = η·λ[µm]/1.24 A/W" },
    { id: "a1", chip: "f–V", s: "ana", d: "an", dn: "speed", t: "Bandwidth vs bias", x: "Transit time across the i-Ge (holes are the slow carrier) and RC charging. More bias = faster carriers until velocity saturates.", eq: "f<sub>tr</sub> ≈ 0.45·v̄/W<sub>i</sub>,&nbsp; f<sub>RC</sub> = 1/(2π(R<sub>L</sub>+R<sub>s</sub>)C),&nbsp; C = ε<sub>Ge</sub>A/W<sub>i</sub>" },
    { id: "a2", chip: "η–L", s: "ana", d: "an", dn: "trade-off", t: "Length: efficiency vs capacitance", x: "A longer Ge section absorbs more light but adds capacitance. The marker is the current length.", eq: "η(L) = 0.9(1 − e<sup>−ΓαL</sup>),&nbsp; C ∝ L" },
  ],
  foot: "Model: strained Ge-on-Si absorption (direct edge 0.78 eV), mode overlap Γ = 0.35, 0.8 µm wide × 0.4 µm intrinsic Ge, saturation velocities 6×10⁶ cm/s, 50 Ω load + 30 Ω series, 8 fF pad; dark current scales with length and bias; receiver noise 2 µA rms. Illustrative values.",
  sim(st) {
    seed = 99;
    const o = optics(st), bw = bandwidth(Math.max(st.VR, 0), st.L);
    const R = { o, bw };
    R.Iph = o.R * st.P * 1e-3 * collection(-st.VR);
    R.Idark = -iv(-st.VR, st, 0);
    const spb = 24, N = BITS.length * spb, dt = 1 / (st.rate * spb); // ns
    const er = Math.pow(10, 0.6), hi = (2 * er) / (er + 1), lo = 2 / (er + 1);
    const t = new Float64Array(N), P = new Float64Array(N), I = new Float64Array(N);
    const tau = 1 / (2 * PI * bw.f3 * 1.55); // two cascaded poles ≈ f3
    const a = 1 - Math.exp(-dt / tau);
    let y1 = 0, y2 = 0;
    for (let pass = 0; pass < 2; pass++) for (let i = 0; i < N; i++) {
      t[i] = i * dt; P[i] = st.P * (BITS[Math.floor(i / spb)] ? hi : lo);
      y1 += (o.R * P[i] * collection(-st.VR) - y1) * a; y2 += (y1 - y2) * a;
      I[i] = y2 * 1000 + (pass ? 2 * gauss() : 0); // ℛ[A/W]·P[mW] = mA → µA, plus 2 µA rms receiver noise
    }
    Object.assign(R, { t, P, I, spb, N });
    // eye
    const segs = [], ones = [], zeros = [];
    let bp = 0, best = -1;
    for (let p = 0; p < spb; p++) { let s1 = 0, s0 = 0, n1 = 0, n0 = 0; for (let k = 2; k < BITS.length - 1; k++) { const v = I[k * spb + p]; if (BITS[k]) { s1 += v; n1++; } else { s0 += v; n0++; } } if (s1 / n1 - s0 / n0 > best) { best = s1 / n1 - s0 / n0; bp = p; } }
    for (let k = 2; k < BITS.length - 2; k++) {
      const c = k * spb + bp; (BITS[k] ? ones : zeros).push(I[c]);
      const i0 = c - Math.round(spb / 2), xs = [], ys = [];
      for (let i = i0; i <= i0 + 2 * spb && i < N; i++) { xs.push((i - i0) / spb); ys.push(I[i]); }
      segs.push([xs, ys]);
    }
    const mean = (q) => q.reduce((s, v) => s + v, 0) / q.length, sd = (q, m) => Math.sqrt(q.reduce((s, v) => s + (v - m) * (v - m), 0) / q.length);
    const m1 = mean(ones), m0 = mean(zeros);
    R.eye = { segs, m1, m0, Q: (m1 - m0) / (sd(ones, m1) + sd(zeros, m0)), EH: Math.min(...ones) - Math.max(...zeros) };
    R.V = linspace(-3.2, 0.6, 160);
    R.ivD = map(R.V, (v) => Math.abs(iv(v, st, 0)));
    R.ivL = map(R.V, (v) => Math.abs(iv(v, st, o.R * st.P * 1e-3)));
    R.lams = linspace(1250, 1650, 161);
    R.Rl = map(R.lams, (l) => optics({ ...st, lam: l }).R);
    R.vr = linspace(0, 3, 61);
    R.ftr = map(R.vr, (v) => bandwidth(v, st.L).ftr); R.frc = map(R.vr, (v) => bandwidth(v, st.L).frc); R.f3 = map(R.vr, (v) => bandwidth(v, st.L).f3);
    R.Ls = linspace(2, 60, 59);
    R.etaL = map(R.Ls, (L) => optics({ ...st, L }).eta * 100); R.f3L = map(R.Ls, (L) => bandwidth(Math.max(st.VR, 0), L).f3);
    return R;
  },
  render(R, api) {
    const { st, C } = api;
    const W = 16 * R.spb, tw = R.t.subarray(0, W), xmax = tw[W - 1], cur = (api.frame * 4) % W;
    const fwd = st.VR < -0.15;
    api.status([
      ["Responsivity", R.o.R.toFixed(3) + " A/W", R.o.R < 0.4 ? "warn" : "good"], ["Photocurrent", fSI(R.Iph, "A"), ""], ["Dark current", fSI(R.Idark, "A"), ""],
      ["f₃dB", R.bw.f3.toFixed(1) + " GHz", R.bw.f3 < 0.6 * st.rate ? "warn" : "good"], ["Eye Q", R.eye.Q.toFixed(1), R.eye.Q < 6 ? "warn" : "good"], ["Bias", fwd ? "forward: not collecting" : "reverse", fwd ? "warn" : "good"],
    ]);
    api.q(".pdtxt").textContent = `L = ${st.L} µm · C = ${(R.bw.C * 1e15).toFixed(1)} fF`;
    api.q(".dev")?.classList.toggle("fault", fwd);
    api.plot("tp1", { xmin: 0, xmax, ymin: 0, xlabel: "time (ns)", ylabel: "P (mW)", series: [{ x: tw, y: R.P.subarray(0, W), color: C.opt, w: 1.8, fill: C.opt }], cursor: tw[cur] });
    api.ro("tp1", [["Average", st.P.toFixed(2) + " mW"], ["Average", (10 * Math.log10(st.P)).toFixed(1) + " dBm"], ["Photon energy", (1239.84 / st.lam).toFixed(3) + " eV"]]);
    api.plot("tp2", { xmin: -3.2, xmax: 0.6, ylog: true, ymin: 1e-11, ymax: 1e-2, xlabel: "V_anode−cathode (V)", ylabel: "|I| (A)", legend: true, series: [{ x: R.V, y: R.ivD, color: C.muted, w: 1.6, label: "dark" }, { x: R.V, y: R.ivL, color: C.dc, w: 2.2, label: "illuminated" }], points: [{ x: -st.VR, y: Math.abs(iv(-st.VR, st, R.o.R * st.P * 1e-3)), color: C.ink }] });
    api.eqv("tp2", `I_ph = ${R.o.R.toFixed(3)} A/W × ${st.P.toFixed(2)} mW = ${fSI(R.o.R * st.P * 1e-3, "A")}, collected ${(collection(-st.VR) * 100).toFixed(0)} %`);
    api.ro("tp2", [["V_R", f(st.VR, 2) + " V"], ["Total current", fSI(Math.abs(iv(-st.VR, st, R.o.R * st.P * 1e-3)), "A")], ["Dark", fSI(R.Idark, "A")]]);
    api.plot("tp3", { xmin: 0, xmax: 2, ymin: Math.min(0, R.eye.m0 * 1.3), xlabel: "time (UI)", ylabel: "i (µA)", series: [{ segs: R.eye.segs, color: C.rf, w: 1, alpha: 0.35 }], hlines: [{ y: R.eye.m1, color: C.ok, dash: [3, 3], label: "'1'" }, { y: R.eye.m0, color: C.bad, dash: [3, 3], label: "'0'" }] });
    api.eqv("tp3", `f_tr = ${R.bw.ftr.toFixed(0)} GHz, f_RC = ${R.bw.frc.toFixed(0)} GHz → f₃dB = ${R.bw.f3.toFixed(1)} GHz for ${st.rate} Gb/s`);
    api.ro("tp3", [["Q-factor", R.eye.Q.toFixed(1), R.eye.Q < 6 ? "warn" : "good"], ["OMA", (R.eye.m1 - R.eye.m0).toFixed(0) + " µA"], ["Eye height", R.eye.EH.toFixed(0) + " µA", R.eye.EH <= 0 ? "warn" : ""]]);
    api.plot("tp4", { xmin: 1250, xmax: 1650, ymin: 0, ymax: 1.25, xlabel: "λ (nm)", ylabel: "ℛ (A/W)", series: [{ x: R.lams, y: map(R.lams, (l) => l / 1239.84), color: C.muted, w: 1, dash: [3, 3] }, { x: R.lams, y: R.Rl, color: C.ph, w: 2.2, fill: C.ph }], vlines: [{ x: 1590, color: C.muted, dash: [2, 3], label: "Ge edge" }], points: [{ x: st.lam, y: R.o.R, color: C.ink, label: R.o.R.toFixed(2) + " A/W" }] });
    api.eqv("tp4", `α(${st.lam} nm) = ${R.o.a.toFixed(0)} cm⁻¹ → ΓαL = ${(GAMMA * R.o.a * st.L * 1e-4).toFixed(2)}, η = ${(R.o.eta * 100).toFixed(0)} %. Dashed: 100 % efficiency.`);
    api.ro("tp4", [["α", R.o.a.toFixed(0) + " cm⁻¹"], ["η", (R.o.eta * 100).toFixed(1) + " %"], ["ℛ", R.o.R.toFixed(3) + " A/W"]]);
    api.plot("a1", { xmin: 0, xmax: 3, ymin: 0, xlabel: "V_R (V)", ylabel: "f (GHz)", legend: true, series: [{ x: R.vr, y: R.ftr, color: C.opt, w: 1.4, dash: [4, 3], label: "transit" }, { x: R.vr, y: R.frc, color: C.dc, w: 1.4, dash: [2, 3], label: "RC" }, { x: R.vr, y: R.f3, color: C.ink, w: 2.2, label: "f₃dB" }], points: [{ x: Math.max(st.VR, 0), y: R.bw.f3, color: C.ph }] });
    api.ro("a1", [["f_transit", R.bw.ftr.toFixed(0) + " GHz"], ["f_RC", R.bw.frc.toFixed(0) + " GHz"], ["f₃dB", R.bw.f3.toFixed(1) + " GHz"]]);
    api.plot("a2", { xmin: 2, xmax: 60, ymin: 0, xlabel: "Ge length L (µm)", ylabel: "η (%) · f₃dB (GHz)", legend: true, series: [{ x: R.Ls, y: R.etaL, color: C.ph, w: 2, label: "η %" }, { x: R.Ls, y: R.f3L, color: C.ink, w: 2, label: "f₃dB GHz" }], vlines: [{ x: st.L, color: C.muted, dash: [2, 3] }] });
    api.ro("a2", [["η", (R.o.eta * 100).toFixed(1) + " %"], ["C", (R.bw.C * 1e15).toFixed(1) + " fF"]]);
  },
};

export default { atomic, bench };
