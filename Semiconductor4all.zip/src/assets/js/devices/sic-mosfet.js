// 4H-SiC planar power MOSFET (1200 V class): wide band gap, thin drift layer, imperfect gate interface.
import { buildGrid, solvePoisson, depletedSpans, ekvId, visDensity, fSI, f, MAT, q, eps0 } from "../lib/physics.js";
import { map, linspace, logspace } from "../lib/plot.js";

// ---------- atomic ----------
const L_SRC = 200, L_PW = 800, L_DR = 10000, L_SUB = 500, N_PW = 2e17, N_DR = 8e15;
const DEP = [0, L_SRC, L_SRC + L_PW, L_SRC + L_PW + L_DR, L_SRC + L_PW + L_DR + L_SUB];
const YW = [14, 20, 34, 100, 114];
const d2y = (d) => { for (let k = 0; k < 4; k++) if (d <= DEP[k + 1]) return YW[k] + ((YW[k + 1] - YW[k]) * (d - DEP[k])) / (DEP[k + 1] - DEP[k]); return YW[4]; };
const EC_SIC = 2.5e6, EC_SI = 3e5; // critical fields, V/cm
function verticalCut(VDS) {
  const g = buildGrid([
    { mat: "SiC", t: L_SRC, N: 1e19, dx: 8, phin: 0, phip: 0 },
    { mat: "SiC", t: L_PW, N: -N_PW, dx: 4, phin: 0, phip: 0 },
    { mat: "SiC", t: L_DR, N: N_DR, dx: 30, phin: VDS, phip: 0 },
    { mat: "SiC", t: L_SUB, N: 1e19, dx: 20, phin: VDS, phip: 0 },
  ]);
  return { g, s: solvePoisson(g, { left: { type: "ohmic", V: 0 }, right: { type: "ohmic", V: VDS } }) };
}
const TOX = 50;
function mosCut(VGS, Dit) { // trapped interface charge: ≈ Dit × 0.6 eV of filled states once the surface inverts
  const fill = Math.max(0, Math.min(1, (VGS - 2) / 8));
  const g = buildGrid([{ mat: "SiO2", t: TOX - 1, dx: 2 }, { mat: "SiO2", t: 1, dx: 0.25, Qf: (-Dit * 0.6 * fill) / 1e-7 }, { mat: "SiC", t: 400, N: -5e16, dx: 1.5 }]);
  const s = solvePoisson(g, { left: { type: "gate", V: VGS, wf: 4.05 }, right: { type: "ohmic", V: 0 } });
  let ns = 0; for (let i = 1; i < g.x.length; i++) if (g.x[i] > TOX) ns += s.n[i] * (g.x[i] - g.x[i - 1]) * 1e-7;
  return { g, s, ns };
}

const atomic = {
  intro: "Half-cell of a planar SiC MOSFET. Silicon carbide's band gap (3.3 eV) and critical field (≈ 2.5 MV/cm, 8× silicon) let a 10 µm drift layer block 1200 V; silicon would need ~100 µm. The weak point is the gate: the SiC/SiO₂ interface traps many electrons, so channel mobility is low. Not to scale.",
  controls: [
    { label: "Gate", color: "ph", items: [{ id: "VGS", label: "V_GS", min: -5, max: 20, step: 0.5, value: 0, fmt: (v) => f(v, 1) + " V" }] },
    { label: "Drain", color: "rf", items: [{ id: "VDS", label: "V_DS", min: 0, max: 1500, step: 10, value: 800, fmt: (v) => v + " V" }] },
    { label: "Gate interface", color: "dc", items: [{ id: "Dit", label: "Interface trap density", min: 1e11, max: 5e12, step: 1e11, value: 1e12, fmt: (v) => (v / 1e12).toFixed(1) + "×10¹² cm⁻²eV⁻¹" }] },
  ],
  presets: [{ label: "Blocking 800 V", set: { VGS: 0, VDS: 800 } }, { label: "Blocking 1400 V", set: { VGS: 0, VDS: 1400 } }, { label: "On: 18 V gate", set: { VGS: 18, VDS: 2 } }, { label: "Poor interface", set: { VGS: 18, VDS: 2, Dit: 5e12 } }],
  look: [
    "Block 800–1400 V: the depletion region fills most of the 10 µm drift layer. Look at the Field view: the peak stays below SiC's critical field, about 8× what silicon could take.",
    "On the gate cut at 18 V: compare the trapped charge with Dit = 10¹¹ and 5×10¹²: interface traps soak up electrons that should be in the channel.",
    "Lens on the drift region: the 4H-SiC crystal. Each Si atom is bonded to four C atoms, and those short, strong bonds give the wide gap.",
  ],
  world: { w: 160, h: 120 }, aspect: "4/3", lensAt: [40, 60],
  cuts: [{ id: "vert", label: "Vertical: source → drain", a: [30, 14], b: [30, 114] }, { id: "mos", label: "Gate → channel", a: [64, 8], b: [64, 30] }],
  solve(st) {
    const V = verticalCut(st.VDS), M = mosCut(st.VGS, st.Dit);
    let Emax = 0; for (const e of V.s.E) Emax = Math.max(Emax, Math.abs(e));
    return { V, M, Emax, spans: depletedSpans(V.g, V.s, 0.5), id: idDC(st.VGS, Math.min(st.VDS, 20), { Tj: 25, Dit: st.Dit }) };
  },
  scene(S, st) {
    const sp = S.spans.find((s) => s[0] < DEP[2] + 50 && s[1] > DEP[2]) || [DEP[2], DEP[2]];
    const yt = d2y(sp[0]), yb = d2y(sp[1]);
    const ch = visDensity(S.M.ns / 5e-6, 13, 19.5), flow = S.id > 1e-3 ? Math.min(40, 6 * Math.log10(S.id * 1e3)) : 0;
    const zones = [];
    for (const [x0, x1, s] of [[0, 70, "L"], [90, 160, "R"]]) {
      zones.push({ id: "pw" + s, type: "h", x: x0, y: 20, w: x1 - x0, h: Math.max(0.5, yt - 20), dens: 0.7 });
      zones.push({ id: "dr" + s, type: "e", x: x0, y: Math.max(yb, 34), w: x1 - x0, h: Math.max(0.5, 100 - Math.max(yb, 34)), dens: 0.35, vy: flow * 0.6 });
    }
    zones.push({ id: "src", type: "e", x: 20, y: 14, w: 40, h: 6, dens: 0.9 }, { id: "src2", type: "e", x: 100, y: 14, w: 40, h: 6, dens: 0.9 });
    zones.push({ id: "jfet", type: "e", x: 70, y: 14, w: 20, h: Math.max(0.5, Math.min(yb, 100) - 14 > 0 ? 20 : 0.5), dens: 0.35, vy: flow * 0.6 });
    zones.push({ id: "sub", type: "e", x: 0, y: 100, w: 160, h: 14, dens: 0.9 });
    zones.push({ id: "chL", type: "e", x: 60, y: 14, w: 10, h: 1.6, dens: ch, vx: flow, jit: 0.4, px: 25 }, { id: "chR", type: "e", x: 90, y: 14, w: 10, h: 1.6, dens: ch, vx: -flow, jit: 0.4, px: 25 });
    return {
      regions: [
        { x: 0, y: 114, w: 160, h: 6, mat: "metal" }, { x: 0, y: 100, w: 160, h: 14, mat: "sic", dop: "n+" }, { x: 0, y: 14, w: 160, h: 86, mat: "sic", dop: "n" },
        { x: 0, y: 14, w: 70, h: 20, mat: "sic", dop: "p" }, { x: 90, y: 14, w: 70, h: 20, mat: "sic", dop: "p" },
        { x: 20, y: 14, w: 40, h: 6, mat: "sic", dop: "n+" }, { x: 100, y: 14, w: 40, h: 6, mat: "sic", dop: "n+" },
        { x: 55, y: 11, w: 50, h: 3, mat: "ox" }, { x: 55, y: 4, w: 50, h: 7, mat: "poly" },
        { x: 0, y: 4, w: 40, h: 10, mat: "metal" }, { x: 120, y: 4, w: 40, h: 10, mat: "metal" },
      ],
      depl: yb - yt > 0.4 ? [{ x: 0, y: yt, w: 160, h: yb - yt }] : [],
      ions: yb - yt > 0.4 ? [{ x: 0, y: Math.max(yt, 20), w: 70, h: Math.max(0, 34 - Math.max(yt, 20)), sign: -1 }, { x: 90, y: Math.max(yt, 20), w: 70, h: Math.max(0, 34 - Math.max(yt, 20)), sign: -1 }, { x: 0, y: 34, w: 160, h: Math.max(0, yb - 34), sign: 1, dens: 0.18 }] : [],
      zones,
      arrows: S.Emax > EC_SIC * 0.9 ? [{ x1: 30, y1: 42, x2: 30, y2: 35, color: "bad", label: "near critical field" }] : flow > 0 ? [{ x1: 80, y1: 40, x2: 80, y2: 90, color: "e", label: "e⁻" }] : [],
      labels: [{ x: 80, y: 7.5, text: "gate", size: 9 }, { x: 25, y: 28, text: "p-well", size: 10 }, { x: 80, y: 30, text: "JFET", size: 8, color: "muted" }, { x: 125, y: 70, text: "n⁻ drift, 10 µm", size: 10 }, { x: 125, y: 107, text: "n⁺ 4H-SiC substrate", size: 9 }],
      terminals: [{ x: 20, y: 2, text: "S" }, { x: 80, y: 1.5, text: `G ${f(st.VGS, 1)} V` }, { x: 130, y: 117, text: `D ${st.VDS} V` }],
    };
  },
  bands(S, st, cut) {
    if (cut === "mos") {
      const { g, s } = S.M;
      const idx = []; for (let i = 0; i < s.x.length; i++) if (s.x[i] <= TOX + 120) idx.push(i);
      const pick = (a) => Float64Array.from(idx, (i) => a[i]);
      return { x: pick(s.x), Ec: pick(s.Ec), Ev: pick(s.Ev), EFn: pick(s.EFn), EFp: pick(s.EFp), n: pick(s.n), p: pick(s.p), E: pick(s.E), Nabs: map(pick(g.N), Math.abs), regions: [{ x0: 0, x1: TOX, label: "gate oxide" }, { x0: TOX, x1: TOX + 120, label: "p-well (SiC)" }], xlabel: "depth from gate (nm)", clip: [-8, 10] };
    }
    const { g, s } = S.V;
    return { x: map(s.x, (v) => v / 1000), Ec: s.Ec, Ev: s.Ev, EFn: s.EFn, EFp: s.EFp, n: s.n, p: s.p, E: s.E, Nabs: map(g.N, Math.abs), regions: [{ x0: 0, x1: 0.2, label: "" }, { x0: 0.2, x1: 1.0, label: "p" }, { x0: 1.0, x1: 11.0, label: "n⁻ drift" }, { x0: 11.0, x1: 11.5, label: "n⁺" }], xlabel: "depth (µm)" };
  },
  readouts(S, st) {
    return [["Peak field", (S.Emax / 1e6).toFixed(2) + " MV/cm", S.Emax > EC_SIC ? "warn" : "good"], ["vs SiC critical field", ((S.Emax / EC_SIC) * 100).toFixed(0) + " %"], ["Silicon would need", ((st.VDS * 2) / EC_SI * 1e4).toFixed(0) + " µm of drift"],
      ["Channel electrons", S.M.ns.toExponential(1) + " cm⁻²"], ["Electrons lost to traps", (st.Dit * 0.6 * Math.max(0, Math.min(1, (st.VGS - 2) / 8))).toExponential(1) + " cm⁻²"]];
  },
  foot: "Vertical 1D Poisson in 4H-SiC (E_g 3.26 eV): n⁺ | p-well 2×10¹⁷ | 10 µm drift 8×10¹⁵ | n⁺. Gate cut: 50 nm oxide on a 5×10¹⁶ p-well surface, interface traps as a negative sheet growing with gate voltage. Incomplete ionisation of dopants in SiC is ignored. Illustrative values.",
};

// ---------- compact model (die area 0.1 cm²) ----------
const AREA = 0.1, PITCH = 5e-4, LCH = 0.5e-4, COX = (3.9 * eps0) / (TOX * 1e-7);
function devParams(o) {
  const T = o.Tj + 273.15, r = T / 298;
  const muCh = (35 / (1 + o.Dit / 1.5e12)) * Math.pow(r, 0.9); // Coulomb scattering by trapped charge eases when hot
  const Vt = 4.0 + (o.Dit / 1e12) * 0.8 - 0.006 * (o.Tj - 25);
  const beta = (muCh * COX * ((AREA * 2) / PITCH)) / LCH;
  const Rdrift = (L_DR * 1e-7 / (q * N_DR * 900 * Math.pow(r, -2.4))) / AREA; // Ω
  return { Vt, n: 2.2, beta, Ut: 0.0259 * r, theta: 0.02, lambda: 0.001, muCh, Rd: Rdrift + 0.0015 * r, Rs: 0.001, Rjfet: 0.002 * Math.pow(r, 2) };
}
function idDC(VGS, VDS, o) {
  const p = devParams(o), Rser = p.Rd + p.Rs + p.Rjfet;
  if (VDS <= 0) return 0;
  let lo = 0, hi = Math.min(VDS / Rser, 3000);
  for (let k = 0; k < 60; k++) { const m = (lo + hi) / 2; if (ekvId(VGS - m * p.Rs, VDS - m * Rser, p) > m) lo = m; else hi = m; }
  return (lo + hi) / 2;
}
const ron = (VGS, o) => 1 / Math.max(idDC(VGS, 1, o), 1e-9);
function drift(V, mat) { // abrupt junction with punch-through into the substrate
  const es = (mat === "SiC" ? 9.7 : 11.7) * eps0, N = mat === "SiC" ? N_DR : 1.5e14, Wd = (mat === "SiC" ? L_DR : 100000) * 1e-7, a = (q * N) / es;
  let W = Math.sqrt((2 * V) / a), Emax, pt = false;
  if (W <= Wd) Emax = a * W; else { pt = true; W = Wd; Emax = V / Wd + (a * Wd) / 2; }
  return { Emax, W: W * 1e4, pt, a, Wd: Wd * 1e4 };
}

const bench = {
  intro: "A 1200 V, 0.1 cm² SiC MOSFET on a curve tracer and in a blocking test. Gate drive is +18 V / −5 V; watch how temperature and the gate-oxide interface change the on-resistance, and compare the drift layer with silicon's.",
  controls: [
    { label: "Gate driver (TP1)", color: "ph", items: [{ id: "VGS", label: "V_GS", min: -5, max: 20, step: 0.5, value: 18, fmt: (v) => f(v, 1) + " V" }] },
    { label: "Drain (TP2, TP3)", color: "rf", items: [{ id: "VDS", label: "V_DS (curves)", min: 0, max: 10, step: 0.1, value: 2, fmt: (v) => v.toFixed(1) + " V" }, { id: "Vbus", label: "Blocking voltage", min: 100, max: 1500, step: 20, value: 800, fmt: (v) => v + " V" }] },
    { label: "Conditions", color: "heat", items: [{ id: "Tj", label: "Junction temperature", min: 25, max: 200, step: 5, value: 25, fmt: (v) => v + " °C" }, { id: "Dit", label: "Interface traps D_it", min: 1e11, max: 5e12, step: 1e11, value: 1e12, fmt: (v) => (v / 1e12).toFixed(1) + "×10¹²" }] },
  ],
  presets: [{ label: "18 V, 25 °C", set: { VGS: 18, Tj: 25, Dit: 1e12 } }, { label: "18 V, 175 °C", set: { VGS: 18, Tj: 175 } }, { label: "Weak drive 12 V", set: { VGS: 12 } }, { label: "Better oxide (D_it 2×10¹¹)", set: { Dit: 2e11 } }, { label: "Block 1400 V", set: { Vbus: 1400 } }],
  schematic: {
    viewBox: "0 0 900 300",
    svg: `
  <rect class="bx" x="30" y="120" width="150" height="56" rx="5"/><text class="lb" x="105" y="144" text-anchor="middle">Gate driver</text><text class="sub" x="105" y="163" text-anchor="middle">+18 / −5 V</text>
  <path class="mix" d="M180,148 H380"/>
  <rect class="dev" x="380" y="100" width="140" height="96" rx="6"/><text class="lb" x="450" y="140" text-anchor="middle">SiC MOSFET</text><text class="sub sictxt" x="450" y="160" text-anchor="middle"></text>
  <rect class="bx" x="600" y="20" width="200" height="56" rx="5"/><text class="lb" x="700" y="44" text-anchor="middle">Curve tracer / HV supply</text><text class="sub" x="700" y="63" text-anchor="middle">V_DS, I_D</text>
  <path class="rf" d="M450,100 V48 H600"/>
  <path class="w" d="M450,196 V260 H430 M435,266 H465 M442,272 H458"/>
  <rect class="bx" x="600" y="200" width="200" height="56" rx="5"/><text class="lb" x="700" y="224" text-anchor="middle">Hot plate</text><text class="sub" x="700" y="243" text-anchor="middle">T_j</text>
  <path class="th" d="M600,228 H520"/>`,
  },
  tps: [{ n: 1, x: 300, y: 148, label: "gate" }, { n: 2, x: 520, y: 48, label: "drain" }, { n: 3, x: 450, y: 220, label: "drift layer" }, { n: 4, x: 560, y: 228, label: "temperature" }],
  sections: [{ k: "tp", t: "Test points", n: "" }, { k: "ana", t: "Why silicon carbide", n: "" }],
  cards: [
    { id: "tp1", tp: 1, s: "tp", d: "ph", dn: "transfer", t: "Transfer curves at 25, 100 and 175 °C", x: "I_D vs V_GS at V_DS = 10 V. V_t falls as temperature rises; the curves cross at the temperature-compensation point.", eq: "V<sub>t</sub> ≈ 4 V + 0.8 V·(D<sub>it</sub>/10¹²) − 6 mV/K·ΔT,&nbsp; µ<sub>ch</sub> ∝ T<sup>+0.9</sup>/(1 + D<sub>it</sub>/D<sub>0</sub>)" },
    { id: "tp2", tp: 2, s: "tp", d: "rf", dn: "output", t: "Output curves", x: "I_D vs V_DS at V_GS = 10, 14, 18 and 20 V. Marker: operating point.", eq: "R<sub>on</sub> = R<sub>ch</sub> + R<sub>JFET</sub> + R<sub>drift</sub> + R<sub>sub</sub>", h: "tall" },
    { id: "tp3", tp: 3, s: "tp", d: "dc", dn: "blocking", t: "Drift layer field: SiC vs Si", x: "Field profile when blocking. SiC: 10 µm at 8×10¹⁵ cm⁻³. Silicon for the same voltage would need ~100 µm of 1.5×10¹⁴ cm⁻³ (dashed, depth ÷ 10).", eq: "W<sub>drift</sub> ≈ 2BV/E<sub>c</sub>,&nbsp; E<sub>c,SiC</sub> ≈ 2.5 MV/cm ≈ 8×E<sub>c,Si</sub>" },
    { id: "tp4", tp: 4, s: "tp", d: "th", dn: "thermal", t: "On-resistance breakdown vs temperature", x: "Contributions to R_on from 25 to 200 °C. The channel gets better when hot while the drift gets worse, which flattens the total.", eq: "R<sub>drift</sub> ∝ T<sup>2.4</sup>,&nbsp; R<sub>ch</sub> ∝ 1/(µ<sub>ch</sub>(V<sub>GS</sub> − V<sub>t</sub>))" },
    { id: "a1", chip: "R–BV", s: "ana", d: "an", dn: "limits", t: "Specific on-resistance vs breakdown", x: "The unipolar limits of Si and 4H-SiC. SiC's limit is about 400× lower, which is why 1200 V MOSFETs exist in SiC but not in Si (where IGBTs are needed).", eq: "R<sub>on,sp</sub> = 4BV²/(εµE<sub>c</sub>³)" },
  ],
  foot: "Model: die area 0.1 cm², cell pitch 5 µm, channel 0.5 µm, 50 nm gate oxide, channel mobility 35 cm²/V·s degraded by D_it, drift 10 µm at 8×10¹⁵ cm⁻³ with µ = 900 cm²/V·s ∝ T^−2.4, JFET and substrate terms. Illustrative values.",
  sim(st) {
    const o = { Tj: st.Tj, Dit: st.Dit };
    const p = devParams(o), R = { p };
    R.id = idDC(st.VGS, st.VDS, o);
    R.vg = linspace(0, 20, 81);
    R.tr = [25, 100, 175].map((T) => map(R.vg, (v) => idDC(v, 10, { ...o, Tj: T })));
    R.vd = linspace(0, 10, 81);
    R.fam = [10, 14, 18, 20].map((vg) => map(R.vd, (v) => idDC(vg, v, o)));
    R.ron = ron(st.VGS, o);
    R.sic = drift(st.Vbus, "SiC"); R.si = drift(st.Vbus, "Si");
    R.Ts = linspace(25, 200, 36);
    R.parts = map(R.Ts, (T) => ron(st.VGS, { ...o, Tj: T }) * 1000);
    R.drift = map(R.Ts, (T) => devParams({ ...o, Tj: T }).Rd * 1000);
    R.jf = map(R.Ts, (T) => (devParams({ ...o, Tj: T }).Rjfet + 0.001) * 1000);
    R.bv = logspace(2, 4, 80);
    return R;
  },
  render(R, api) {
    const { st, C } = api, p = R.p;
    const rch = Math.max(0, R.ron - p.Rd - p.Rjfet - p.Rs);
    api.status([["R_on", (R.ron * 1000).toFixed(1) + " mΩ", ""], ["V_t", p.Vt.toFixed(2) + " V", p.Vt < 2 ? "warn" : ""], ["Channel mobility", p.muCh.toFixed(1) + " cm²/V·s", ""],
      ["Blocking field", (R.sic.Emax / 1e6).toFixed(2) + " MV/cm", R.sic.Emax > EC_SIC ? "warn" : "good"], ["I_D", fSI(R.id, "A"), ""], ["Channel share of R_on", ((rch / R.ron) * 100).toFixed(0) + " %", ""]]);
    api.q(".sictxt").textContent = `1200 V, ${(R.ron * 1000).toFixed(1)} mΩ at ${st.Tj} °C`;
    api.plot("tp1", { xmin: 0, xmax: 20, ymin: 0, xlabel: "V_GS (V)", ylabel: "I_D (A)", legend: true, series: R.tr.map((y, i) => ({ x: R.vg, y, color: [C.opt, C.dc, C.heat][i], w: 1.8, label: ["25 °C", "100 °C", "175 °C"][i] })), vlines: [{ x: st.VGS, color: C.ink, dash: [2, 3] }] });
    api.ro("tp1", [["V_t at T_j", p.Vt.toFixed(2) + " V"], ["I_D at V_GS, 10 V", fSI(idDC(st.VGS, 10, { Tj: st.Tj, Dit: st.Dit }), "A")]]);
    api.plot("tp2", { xmin: 0, xmax: 10, ymin: 0, xlabel: "V_DS (V)", ylabel: "I_D (A)", series: R.fam.map((y, i) => ({ x: R.vd, y, color: i === 2 ? C.ink : C.muted, w: i === 2 ? 2 : 1.2 })), labels: [10, 14, 18, 20].map((vg, i) => ({ x: 9.9, y: R.fam[i][80], text: vg + " V", align: "right", dy: -7 })), points: [{ x: st.VDS, y: R.id, color: C.rf }] });
    api.ro("tp2", [["R_on at V_GS", (R.ron * 1000).toFixed(1) + " mΩ"], ["Conduction loss at 40 A", (40 * 40 * R.ron).toFixed(0) + " W"]]);
    const y = linspace(0, 12, 121);
    const fld = (D, scale) => map(y, (yy) => { const yc = (yy * scale) * 1e-4; return yc > D.W * 1e-4 ? 0 : Math.max(0, D.Emax - D.a * yc) / 1e6; });
    api.plot("tp3", { xmin: 0, xmax: 12, ymin: 0, xlabel: "depth (µm; Si curve compressed ×10)", ylabel: "E (MV/cm)", legend: true, series: [{ x: y, y: fld(R.sic, 1), color: C.dc, w: 2.2, fill: C.dc, label: "SiC, 10 µm" }, { x: y, y: fld(R.si, 10), color: C.muted, w: 1.6, dash: [4, 3], label: "Si, 100 µm" }], hlines: [{ y: EC_SIC / 1e6, color: C.bad, dash: [3, 3], label: "E_c SiC" }, { y: EC_SI / 1e6, color: C.muted, dash: [1, 3], label: "E_c Si" }] });
    api.ro("tp3", [["SiC E_max", (R.sic.Emax / 1e6).toFixed(2) + " MV/cm", R.sic.Emax > EC_SIC ? "warn" : "good"], ["Si E_max", (R.si.Emax / 1e6).toFixed(2) + " MV/cm", R.si.Emax > EC_SI ? "warn" : ""], ["SiC punch-through", R.sic.pt ? "yes" : "no"]]);
    api.plot("tp4", { xmin: 25, xmax: 200, ymin: 0, xlabel: "T_j (°C)", ylabel: "R (mΩ)", legend: true, series: [{ x: R.Ts, y: R.parts, color: C.ink, w: 2.2, label: "total" }, { x: R.Ts, y: R.drift, color: C.dc, w: 1.6, label: "drift" }, { x: R.Ts, y: R.jf, color: C.ph, w: 1.4, dash: [3, 3], label: "JFET + source" }, { x: R.Ts, y: map(R.Ts, (T, i) => Math.max(0, R.parts[i] - R.drift[i] - R.jf[i])), color: C.opt, w: 1.6, label: "channel" }], vlines: [{ x: st.Tj, color: C.ink, dash: [2, 3] }] });
    api.ro("tp4", [["R_ch", (rch * 1000).toFixed(1) + " mΩ"], ["R_drift", (p.Rd * 1000).toFixed(1) + " mΩ"], ["R_JFET", (p.Rjfet * 1000).toFixed(1) + " mΩ"]]);
    const lim = (Ec, mu, eps) => map(R.bv, (b) => (4 * b * b) / (eps * eps0 * mu * Math.pow(Ec, 3)) * 1000);
    api.plot("a1", { xlog: true, ylog: true, xmin: 100, xmax: 1e4, ymin: 1e-3, ymax: 1e4, xlabel: "BV (V)", ylabel: "R_on,sp (mΩ·cm²)", legend: true, series: [{ x: R.bv, y: lim(EC_SI, 1350, 11.7), color: C.ink, w: 2, label: "Si limit" }, { x: R.bv, y: lim(EC_SIC, 900, 9.7), color: C.ok, w: 2, label: "4H-SiC limit" }], points: [{ x: 1200, y: R.ron * AREA * 1000, color: C.dc, label: "this device" }] });
    api.ro("a1", [["This device", (R.ron * AREA * 1000).toFixed(2) + " mΩ·cm²"], ["Si limit at 1200 V", ((4 * 1200 * 1200) / (11.7 * eps0 * 1350 * Math.pow(EC_SI, 3)) * 1000).toFixed(0) + " mΩ·cm²"]]);
  },
};

export default { atomic, bench };
