// Finds every <div class="sim" data-sim="<device>" data-view="atomic|bench"> on the page,
// loads assets/js/devices/<device>.js and mounts the requested simulation.
// Simulations only animate while they are on screen and in a visible tab.
import { mountBench } from "./lib/bench.js";
import { mountAtomic } from "./lib/atomic.js";

const MOUNT = { bench: mountBench, atomic: mountAtomic };

async function mount(el) {
  if (el.dataset.mounted) return;
  el.dataset.mounted = "1";
  const id = el.dataset.sim, view = el.dataset.view || "bench";
  try {
    const mod = await import(new URL(`./devices/${id}.js`, import.meta.url));
    const def = mod.default[view];
    if (!def) throw new Error(`device "${id}" has no "${view}" simulation`);
    el.innerHTML = "";
    const inst = MOUNT[view](el, def);
    el._sim = inst;
    watchVisibility(el, inst);
  } catch (err) {
    console.error(err);
    el.innerHTML = `<p class="sim-loading">Could not load this simulation (${String(err.message || err)}).</p>`;
  }
}

function watchVisibility(el, inst) {
  const io = new IntersectionObserver((entries) => {
    for (const e of entries) inst.setVisible(e.isIntersecting && !el.closest("[hidden]"));
  });
  io.observe(el);
  window.addEventListener("s4a:tab", () => {
    const vis = !el.closest("[hidden]");
    inst.setVisible(vis);
    if (vis) inst.refresh();
  });
  window.addEventListener("s4a:theme", () => inst.refresh());
  window.addEventListener("resize", () => inst.refresh());
}

const sims = [...document.querySelectorAll(".sim[data-sim]")];
for (const el of sims) {
  if (el.hasAttribute("data-lazy") && el.closest("[hidden]")) {
    // mount the hidden tab the first time it is shown
    const once = () => { if (!el.closest("[hidden]")) { window.removeEventListener("s4a:tab", once); mount(el); } };
    window.addEventListener("s4a:tab", once);
  } else mount(el);
}
