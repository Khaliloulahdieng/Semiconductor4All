// Site shell: dark-mode toggle and the simulation tabs on device pages.
const root = document.documentElement;

function currentTheme() {
  if (root.dataset.theme) return root.dataset.theme;
  return matchMedia("(prefers-color-scheme: dark)").matches ? "dark" : "light";
}
document.querySelector(".theme-btn")?.addEventListener("click", () => {
  const next = currentTheme() === "dark" ? "light" : "dark";
  root.dataset.theme = next;
  try { localStorage.setItem("s4a-theme", next); } catch (e) { /* storage blocked: theme lasts for this page only */ }
  window.dispatchEvent(new CustomEvent("s4a:theme"));
});

const tabs = [...document.querySelectorAll(".sim-tabs [role=tab]")];
function selectTab(btn, focus) {
  for (const t of tabs) {
    const on = t === btn;
    t.setAttribute("aria-selected", on);
    t.tabIndex = on ? 0 : -1;
    document.getElementById(t.getAttribute("aria-controls")).hidden = !on;
  }
  if (focus) btn.focus();
  history.replaceState(null, "", "#" + btn.dataset.tab);
  window.dispatchEvent(new CustomEvent("s4a:tab", { detail: btn.dataset.tab }));
}
tabs.forEach((t, i) => {
  t.addEventListener("click", () => selectTab(t));
  t.addEventListener("keydown", (e) => {
    if (e.key !== "ArrowRight" && e.key !== "ArrowLeft") return;
    selectTab(tabs[(i + (e.key === "ArrowRight" ? 1 : tabs.length - 1)) % tabs.length], true);
  });
});
const fromHash = tabs.find((t) => "#" + t.dataset.tab === location.hash);
if (fromHash) selectTab(fromHash);
