---
tech: cmos
title: "CMOS / FD-SOI"
description: "Devices and interactive simulations for CMOS / FD-SOI."
---
FD-SOI is the planar answer to the end of easy scaling: an ultra-thin, undoped silicon film sits on a buried oxide (BOX), so the gate controls the whole channel and the substrate under the BOX becomes a second, back gate.
