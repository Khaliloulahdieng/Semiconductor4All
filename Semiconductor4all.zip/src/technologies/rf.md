---
tech: rf
title: "RF"
description: "Devices and interactive simulations for RF."
---
An RF front-end switches the antenna between transmit and receive paths and amplifies weak signals. RF-SOI dominates switches: stacked transistors share the voltage swing, and a trap-rich layer under the BOX keeps the substrate from adding loss and distortion.
