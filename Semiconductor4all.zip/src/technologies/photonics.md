---
tech: photonics
title: "Silicon Photonics"
description: "Devices and interactive simulations for Silicon Photonics."
---
Silicon is transparent at 1310 and 1550 nm, so a CMOS-like process can carve waveguides, splitters and modulators. Changing the free-carrier density in a PN junction shifts the refractive index (plasma dispersion), which is how electrical bits become optical ones.
