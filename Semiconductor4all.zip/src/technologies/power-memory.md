---
tech: power-memory
title: "Power & Memory"
description: "Devices and interactive simulations for Power & Memory."
---
Power devices trade on-resistance against blocking voltage through a lightly doped drift region. Memory devices store a bit as charge or as the state of a latch.
