---
deviceId: cmos-inverter
tech: cmos
order: 10
title: CMOS inverter
summary: "The simplest logic gate: an nMOS pulls the output down, a pMOS pulls it up, and one of them is always off. Switching speed, noise margins and energy per operation all start here."
specs: ["nMOS + pMOS", "twin well", "C·V² energy", "noise margins"]
thumb: '<svg viewBox="0 0 160 80"><rect x="0" y="44" width="80" height="36" fill="var(--m-p)"/><rect x="80" y="44" width="80" height="36" fill="var(--m-n)"/><rect x="6" y="44" width="22" height="8" fill="var(--m-np)"/><rect x="52" y="44" width="22" height="8" fill="var(--m-np)"/><rect x="86" y="44" width="22" height="8" fill="var(--m-pp)"/><rect x="132" y="44" width="22" height="8" fill="var(--m-pp)"/><rect x="28" y="30" width="24" height="12" fill="var(--m-poly)"/><rect x="108" y="30" width="24" height="12" fill="var(--m-poly)"/><path d="M40 30V18h80v12M63 44V10h34v34" fill="none" stroke="currentColor" stroke-width="1.5"/><g font-family="monospace" font-size="7" fill="currentColor" text-anchor="middle"><text x="80" y="16">in</text><text x="80" y="8">out</text><text x="40" y="72">nMOS</text><text x="120" y="72">pMOS</text></g></svg>'
---

## What it is

A CMOS inverter connects a pMOS from V_DD to the output and an nMOS from the output to ground, with both gates tied to the input. With the input high, the nMOS is on and the pMOS off, so the output is pulled to 0. With the input low, it is the other way round. In either steady state one transistor is off, so almost no current flows: that is why CMOS took over digital electronics.

## Key equations

<div class="eq">I<sub>n</sub>(V<sub>M</sub>) = I<sub>p</sub>(V<sub>M</sub>) defines the switching threshold V<sub>M</sub>,&nbsp; NM<sub>L</sub> = V<sub>IL</sub> − V<sub>OL</sub>,&nbsp; NM<sub>H</sub> = V<sub>OH</sub> − V<sub>IH</sub><br>t<sub>p</sub> ≈ C<sub>L</sub>V<sub>DD</sub>/(2I<sub>on</sub>),&nbsp; E<sub>switch</sub> ≈ C<sub>L</sub>V<sub>DD</sub>²</div>

Holes are about half as mobile as electrons, so the pMOS is usually made about twice as wide to centre V_M at V_DD/2 and balance rise and fall times.

## Things to look for

- **Atomic physics:** sweep the input and watch the electron channel (nMOS, left) and the hole channel (pMOS, right) trade places.
- **Bench:** drop V_DD toward 0.45 V. The energy per cycle falls with V_DD², but the delay grows quickly as V_DD approaches V_t.
