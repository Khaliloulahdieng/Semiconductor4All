---
deviceId: finfet
tech: cmos
order: 5
title: FinFET
summary: A transistor built on a thin vertical silicon fin, with the gate wrapped around three sides. Better gate control than a planar device lets gate lengths shrink below 20 nm without leaking.
specs: ["7–16 nm class", "tri-gate", "fin width 5–15 nm", "quantised width"]
thumb: '<svg viewBox="0 0 160 80"><rect x="0" y="62" width="160" height="18" fill="var(--m-p)"/><rect x="0" y="50" width="160" height="12" fill="var(--m-ox)"/><g fill="var(--m-si)" stroke="var(--edge)"><rect x="46" y="18" width="12" height="44"/><rect x="102" y="18" width="12" height="44"/></g><path d="M30 50V10h100v40h-10V14h-4v36h-46V14h-4v36z" fill="var(--m-metal)" opacity=".85"/><g fill="var(--e)"><circle cx="48.5" cy="30" r="1.5"/><circle cx="55.5" cy="38" r="1.5"/><circle cx="104.5" cy="34" r="1.5"/><circle cx="111.5" cy="26" r="1.5"/></g><g font-family="monospace" font-size="7" fill="currentColor" text-anchor="middle"><text x="80" y="8">gate wraps the fins</text><text x="80" y="58">STI</text></g></svg>'
---

## What it is

As planar transistors shrank below about 25 nm, the drain began to control the channel almost as much as the gate: threshold voltages rolled off, sub-threshold slopes degraded and off-state leakage exploded. The **FinFET** (Intel's *tri-gate*, 2011) fixes this by turning the channel on its side. The silicon becomes a thin vertical **fin**, and the gate wraps its two sidewalls and top.

With gates on both sides of a fin only 5–10 nm wide, no part of the channel is far from a gate. The electrostatics are described by a **natural length**:

<div class="eq">λ ≈ √(ε<sub>Si</sub>·W<sub>fin</sub>·t<sub>ox</sub> / (2ε<sub>ox</sub>))</div>

Short-channel effects scale as e<sup>−L/2λ</sup>. A thin fin means a small λ, so a short gate still behaves like a long one.

## The catch: quantised width

A planar transistor can have any width. A FinFET's effective width is a whole number of fins, **W<sub>eff</sub> = n<sub>fin</sub>(2H<sub>fin</sub> + W<sub>fin</sub>)**. Designers size circuits in steps of one fin.

## Things to look for

- **Atomic physics:** with a 5 nm fin, the band bending reaches the fin centre (volume inversion). With 15 nm, the centre lags and DIBL grows on the channel cut.
- **Bench:** shorten the gate to 12 nm and compare thin and fat fins on the V_t roll-off card.
