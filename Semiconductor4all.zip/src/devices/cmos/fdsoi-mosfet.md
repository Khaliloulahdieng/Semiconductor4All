---
deviceId: fdsoi-mosfet
tech: cmos
order: 1
title: FD-SOI MOSFET
summary: A planar transistor on an ultra-thin silicon film over a buried oxide. The substrate under the oxide becomes a second gate that tunes the threshold voltage after fabrication.
specs: ["28 nm-class UTBB", "7 nm film", "25 nm BOX", "back-gate bias"]
thumb: '<svg viewBox="0 0 160 80"><rect x="10" y="56" width="140" height="20" fill="var(--m-pp)"/><rect x="10" y="44" width="140" height="12" fill="var(--m-box)"/><rect x="10" y="36" width="50" height="8" fill="var(--m-np)"/><rect x="60" y="36" width="40" height="8" fill="var(--m-si)"/><rect x="100" y="36" width="50" height="8" fill="var(--m-np)"/><rect x="60" y="32" width="40" height="4" fill="var(--m-ox)"/><rect x="60" y="14" width="40" height="18" fill="var(--m-metal)"/><g fill="var(--e)"><circle cx="66" cy="38.5" r="1.6"/><circle cx="74" cy="38" r="1.6"/><circle cx="82" cy="38.6" r="1.6"/><circle cx="90" cy="38" r="1.6"/></g><g font-family="monospace" font-size="7" fill="currentColor" text-anchor="middle"><text x="80" y="25">G</text><text x="35" y="31">S</text><text x="125" y="31">D</text><text x="80" y="53">BOX</text><text x="80" y="70">back gate</text></g></svg>'
---

## What it is

A fully depleted silicon-on-insulator (FD-SOI) transistor is a planar MOSFET built in a silicon film only a few nanometres thick, sitting on a buried oxide (BOX). The film is left undoped, so it is **fully depleted**: there are no free carriers in it until the gate pulls electrons in.

Three things follow from that thin film:

- **Good electrostatic control.** The gate sees the whole channel, so short-channel effects (DIBL, sub-threshold slope degradation) stay small without heavy channel doping.
- **Low variability.** No channel dopants means no random dopant fluctuation.
- **A back gate.** The doped ground plane under the thin BOX couples to the channel through the oxide. Biasing it shifts the threshold voltage by tens of millivolts per volt, so a chip can trade speed for leakage while it runs.

## Key equations

Threshold voltage with back bias, to first order:

<div class="eq">V<sub>t</sub> ≈ V<sub>t0</sub> − γ·V<sub>BB</sub>,&nbsp; γ ≈ (C<sub>BOX</sub> ∥ C<sub>Si</sub>)/C<sub>ox</sub> ≈ 70–85 mV/V</div>

Sub-threshold current falls by one decade every <b>SS = n·(kT/q)·ln 10</b> of gate voltage, about 65–75 mV/dec here.

## Things to look for

- In **Atomic physics**, the vertical cut shows the band bending from the gate through the film, the BOX and into the ground plane. Forward back bias pulls the electron layer down toward the back interface.
- On the **bench**, compare the three grey Id–Vg curves: back bias shifts the curve sideways without changing its slope.
