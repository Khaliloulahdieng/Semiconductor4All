---
deviceId: bulk-mosfet
tech: cmos
order: 9
title: Bulk n-MOSFET
summary: The classic planar transistor on a doped silicon substrate. Gate voltage takes the surface from accumulation to depletion to inversion; the substrate acts as a fourth terminal through the body effect.
specs: ["planar", "n⁺ poly / 2 nm oxide", "body effect", "65 nm class"]
thumb: '<svg viewBox="0 0 160 80"><rect x="0" y="40" width="160" height="40" fill="var(--m-p)"/><rect x="10" y="40" width="40" height="9" fill="var(--m-np)"/><rect x="110" y="40" width="40" height="9" fill="var(--m-np)"/><rect x="50" y="37" width="60" height="3" fill="var(--m-ox)"/><rect x="50" y="20" width="60" height="17" fill="var(--m-poly)"/><rect x="50" y="40" width="60" height="14" fill="none" stroke="var(--edge)" stroke-dasharray="3 2"/><g font-family="monospace" font-size="7" fill="var(--h)" text-anchor="middle"><text x="62" y="50">−</text><text x="74" y="47">−</text><text x="86" y="51">−</text><text x="98" y="47">−</text></g><g font-family="monospace" font-size="7" fill="currentColor" text-anchor="middle"><text x="80" y="31">gate</text><text x="80" y="72">p-substrate (body)</text></g></svg>'
---

## What it is

For forty years almost every chip was built from this device: an n⁺-poly gate on a thin oxide over a p-type silicon substrate, with n⁺ source and drain on either side. The surface under the gate goes through three regimes as V_G rises:

1. **Accumulation** (V_G < V_FB): holes pile up at the surface.
2. **Depletion**: holes are pushed away, leaving a layer of fixed, negatively charged acceptor ions.
3. **Inversion** (V_G > V_t): the surface potential reaches about 2φ_F and a thin layer of electrons forms. That layer is the channel.

## Key equations

<div class="eq">V<sub>t</sub> = V<sub>FB</sub> + 2φ<sub>F</sub> + γ√(2φ<sub>F</sub> + V<sub>SB</sub>),&nbsp; γ = √(2qε<sub>Si</sub>N<sub>A</sub>)/C<sub>ox</sub>,&nbsp; φ<sub>F</sub> = (kT/q)ln(N<sub>A</sub>/n<sub>i</sub>)</div>

The substrate is a fourth terminal. Reverse-biasing it (V_SB > 0) deepens the depletion region and raises V_t, which is the **body effect**. In short devices, source and drain depletion regions share the channel charge, so V_t falls and the drain lowers the source barrier (DIBL). Heavy channel doping fights this but costs mobility and junction leakage; that is why FD-SOI and FinFETs took over below about 28 nm.

## Things to look for

- **Atomic physics:** sweep V_G from −1 V to +1.5 V on the vertical cut and identify the three regimes in the bands and in the cross-section.
- **Bench:** compare 30 nm and 250 nm gates on the V_t roll-off card for two doping levels.
