---
deviceId: gan-hemt
tech: rf
order: 13
title: GaN HEMT
summary: A transistor whose channel is a sheet of electrons created by polarization at the AlGaN/GaN interface, with no doping needed. High electron velocity plus high breakdown voltage make it the workhorse of RF power amplifiers.
specs: ["AlGaN/GaN 2DEG", "depletion mode", "28–50 V", "several W/mm"]
thumb: '<svg viewBox="0 0 160 80"><rect x="0" y="66" width="160" height="14" fill="var(--m-hr)"/><rect x="0" y="36" width="160" height="30" fill="var(--m-ge)"/><rect x="0" y="28" width="160" height="8" fill="var(--m-box)"/><rect x="0" y="22" width="160" height="6" fill="var(--m-ox)"/><rect x="8" y="16" width="28" height="20" fill="var(--m-metal)"/><rect x="124" y="16" width="28" height="20" fill="var(--m-metal)"/><rect x="70" y="10" width="16" height="18" fill="var(--m-metal)"/><path d="M0 37.5H160" stroke="var(--e)" stroke-width="2" stroke-dasharray="2 2"/><g font-family="monospace" font-size="7" fill="currentColor" text-anchor="middle"><text x="22" y="12">S</text><text x="78" y="7">G</text><text x="138" y="12">D</text><text x="110" y="48">2DEG</text><text x="80" y="58">GaN</text></g></svg>'
---

## What it is

GaN and AlGaN are polar crystals. Where a thin AlGaN barrier sits on GaN, the difference in their spontaneous and piezoelectric polarization leaves a fixed positive sheet charge of about 10¹³ cm⁻² at the interface. That charge pulls in an equal sheet of free electrons on the GaN side: a **two-dimensional electron gas** (2DEG) a few nanometres thick, with no dopant atoms in it to scatter the electrons.

The result is a channel with high electron density, high mobility (~1800 cm²/V·s) and high saturation velocity, in a material with a 3.4 eV band gap that withstands fields above 3 MV/cm. A Schottky gate on the barrier depletes the 2DEG at negative voltage, so the device is **normally on** (depletion mode).

## Key equations

<div class="eq">q·n<sub>s</sub> ≈ σ<sub>pol</sub> − (ε/d)(qφ<sub>B</sub> − ΔE<sub>c</sub> − qV<sub>G</sub>),&nbsp; I<sub>max</sub> ≈ q·n<sub>s</sub>·v<sub>sat</sub>·W<br>P<sub>sat</sub> ≈ (V<sub>DD</sub> − V<sub>knee</sub>)·I<sub>max</sub>/8</div>

## Things to look for

- **Atomic physics:** at V_G = 0 the conduction band dips below the Fermi level right under the barrier; drive V_G to −5 V and the well empties.
- **Bench:** compare 28 V and 48 V supplies on the power card, then heat the base plate to 150 °C and watch the output curves droop.
