---
deviceId: rfsoi-switch
tech: rf
order: 3
title: RF-SOI antenna switch
summary: Stacks of SOI transistors route the antenna between transmit and receive paths. Low on-resistance, low off-capacitance, and a trap-rich substrate keep loss and distortion down.
specs: ["stacked nFETs", "R_on·C_off ≈ 120 fs", "trap-rich HR-SOI", "0.5–8 GHz"]
thumb: '<svg viewBox="0 0 160 80"><path d="M6 30h22M132 30h22" stroke="var(--rf)" stroke-width="2.5"/><g fill="color-mix(in srgb,var(--ph) 18%,transparent)" stroke="var(--ph)"><rect x="28" y="22" width="20" height="16" rx="2"/><rect x="54" y="22" width="20" height="16" rx="2"/><rect x="80" y="22" width="20" height="16" rx="2"/><rect x="106" y="22" width="20" height="16" rx="2"/></g><path d="M48 30h6M74 30h6M100 30h6M126 30h6" stroke="var(--rf)" stroke-width="2"/><rect x="0" y="48" width="160" height="8" fill="var(--m-box)"/><rect x="0" y="56" width="160" height="8" fill="var(--m-trap)"/><rect x="0" y="64" width="160" height="16" fill="var(--m-hr)"/><g font-family="monospace" font-size="7" fill="currentColor" text-anchor="middle"><text x="77" y="16">N × FET stack</text><text x="80" y="62">trap-rich</text></g></svg>'
---

## What it is

Every phone has an antenna switch that connects the antenna to one of many transmit and receive paths. It must pass up to a few watts with a fraction of a dB of loss when **ON**, block it with 30–40 dB of isolation when **OFF**, and add almost no harmonics. RF-SOI does this with plain nMOS transistors:

- The **buried oxide** removes junction capacitance to the substrate, so the OFF transistor is a small, linear capacitor.
- **Stacking** N transistors in series splits a 20–30 V peak swing into a few volts per device.
- A **high-resistivity handle** with a **trap-rich layer** under the BOX keeps the substrate from conducting. Without it, fixed charge in the oxide pulls in a thin electron layer (parasitic surface conduction). The RF signal modulates that layer, which causes loss and second-harmonic distortion.

## Key equations

<div class="eq">R<sub>on</sub>·C<sub>off</sub> (fs) is the technology figure of merit,&nbsp; f<sub>c</sub> = 1/(2πR<sub>on</sub>C<sub>off</sub>)<br>V<sub>pk</sub> = √(2PZ<sub>0</sub>): 35 dBm on 50 Ω → 17.8 V peak<br>N ≥ V<sub>pk</sub>/V<sub>max,FET</sub> (plus margin for uneven division)</div>

## Things to look for

- **Atomic physics:** without trap-rich, an electron layer sits under the BOX and changes with the RF swing. Tick trap-rich and it is gone.
- **Bench:** isolate 35 dBm with 4 FETs and the first transistor exceeds its breakdown; raise N until the stack survives. Then compare H2 with and without trap-rich.
