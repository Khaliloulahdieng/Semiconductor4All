---
deviceId: sige-hbt
tech: rf
order: 7
title: SiGe HBT
summary: A bipolar transistor with a thin silicon-germanium base. Grading the germanium builds in a field that rushes electrons across the base, pushing f_T and f_max past 300 GHz in a silicon process.
specs: ["npn BiCMOS", "graded-Ge base", "20 nm base", "f_T > 200 GHz"]
thumb: '<svg viewBox="0 0 160 80"><rect x="0" y="66" width="160" height="14" fill="var(--m-np)"/><rect x="20" y="36" width="120" height="30" fill="var(--m-n)"/><rect x="20" y="30" width="120" height="6" fill="var(--m-ge)"/><rect x="60" y="12" width="40" height="18" fill="var(--m-np)"/><rect x="20" y="22" width="34" height="8" fill="var(--m-pp)"/><rect x="106" y="22" width="34" height="8" fill="var(--m-pp)"/><path d="M80 34v26" stroke="var(--e)" stroke-width="2"/><g font-family="monospace" font-size="7" fill="currentColor" text-anchor="middle"><text x="80" y="23">E</text><text x="37" y="19">B</text><text x="123" y="19">B</text><text x="120" y="52">C</text><text x="80" y="35">SiGe</text></g></svg>'
---

## What it is

A bipolar transistor amplifies by injecting electrons from an n⁺ emitter into a thin p-type base. Most cross it and are collected; a few recombine and form the base current. Speed is limited by how long electrons take to cross the base and how fast the junction capacitances charge.

In a **SiGe heterojunction bipolar transistor (HBT)**, the base is a strained Si₁₋ₓGeₓ layer. Germanium narrows the band gap, and it does two useful things:

1. **More injection.** A smaller gap at the emitter edge raises n<sub>i</sub>² in the base, so more collector current flows for the same V_BE (higher β, or room to dope the base more heavily and lower its resistance).
2. **A built-in drift field.** Grading the Ge from low at the emitter to high at the collector tilts the conduction band across the base. Electrons drift instead of diffuse, cutting the base transit time several-fold.

## Key equations

<div class="eq">I<sub>C</sub> = I<sub>S</sub>e<sup>V<sub>BE</sub>/U<sub>T</sub></sup>,&nbsp; τ<sub>B</sub> = (W<sub>B</sub>²/D<sub>n</sub>)(1/η)[1 − (1 − e<sup>−η</sup>)/η],&nbsp; η = ΔE<sub>g,grade</sub>/kT<br>1/(2πf<sub>T</sub>) = τ<sub>F</sub> + (C<sub>je</sub>+C<sub>bc</sub>)kT/(qI<sub>C</sub>),&nbsp; f<sub>max</sub> = √(f<sub>T</sub>/(8πr<sub>b</sub>C<sub>bc</sub>))</div>

## Things to look for

- **Atomic physics:** set the Ge to 0 % and then 25 %: the conduction band in the base goes from flat to sloped.
- **Bench:** find the peak f_T, then push the current into the Kirk region and watch f_T collapse. Compare with the dashed silicon-base curves.
