---
deviceId: microring-modulator
tech: photonics
order: 11
title: Micro-ring modulator
summary: A ring waveguide only a few microns across, side-coupled to a bus. Its resonance is a sharp notch, so a tiny voltage-driven index change switches the light on and off with very little power and area.
specs: ["R = 5 µm", "Q ≈ 9 000", "depletion PN", "heater tuning"]
thumb: '<svg viewBox="0 0 160 80"><path d="M0 70H160" stroke="var(--opt)" stroke-width="3"/><circle cx="80" cy="38" r="26" fill="none" stroke="var(--opt)" stroke-width="3"/><circle cx="80" cy="38" r="31" fill="none" stroke="var(--rf)" stroke-width="1.5" stroke-dasharray="4 3"/><circle cx="80" cy="38" r="20" fill="none" stroke="var(--heat)" stroke-width="1.5" opacity=".7"/><g font-family="monospace" font-size="7" fill="currentColor" text-anchor="middle"><text x="80" y="41">ring</text><text x="140" y="66">bus</text></g></svg>'
---

## What it is

Light in the bus waveguide couples into a nearby ring. At wavelengths where the ring's circumference holds a whole number of wavelengths, light builds up in the ring and is lost there, so the bus transmission drops in a sharp notch. Shifting that notch by a fraction of its width, with a PN junction in the ring, turns the transmitted light on and off.

## Key equations

<div class="eq">λ<sub>res</sub> = n<sub>eff</sub>·2πR/m,&nbsp; FSR = λ²/(n<sub>g</sub>·2πR),&nbsp; Δλ<sub>FWHM</sub> = λ/Q<sub>L</sub><br>T(δ) = 1 − (1 − T<sub>min</sub>)/(1 + (2δ/Δλ<sub>FWHM</sub>)²),&nbsp; τ<sub>ph</sub> = Q<sub>L</sub>λ/(2πc)</div>

A ring modulator is about 100× smaller than a Mach-Zehnder and needs far less drive energy (a few fJ/bit). The price is sensitivity: the resonance moves about 80 pm per kelvin, roughly half a linewidth, so every ring needs a heater and a feedback loop to stay locked to the laser.

## Things to look for

- **Atomic physics:** the PN junction is the same physics as in the MZM, but the shift it produces is now compared with a linewidth of only ~170 pm.
- **Bench:** put the laser at the bottom of the notch and the modulation almost vanishes. Then raise Q to 15 000 and push the bit rate: the eye closes because photons stay in the ring too long.
