---
deviceId: ge-photodiode
tech: photonics
order: 6
title: Ge photodiode
summary: A germanium PIN diode grown on a silicon waveguide. Silicon is transparent at telecom wavelengths; germanium absorbs them, turning light back into current at tens of gigahertz.
specs: ["Ge-on-Si PIN", "waveguide-coupled", "≈ 1 A/W", "50–100 Gb/s"]
thumb: '<svg viewBox="0 0 160 80"><rect x="0" y="62" width="160" height="18" fill="var(--m-box)"/><rect x="10" y="50" width="140" height="12" fill="var(--m-pp)"/><rect x="45" y="22" width="70" height="28" fill="var(--m-ge)"/><rect x="45" y="16" width="70" height="6" fill="var(--m-np)"/><ellipse cx="80" cy="53" rx="40" ry="7" fill="var(--opt)" opacity=".35"/><g fill="var(--e)"><circle cx="66" cy="30" r="1.6"/><circle cx="88" cy="26" r="1.6"/></g><g fill="none" stroke="var(--h)" stroke-width="1.2"><circle cx="72" cy="42" r="1.6"/><circle cx="96" cy="40" r="1.6"/></g><g font-family="monospace" font-size="7" fill="currentColor" text-anchor="middle"><text x="80" y="36">i-Ge</text><text x="130" y="58">p⁺ Si</text></g></svg>'
---

## What it is

Silicon photonics needs a detector at the end of every link. Silicon itself is useless here: its band gap (1.12 eV) is larger than the photon energy at 1310 nm (0.95 eV) and 1550 nm (0.80 eV), so the light goes straight through. **Germanium** has a direct gap near 0.8 eV and absorbs strongly up to about 1600 nm. It can be grown epitaxially on silicon in a CMOS-compatible flow.

In a **waveguide-coupled** photodiode the Ge block sits on top of the silicon waveguide. Light leaks up into the Ge over a few to a few tens of microns and is absorbed. Each absorbed photon creates an electron–hole pair in the intrinsic Ge, and the built-in plus applied field sweeps them to the contacts.

## Key equations

<div class="eq">ℛ = η·qλ/(hc) = η·λ[µm]/1.24 A/W,&nbsp; η = 1 − e<sup>−ΓαL</sup><br>f<sub>tr</sub> ≈ 0.45·v<sub>sat</sub>/W<sub>i</sub>,&nbsp; f<sub>RC</sub> = 1/(2πRC),&nbsp; f<sub>3dB</sub> = (f<sub>tr</sub><sup>−2</sup> + f<sub>RC</sub><sup>−2</sup>)<sup>−½</sup></div>

A thinner intrinsic layer is faster to cross but has more capacitance. A longer Ge section absorbs more light but adds capacitance too.

## Things to look for

- **Atomic physics:** compare the Ge and Si band gaps on the band diagram, and watch photogenerated electrons drift up and holes drift down.
- **Bench:** move the wavelength past 1590 nm and watch responsivity fall off the band edge; push the data rate to 100 Gb/s with a 50 µm long diode and watch the eye close.
