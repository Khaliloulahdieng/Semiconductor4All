---
deviceId: mzm-modulator
tech: photonics
order: 2
title: Mach-Zehnder modulator
summary: Two silicon waveguides with PN junctions. Reverse bias sweeps carriers out of the light's path, shifting its phase; recombining the arms turns that phase into on/off light.
specs: ["depletion PN", "push-pull", "1550 nm", "25–56 Gb/s"]
thumb: '<svg viewBox="0 0 160 80"><path d="M6 40h18c10 0 10-20 22-20h68c12 0 12 20 22 20h18M24 40c10 0 10 20 22 20h68c12 0 12-20 22-20" fill="none" stroke="var(--opt)" stroke-width="3"/><rect x="52" y="14" width="56" height="12" rx="2" fill="color-mix(in srgb,var(--rf) 18%,transparent)" stroke="var(--rf)"/><rect x="52" y="54" width="56" height="12" rx="2" fill="color-mix(in srgb,var(--rf) 18%,transparent)" stroke="var(--rf)"/><g font-family="monospace" font-size="7" fill="currentColor" text-anchor="middle"><text x="80" y="22.5">PN +v</text><text x="80" y="62.5">PN −v</text><text x="80" y="43">Δφ → P</text></g></svg>'
---

## What it is

A Mach-Zehnder modulator (MZM) splits light into two waveguide arms and recombines it. If the two arms accumulate the same phase, the light adds up; if they differ by π, it cancels. Silicon has no useful electro-optic (Pockels) effect, so silicon MZMs use the **plasma-dispersion effect**: free electrons and holes lower the refractive index and add absorption.

Each arm carries a lateral PN junction through the waveguide. Under **reverse bias** the depletion region widens and pushes carriers out of the optical mode. Fewer carriers mean a higher index, and the light picks up extra phase. Driving the two arms in opposite directions (push-pull) doubles the phase difference and cancels chirp.

## Key equations

<div class="eq">Δn ≈ −(8.8×10⁻²² ΔN + 8.5×10⁻¹⁸ ΔP<sup>0.8</sup>) &nbsp;(1550 nm)<br>W = √(2ε(V<sub>bi</sub>+V<sub>R</sub>)(N<sub>A</sub>+N<sub>D</sub>)/(qN<sub>A</sub>N<sub>D</sub>))<br>P<sub>out</sub> ≈ P<sub>max</sub>·cos²(Δφ/2)</div>

Because the depletion width grows as √V, the phase law is sub-linear: efficiency drops as bias increases, while the junction capacitance falls and bandwidth rises. Choosing V_R is a trade-off between V_π and speed.

## Things to look for

- **Atomic physics:** watch the depletion region open inside the optical mode, and the quasi-Fermi levels split by qV_R.
- **Bench:** move the bias phase to 1.0π with a sine drive to see frequency doubling, or push the swing past V_R to forward-bias a junction (the PN block turns red).

The bench reuses the model of the original *SiPh MZM Test Bench*.
