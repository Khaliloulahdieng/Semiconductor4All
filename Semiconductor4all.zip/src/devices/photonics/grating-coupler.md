---
deviceId: grating-coupler
tech: photonics
order: 12
title: Grating coupler
summary: A row of shallow etched teeth that diffracts light out of the chip toward a fibre held above it. It solves the size mismatch between a 10 µm fibre mode and a 0.5 µm waveguide, and allows wafer-scale optical testing.
specs: ["Λ ≈ 610 nm", "70 nm etch", "fibre at 10°", "≈ −2 dB"]
thumb: '<svg viewBox="0 0 160 80"><rect x="0" y="52" width="160" height="18" fill="var(--m-box)"/><rect x="0" y="44" width="160" height="8" fill="var(--m-si)"/><g fill="var(--m-clad)"><rect x="50" y="44" width="6" height="3"/><rect x="62" y="44" width="6" height="3"/><rect x="74" y="44" width="6" height="3"/><rect x="86" y="44" width="6" height="3"/><rect x="98" y="44" width="6" height="3"/><rect x="110" y="44" width="6" height="3"/></g><path d="M0 48h44" stroke="var(--opt)" stroke-width="2"/><path d="M70 40 82 6M84 40 96 6M98 40 110 6" stroke="var(--opt)" stroke-width="1.5" opacity=".7"/><rect x="88" y="0" width="30" height="8" fill="var(--m-clad)" stroke="var(--edge)" transform="rotate(10 103 4)"/><g font-family="monospace" font-size="7" fill="currentColor" text-anchor="middle"><text x="30" y="40">waveguide</text><text x="130" y="20">fibre</text></g></svg>'
---

## What it is

A single-mode fibre carries light in a mode about 10 µm across; a silicon waveguide confines it to 0.5 × 0.22 µm. A **grating coupler** bridges the two from above: a periodic set of shallow etched teeth along an expanded waveguide scatters a little light at every tooth. When the period is right, all scattered waves leave in phase at one angle, forming a beam that matches a fibre held a few degrees from vertical.

## Key equations

<div class="eq">sin θ = n<sub>eff</sub> − λ/Λ &nbsp;(first-order phase matching)<br>P(x) = P<sub>0</sub>e<sup>−2αx</sup>,&nbsp; η = D·η<sub>overlap</sub>·η<sub>angle</sub></div>

Three things limit efficiency: **directionality** D (light also goes down into the substrate; the BOX thickness sets how much reflects back up), **mode overlap** (an exponential emission profile matches a Gaussian fibre mode at best ~80 %), and the **angle match**, which is what limits the bandwidth to a few tens of nm.

## Things to look for

- **Atomic physics:** change the period and the wavelength and watch the beam angle swing (phase-matching view).
- **Bench:** set the BOX to 1.6 µm for destructive interference, then misalign the fibre by 5 µm and read the tolerance card.
