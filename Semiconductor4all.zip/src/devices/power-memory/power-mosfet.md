---
deviceId: power-mosfet
tech: power-memory
order: 4
title: Trench power MOSFET
summary: A vertical transistor that switches tens of amps and blocks tens of volts. A lightly doped drift region holds the voltage; a trench gate packs millions of channels into each square millimetre.
specs: ["80 V class", "trench gate", "5 µm drift", "≈ 6 mΩ"]
thumb: '<svg viewBox="0 0 160 80"><rect x="0" y="4" width="160" height="5" fill="var(--m-metal)"/><rect x="0" y="9" width="160" height="5" fill="var(--m-np)"/><rect x="0" y="14" width="160" height="12" fill="var(--m-pp)"/><rect x="0" y="26" width="160" height="38" fill="var(--m-n)"/><rect x="0" y="64" width="160" height="8" fill="var(--m-np)"/><rect x="0" y="72" width="160" height="5" fill="var(--m-metal)"/><g fill="var(--m-ox)"><rect x="34" y="9" width="16" height="26"/><rect x="110" y="9" width="16" height="26"/></g><g fill="var(--m-poly)"><rect x="37" y="11" width="10" height="22"/><rect x="113" y="11" width="10" height="22"/></g><path d="M80 30v28" stroke="var(--e)" stroke-width="2"/><g font-family="monospace" font-size="7" fill="currentColor" text-anchor="middle"><text x="80" y="22">p-body</text><text x="140" y="48">n⁻ drift</text></g></svg>'
---

## What it is

Power MOSFETs switch the current in power supplies, motor drives and battery systems. Unlike a logic transistor, the current flows **vertically** through the wafer:

1. Electrons leave the n⁺ source at the top,
2. cross the p-body through an inversion channel along the side of the **trench gate**,
3. drift down through the lightly doped **n⁻ drift region**,
4. and leave through the n⁺ substrate and the drain metal on the back.

When the device is off, the p-body/n⁻ drift junction is reverse biased. The depletion region spreads mostly into the lightly doped drift layer, and that layer's thickness and doping set the breakdown voltage. The same layer also adds resistance when the device is on. That is the fundamental trade-off of power devices.

## Key equations

<div class="eq">BV ≈ ε E<sub>c</sub>² / (2qN<sub>D</sub>),&nbsp; W<sub>drift</sub> ≈ 2BV/E<sub>c</sub><br>R<sub>on,sp</sub> ≈ W<sub>drift</sub>/(qµN<sub>D</sub>) = 4BV²/(εµE<sub>c</sub>³) ∝ BV<sup>2.5</sup><br>E<sub>sw</sub> ≈ ½·V<sub>bus</sub>·I<sub>L</sub>·(t<sub>ri</sub> + t<sub>fv</sub>),&nbsp; t<sub>fv</sub> ≈ Q<sub>gd</sub>R<sub>g</sub>/(V<sub>drv</sub> − V<sub>pl</sub>)</div>

## Things to look for

- **Atomic physics:** push V_DS to 90 V and watch the depletion region reach deep into the drift layer; the field plot shows the peak at the junction approaching the avalanche limit.
- **Bench:** increase R_g and watch the Miller plateau stretch, which slows the drain-voltage edge and raises switching loss. Then push f_sw toward 1 MHz and see switching loss overtake conduction loss.
