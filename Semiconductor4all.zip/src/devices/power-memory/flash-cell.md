---
deviceId: flash-cell
tech: power-memory
order: 8
title: Flash memory cell
summary: A transistor with a floating gate sealed in oxide. Electrons pushed onto it by quantum tunnelling shift the threshold voltage, and that shift is the stored bit, kept for ten years without power.
specs: ["floating gate", "7 nm tunnel oxide", "FN program/erase", "10-year retention"]
thumb: '<svg viewBox="0 0 160 80"><rect x="0" y="58" width="160" height="22" fill="var(--m-p)"/><rect x="10" y="54" width="36" height="12" fill="var(--m-np)"/><rect x="114" y="54" width="36" height="12" fill="var(--m-np)"/><rect x="40" y="8" width="80" height="46" fill="var(--m-ox)"/><rect x="46" y="10" width="68" height="16" fill="var(--m-poly)"/><rect x="52" y="32" width="56" height="16" fill="var(--m-poly)"/><g fill="var(--e)"><circle cx="60" cy="40" r="1.7"/><circle cx="70" cy="37" r="1.7"/><circle cx="82" cy="42" r="1.7"/><circle cx="94" cy="38" r="1.7"/><circle cx="101" cy="43" r="1.7"/></g><g font-family="monospace" font-size="7" fill="currentColor" text-anchor="middle"><text x="80" y="20">control gate</text><text x="80" y="31">floating gate</text></g></svg>'
---

## What it is

Every USB stick, SSD and phone stores data in flash cells. Each cell is a MOSFET with two gates stacked on top of each other:

- the **control gate**, connected to the word line;
- the **floating gate**, completely surrounded by oxide and connected to nothing.

Electrons placed on the floating gate stay there because the surrounding oxide is an energy barrier over 3 eV high. Their negative charge raises the threshold voltage seen from the control gate. Reading the cell at a voltage between the "empty" and "full" thresholds tells whether it conducts: that is the bit.

## Writing and erasing: Fowler–Nordheim tunnelling

To move electrons through 7 nm of oxide, the control gate is pulsed to about 18 V. The oxide field reaches 10–15 MV/cm, which turns the barrier into a thin triangle that electrons can **tunnel** through. A negative pulse reverses the field and pulls them back out (erase). The current depends on the field exponentially:

<div class="eq">J = A·E²·e<sup>−B/E</sup>,&nbsp; V<sub>FG</sub> = α<sub>G</sub>V<sub>CG</sub> + Q<sub>FG</sub>/C<sub>T</sub>,&nbsp; ΔV<sub>t</sub> = −Q<sub>FG</sub>/C<sub>CG</sub></div>

The same exponential keeps the bit safe: at read fields (~2 MV/cm) the tunnel current is about 30 orders of magnitude smaller.

## Things to look for

- **Atomic physics:** compare the full-stack band diagram at +18 V (program), −18 V (erase) and +3 V (read).
- **Bench:** try a 15 V program pulse: it fails verify. Then look at retention at 150 °C to see why automotive flash is harder.
