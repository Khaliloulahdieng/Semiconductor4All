---
deviceId: sram-6t
tech: power-memory
order: 15
title: 6T SRAM bitcell
summary: "Six transistors that hold one bit as long as power is on: two cross-coupled inverters and two access transistors. Caches in every processor are built from billions of them, sized at the edge of read and write stability."
specs: ["6 transistors", "cell ratio ≈ 2", "read / write margins", "V_min"]
thumb: '<svg viewBox="0 0 160 80"><path d="M14 6V74M146 6V74" stroke="var(--rf)" stroke-width="2"/><path d="M0 40H160" stroke="var(--ph)" stroke-width="2"/><g fill="color-mix(in srgb,var(--ph) 18%,transparent)" stroke="var(--ph)"><rect x="22" y="32" width="18" height="16" rx="2"/><rect x="120" y="32" width="18" height="16" rx="2"/><rect x="52" y="10" width="18" height="14" rx="2"/><rect x="52" y="56" width="18" height="14" rx="2"/><rect x="90" y="10" width="18" height="14" rx="2"/><rect x="90" y="56" width="18" height="14" rx="2"/></g><path d="M61 24V56M99 24V56M61 40L99 60M99 40L61 60" stroke="currentColor" stroke-width="1" fill="none"/><g font-family="monospace" font-size="7" fill="currentColor" text-anchor="middle"><text x="14" y="4">BL</text><text x="146" y="4">BLB</text><text x="80" y="37">Q · QB</text></g></svg>'
---

## What it is

A static RAM cell stores a bit in a latch: two inverters connected in a loop, so each holds the other's input. Two **pass-gate** transistors, controlled by the word line (WL), connect the storage nodes Q and QB to the bit lines (BL, BLB). That is six transistors: two pull-ups (PU), two pull-downs (PD) and two pass-gates (PG).

The cell has to do three contradictory things:

- **Hold** the bit with the word line off.
- **Be read without flipping.** During a read, both bit lines are precharged high and the WL opens. The node storing 0 is pulled up through the pass-gate while its pull-down holds it down, and the bump must stay below the other inverter's trip point. This needs a strong pull-down: **cell ratio** PD/PG ≈ 1.5–2.5.
- **Be writable.** To write, one bit line is driven to 0, and the pass-gate must overpower the pull-up holding the node high. This needs a weak pull-up: **pull-up ratio** PU/PG < 1.

## Key equations

<div class="eq">SNM = side of the largest square inside the butterfly curves,&nbsp; t<sub>read</sub> ≈ C<sub>BL</sub>·ΔV/I<sub>read</sub></div>

Random transistor mismatch shrinks these margins, and they collapse as V_DD drops. The resulting **V_min** is often what limits the supply voltage of a whole chip.

## Things to look for

- **Atomic physics:** read a 0 and watch electrons flow from ground through both transistors to the bit line; Q rises a few tens of millivolts.
- **Bench:** set the cell ratio to 1 and the read flips the cell. Then add 80 mV of mismatch at 0.45 V and watch one lobe of the butterfly close.
