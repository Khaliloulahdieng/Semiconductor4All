---
deviceId: sic-mosfet
tech: power-memory
order: 14
title: SiC MOSFET
summary: A power MOSFET in 4H silicon carbide. An eight-times-higher critical field lets a 10 µm drift layer block 1200 V, making fast unipolar switches possible for EV inverters and chargers. Its gate interface is the weak spot.
specs: ["1200 V class", "4H-SiC", "10 µm drift", "+18 / −5 V gate"]
thumb: '<svg viewBox="0 0 160 80"><rect x="0" y="70" width="160" height="10" fill="var(--m-np)"/><rect x="0" y="20" width="160" height="50" fill="var(--m-n)"/><rect x="0" y="20" width="62" height="16" fill="var(--m-p)"/><rect x="98" y="20" width="62" height="16" fill="var(--m-p)"/><rect x="18" y="20" width="34" height="6" fill="var(--m-np)"/><rect x="108" y="20" width="34" height="6" fill="var(--m-np)"/><rect x="48" y="16" width="64" height="4" fill="var(--m-ox)"/><rect x="48" y="8" width="64" height="8" fill="var(--m-poly)"/><path d="M80 28v36" stroke="var(--e)" stroke-width="2"/><g font-family="monospace" font-size="7" fill="currentColor" text-anchor="middle"><text x="80" y="15">gate</text><text x="130" y="56">n⁻ SiC drift</text></g></svg>'
---

## What it is

Silicon carbide has a 3.3 eV band gap and a critical field around 2.5 MV/cm, about eight times silicon's. A drift region can therefore be ~10× thinner and ~100× more heavily doped for the same blocking voltage. Since drift resistance scales as BV²/(µE_c³), the unipolar limit drops by more than two orders of magnitude. At 1200 V a silicon MOSFET would be far too resistive and silicon designers use bipolar IGBTs; SiC makes a fast unipolar MOSFET possible.

## The gate problem

The SiC/SiO₂ interface is full of electronic traps (D_it ~ 10¹²–10¹³ cm⁻²eV⁻¹, versus ~10¹⁰ for Si). Trapped electrons do not conduct and their charge scatters the ones that do, so channel mobility is only 20–40 cm²/V·s. The channel can then be a large share of R_on at low voltage classes. It also behaves unusually with temperature: the channel improves when hot (fewer trapped electrons) while the drift gets worse.

## Key equations

<div class="eq">R<sub>on,sp</sub> = 4BV²/(εµE<sub>c</sub>³),&nbsp; W<sub>drift</sub> ≈ 2BV/E<sub>c</sub>,&nbsp; R<sub>on</sub> = R<sub>ch</sub> + R<sub>JFET</sub> + R<sub>drift</sub> + R<sub>sub</sub></div>

## Things to look for

- **Atomic physics:** block 1400 V and compare the peak field with SiC's critical field.
- **Bench:** compare R_on at 25 °C and 175 °C, then improve the oxide (lower D_it) and watch the channel share shrink.
