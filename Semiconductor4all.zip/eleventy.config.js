import { HtmlBasePlugin } from "@11ty/eleventy";
import { feedPlugin } from "@11ty/eleventy-plugin-rss";
import { eleventyImageTransformPlugin } from "@11ty/eleventy-img";
import markdownItKatexModule from "@vscode/markdown-it-katex";
import site from "./src/_data/site.json" with { type: "json" };

const markdownItKatex = markdownItKatexModule.default || markdownItKatexModule;

export default function (eleventyConfig) {
  const isBuild = process.env.ELEVENTY_RUN_MODE === "build";

  // ---------- markdown: KaTeX maths ($…$ and $$…$$) ----------
  eleventyConfig.amendLibrary("md", (md) => md.use(markdownItKatex, { throwOnError: false }));

  // ---------- plugins ----------
  eleventyConfig.addPlugin(HtmlBasePlugin);
  eleventyConfig.addPlugin(eleventyImageTransformPlugin, {
    formats: ["avif", "webp", "auto"],
    widths: [480, 960, "auto"],
    htmlOptions: { imgAttributes: { loading: "lazy", decoding: "async", sizes: "(max-width: 760px) 100vw, 760px" } },
  });
  eleventyConfig.addPlugin(feedPlugin, {
    type: "atom",
    outputPath: "/feed.xml",
    collection: { name: "posts", limit: 20 },
    metadata: {
      language: "en",
      title: site.title,
      subtitle: site.description,
      base: site.url,
      author: { name: site.author },
    },
  });

  // ---------- drafts: visible with `npm start`, excluded from `npm run build` ----------
  eleventyConfig.addPreprocessor("drafts", "*", (data) => {
    if (data.draft && isBuild) return false;
  });

  // ---------- static assets ----------
  eleventyConfig.addPassthroughCopy({ "src/assets": "assets" });
  eleventyConfig.addPassthroughCopy({ "node_modules/katex/dist/katex.min.css": "assets/vendor/katex/katex.min.css" });
  eleventyConfig.addPassthroughCopy({ "node_modules/katex/dist/fonts": "assets/vendor/katex/fonts" });

  // ---------- collections ----------
  eleventyConfig.addCollection("devices", (api) =>
    api.getFilteredByGlob("src/devices/**/*.md").sort((a, b) => (a.data.order || 99) - (b.data.order || 99))
  );
  eleventyConfig.addCollection("posts", (api) =>
    api.getFilteredByGlob("src/blog/posts/**/*.md").sort((a, b) => a.date - b.date)
  );
  eleventyConfig.addCollection("tagList", (api) => {
    const s = new Set();
    for (const p of api.getFilteredByGlob("src/blog/posts/**/*.md")) for (const t of p.data.tags || []) if (t !== "posts") s.add(t);
    return [...s].sort();
  });

  // ---------- filters ----------
  eleventyConfig.addFilter("byTech", (items, tech) => (items || []).filter((d) => d.data.tech === tech));
  eleventyConfig.addFilter("byDevice", (posts, id) => (posts || []).filter((p) => (p.data.devices || []).includes(id)));
  eleventyConfig.addFilter("byTag", (posts, tag) => (posts || []).filter((p) => (p.data.tags || []).includes(tag)));
  eleventyConfig.addFilter("findTech", (techs, id) => techs.find((t) => t.id === id));
  eleventyConfig.addFilter("findDevice", (items, id) => (items || []).find((d) => d.data.deviceId === id));
  eleventyConfig.addFilter("latest", (posts, n) => [...(posts || [])].reverse().slice(0, n));
  eleventyConfig.addFilter("readableDate", (d) =>
    new Date(d).toLocaleDateString("en-GB", { year: "numeric", month: "long", day: "numeric", timeZone: "UTC" })
  );
  eleventyConfig.addFilter("isoDate", (d) => new Date(d).toISOString().slice(0, 10));
  eleventyConfig.addFilter("slug2", (s) => String(s).toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/(^-|-$)/g, ""));
  eleventyConfig.addFilter("absUrl", (path, base) => new URL(path, base).href);

  // ---------- shortcodes ----------
  // {% devicesim "fdsoi-mosfet", "bench" %}  — embed a live simulation in any page or article
  eleventyConfig.addShortcode("devicesim", (id, view = "bench") =>
    `<div class="sim-embed"><div class="sim" data-sim="${id}" data-view="${view}"><p class="sim-loading">Loading simulation…</p></div></div>`
  );

  return {
    dir: { input: "src", output: "_site", includes: "_includes", data: "_data" },
    markdownTemplateEngine: "njk",
    htmlTemplateEngine: "njk",
    templateFormats: ["md", "njk", "html"],
  };
}
