# Semiconductor4all

Interactive website about semiconductor devices. Pick a technology, open a device, and run two live simulations:

1. **Atomic physics**: cross-section with lattice, dopant ions, moving electrons/holes, depletion regions, an atom lens, and an energy-band diagram from a 1D Poisson solver running in the browser.
2. **How it works**: a test bench with instruments, a schematic with numbered test points (TP) and a probe card per TP (equation, live plot, readouts).

Built with [Eleventy](https://www.11ty.dev/) (static site, Markdown articles). No server code: the output in `_site/` can be hosted anywhere.

## Run it

```bash
npm install
npm start          # dev server with live reload on http://localhost:8080
npm run build      # production build into _site/ (drafts excluded)
```

## Project layout

```
src/
  _data/site.json            site title, URL (change this when you buy the domain), author
  _data/technologies.json    the 4 technologies + "coming soon" devices
  _includes/layouts/         base, technology, device, post, page
  index.njk                  home page
  technologies/<tech>.md     one page per technology
  devices/<tech>/<id>.md     one page per device (front matter + explanation)
  blog/posts/<slug>/index.md articles (one folder each, images next to the .md)
  assets/css/                site.css, sim.css, fonts.css
  assets/js/lib/             plot.js, controls.js, bench.js, atomic.js, physics.js (Poisson solver, EKV model)
  assets/js/devices/<id>.js  each device's two simulations
photonics_page/              the original MZM bench pages (reference only, not built)
```

## Writing an article

Create `src/blog/posts/my-topic/index.md`:

```markdown
---
title: "My title"
description: "One or two sentences used for search engines and link previews."
date: 2026-11-05
tags: [photonics, tutorial]
devices: [mzm-modulator]   # optional: links device cards under the article
draft: true                # visible with npm start, excluded from npm run build
---

Text in Markdown. Inline maths $V_\pi L$ and display maths:

$$ \Delta n = -8.8\times10^{-22}\,\Delta N $$

Embed a live simulation:

{% devicesim "mzm-modulator", "bench" %}

![Alt text is required](figure.png)
```

- The URL is `/blog/my-topic/` (folder name, or `slug:` in front matter). It never depends on the date, so you can re-date or edit without breaking links. Don't rename a folder after publishing.
- Images placed next to `index.md` are resized and converted to AVIF/WebP at build time.
- Remove `draft: true` to publish.

## Adding a device

1. `src/assets/js/devices/<id>.js` exporting `{ atomic, bench }` (copy an existing device; the data contract is documented at the top of `lib/atomic.js` and `lib/bench.js`).
2. `src/devices/<tech>/<id>.md` with `deviceId`, `tech`, `title`, `summary`, `specs`, `thumb`, `order`.
3. Remove it from the `planned` list in `src/_data/technologies.json`.

## Publishing on your own domain

The site is static. Recommended: **GitHub Pages** (free, HTTPS, custom domain). A workflow is included in `.github/workflows/deploy.yml`.

1. Create a GitHub repository and push this folder (`git init`, `git add .`, `git commit`, `git push`).
2. In the repository: *Settings → Pages → Source: GitHub Actions*.
3. Buy the domain, then in *Settings → Pages → Custom domain* enter it. At your registrar add the DNS records GitHub shows (an `A`/`AAAA` set for the apex, or a `CNAME` for `www`). Tick *Enforce HTTPS*.
4. Put the final address in `src/_data/site.json` → `"url"` (used by the sitemap, RSS feed, canonical links and social previews).

After that, publishing an article = add the Markdown file, commit, push. Netlify or Cloudflare Pages work the same way (build command `npm run build`, output folder `_site`).
